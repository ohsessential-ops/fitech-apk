#!/usr/bin/env python3
"""Offline FiTech source quality gate.

This check does not replace `flutter analyze` or `flutter test`. It catches
common packaging and source-structure failures before the Flutter SDK build.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ERRORS: list[str] = []
WARNINGS: list[str] = []


def fail(message: str) -> None:
    ERRORS.append(message)


def warn(message: str) -> None:
    WARNINGS.append(message)


def check_required_files() -> None:
    required = [
        'pubspec.yaml',
        'analysis_options.yaml',
        'lib/main.dart',
        'lib/core/database/database_service.dart',
        'assets/branding/fitech_logo.png',
    ]
    for item in required:
        if not (ROOT / item).is_file():
            fail(f'Missing required file: {item}')


def check_relative_imports() -> None:
    pattern = re.compile(r"(?:import|export|part)\s+'([^']+)'")
    for source in ROOT.glob('lib/**/*.dart'):
        text = source.read_text(encoding='utf-8')
        for ref in pattern.findall(text):
            if ref.startswith('.'):
                target = (source.parent / ref).resolve()
                if not target.is_file():
                    fail(f'{source.relative_to(ROOT)} has missing import: {ref}')


def check_balanced_delimiters() -> None:
    # Lightweight scanner that ignores comments and strings.
    for source in list(ROOT.glob('lib/**/*.dart')) + list(ROOT.glob('test/**/*.dart')):
        text = source.read_text(encoding='utf-8')
        stack: list[tuple[str, int]] = []
        pairs = {')': '(', ']': '[', '}': '{'}
        opening = set(pairs.values())
        i = 0
        line = 1
        quote: str | None = None
        triple = False
        while i < len(text):
            c = text[i]
            if c == '\n':
                line += 1
            if quote:
                if c == '\\':
                    i += 2
                    continue
                marker = quote * (3 if triple else 1)
                if text.startswith(marker, i):
                    i += len(marker)
                    quote = None
                    triple = False
                    continue
                i += 1
                continue
            if text.startswith('//', i):
                end = text.find('\n', i)
                i = len(text) if end == -1 else end
                continue
            if text.startswith('/*', i):
                end = text.find('*/', i + 2)
                if end == -1:
                    fail(f'{source.relative_to(ROOT)} has unterminated block comment')
                    break
                line += text[i:end].count('\n')
                i = end + 2
                continue
            if text.startswith("'''", i) or text.startswith('"""', i):
                quote = text[i]
                triple = True
                i += 3
                continue
            if c in "'\"":
                quote = c
                i += 1
                continue
            if c in opening:
                stack.append((c, line))
            elif c in pairs:
                if not stack or stack[-1][0] != pairs[c]:
                    fail(f'{source.relative_to(ROOT)} delimiter mismatch near line {line}')
                    break
                stack.pop()
            i += 1
        if quote:
            fail(f'{source.relative_to(ROOT)} has unterminated string')
        if stack:
            fail(f'{source.relative_to(ROOT)} has unclosed {stack[-1][0]} from line {stack[-1][1]}')


def check_project_metadata() -> None:
    pubspec = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
    if 'version: 1.3.0+13' not in pubspec:
        fail('pubspec version is not 1.3.0+13')
    if 'uses-material-design: true' not in pubspec:
        warn('Material icons may not be enabled')
    if not (ROOT / 'android').exists():
        warn('Android runner is not generated yet; Task 14 must run flutter create before APK build')


def main() -> int:
    check_required_files()
    check_relative_imports()
    check_balanced_delimiters()
    check_project_metadata()

    print(f'FiTech quality gate: {len(ERRORS)} error(s), {len(WARNINGS)} warning(s)')
    for item in ERRORS:
        print(f'ERROR: {item}')
    for item in WARNINGS:
        print(f'WARNING: {item}')
    return 1 if ERRORS else 0


if __name__ == '__main__':
    sys.exit(main())
