import '../../../core/database/database_service.dart';
import '../domain/global_search_result.dart';

class GlobalSearchRepository {
  GlobalSearchRepository({DatabaseService? databaseService})
      : _databaseService = databaseService ?? DatabaseService.instance;

  final DatabaseService _databaseService;

  Future<List<GlobalSearchResult>> search(
    String query, {
    GlobalSearchType? type,
  }) async {
    final clean = query.trim();
    if (clean.isEmpty) return [];

    final db = await _databaseService.database;
    final like = '%$clean%';
    final results = <GlobalSearchResult>[];

    if (type == null || type == GlobalSearchType.order) {
      final rows = await db.rawQuery('''
        SELECT order_id, sku_snapshot, product_name_snapshot,
               tracking_number, calculated_profit_gbp, order_date
        FROM financial_orders
        WHERE deleted_at IS NULL
          AND (
            order_id LIKE ? OR
            sku_snapshot LIKE ? OR
            product_name_snapshot LIKE ? OR
            tracking_number LIKE ?
          )
        ORDER BY order_date DESC
        LIMIT 50
      ''', [like, like, like, like]);

      for (final row in rows) {
        results.add(
          GlobalSearchResult(
            type: GlobalSearchType.order,
            title: row['order_id'] as String,
            subtitle:
                '${row['product_name_snapshot']} • ${row['sku_snapshot']}',
            reference: row['order_id'] as String,
            trailing:
                '£${(row['calculated_profit_gbp'] as num).toStringAsFixed(2)}',
          ),
        );
      }
    }

    if (type == null || type == GlobalSearchType.product) {
      final rows = await db.rawQuery('''
        SELECT sku, name, variant, is_active
        FROM products
        WHERE sku LIKE ? OR name LIKE ? OR variant LIKE ?
        ORDER BY is_active DESC, name ASC
        LIMIT 50
      ''', [like, like, like]);

      for (final row in rows) {
        results.add(
          GlobalSearchResult(
            type: GlobalSearchType.product,
            title: row['name'] as String,
            subtitle: '${row['sku']} • ${row['variant'] ?? 'Standard'}',
            reference: row['sku'] as String,
            trailing: (row['is_active'] as int? ?? 1) == 1
                ? 'Active'
                : 'Inactive',
          ),
        );
      }
    }

    return results;
  }
}
