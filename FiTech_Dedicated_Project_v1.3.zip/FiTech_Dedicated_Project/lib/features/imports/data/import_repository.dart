import 'dart:convert';

import '../../../core/database/database_service.dart';
import '../../products/data/product_repository.dart';
import '../domain/import_models.dart';

class ImportRepository {
  ImportRepository({DatabaseService? databaseService})
      : _databaseService = databaseService ?? DatabaseService.instance;

  final DatabaseService _databaseService;

  Future<bool> fileAlreadyImported({
    required String fileHash,
    required ImportType type,
  }) async {
    final db = await _databaseService.database;
    final rows = await db.query(
      'import_batches',
      columns: ['id'],
      where: 'file_hash = ? AND import_type = ? AND status = ?',
      whereArgs: [fileHash, type.name, 'completed'],
      limit: 1,
    );
    return rows.isNotEmpty;
  }

  Future<ImportExecutionResult> execute(ImportPreview preview) async {
    final db = await _databaseService.database;
    final now = DateTime.now().toUtc().toIso8601String();

    final batchId = await db.insert('import_batches', {
      'import_type': preview.type.name,
      'file_name': preview.fileName,
      'file_hash': preview.fileHash,
      'total_rows': preview.totalRows,
      'valid_rows': preview.validRows,
      'imported_rows': 0,
      'skipped_rows': 0,
      'failed_rows': 0,
      'status': 'processing',
      'created_at': now,
    });

    var imported = 0;
    var skipped = 0;
    var failed = 0;

    for (final row in preview.rows) {
      if (!row.canImport) {
        skipped++;
        await _saveRowResult(
          batchId: batchId,
          row: row,
          status: 'skipped',
          message: row.messages.join(' '),
        );
        continue;
      }

      try {
        switch (preview.type) {
          case ImportType.orders:
            await _importOrder(row.values);
          case ImportType.trackingUpdates:
            await _importTracking(row.values);
          case ImportType.supplierPayments:
            await _importSupplierPayment(row.values);
        }
        imported++;
        await _saveRowResult(
          batchId: batchId,
          row: row,
          status: 'imported',
          message: row.messages.join(' '),
        );
      } catch (error) {
        failed++;
        await _saveRowResult(
          batchId: batchId,
          row: row,
          status: 'failed',
          message: error.toString(),
        );
      }
    }

    await db.update(
      'import_batches',
      {
        'imported_rows': imported,
        'skipped_rows': skipped,
        'failed_rows': failed,
        'status': failed == 0 ? 'completed' : 'completed_with_errors',
        'completed_at': DateTime.now().toUtc().toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [batchId],
    );

    return ImportExecutionResult(
      batchId: batchId,
      imported: imported,
      skipped: skipped,
      failed: failed,
    );
  }

  Future<void> _importOrder(Map<String, String> values) async {
    final db = await _databaseService.database;
    final orderId = values['order_id']!.trim();
    final date = DateTime.parse(values['order_date']!.trim());
    final quantity = int.parse(values['quantity']!.trim());
    final earning =
        double.parse(values['tiktok_net_earning_gbp']!.trim());
    final unitCost =
        double.parse(values['supplier_unit_cost_gbp']!.trim());
    final adjustment =
        double.tryParse(values['manual_adjustment_gbp'] ?? '') ?? 0;
    final totalCost = unitCost * quantity;
    final profit = earning - totalCost + adjustment;

    final shopRows = await db.query(
      'shops',
      columns: ['id', 'name'],
      where: 'LOWER(name) = LOWER(?)',
      whereArgs: [values['shop']!.trim()],
      limit: 1,
    );
    if (shopRows.isEmpty) {
      throw Exception('Unknown shop: ${values['shop']}');
    }

    final sku = values['sku']!.trim();
    final productRows = await db.query(
      'products',
      columns: ['id', 'name', 'variant'],
      where: 'LOWER(sku) = LOWER(?)',
      whereArgs: [sku],
      limit: 1,
    );

    int? productId;
    String productName = values['product_name']?.trim() ?? sku;
    String variant = values['variant']?.trim() ?? '';

    if (productRows.isNotEmpty) {
      productId = productRows.first['id'] as int;
      productName = productRows.first['name'] as String;
      variant = (productRows.first['variant'] as String?) ?? variant;
    }

    await db.transaction((txn) async {
      final orderRowId = await txn.insert('financial_orders', {
        'order_id': orderId,
        'order_date': date.toIso8601String(),
        'shop_id': shopRows.first['id'],
        'product_id': productId,
        'sku_snapshot': sku,
        'product_name_snapshot': productName,
        'variant_snapshot': variant,
        'quantity': quantity,
        'tiktok_net_earning_gbp': earning,
        'supplier_unit_cost_gbp': unitCost,
        'supplier_total_cost_gbp': totalCost,
        'manual_adjustment_gbp': adjustment,
        'calculated_profit_gbp': profit,
        'tracking_number': values['tracking_number'],
        'notes': values['notes'],
        'created_at': DateTime.now().toUtc().toIso8601String(),
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      });

      final suppliers = await txn.query(
        'suppliers',
        columns: ['id'],
        where: 'is_active = 1',
        orderBy: 'id',
        limit: 1,
      );
      if (suppliers.isNotEmpty) {
        await txn.insert('supplier_ledger_entries', {
          'supplier_id': suppliers.first['id'],
          'entry_date': date.toIso8601String(),
          'entry_type': 'order_debit',
          'debit_gbp': totalCost,
          'credit_gbp': 0,
          'reference': orderId,
          'notes': 'Imported order $orderId',
          'financial_order_id': orderRowId,
          'created_at': DateTime.now().toUtc().toIso8601String(),
        });
      }
    });
  }

  Future<void> _importTracking(Map<String, String> values) async {
    final db = await _databaseService.database;
    final updated = await db.update(
      'financial_orders',
      {
        'tracking_number': values['tracking_number']!.trim(),
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      },
      where: 'order_id = ? AND deleted_at IS NULL',
      whereArgs: [values['order_id']!.trim()],
    );
    if (updated == 0) throw Exception('Order not found.');
  }

  Future<void> _importSupplierPayment(Map<String, String> values) async {
    final db = await _databaseService.database;
    final suppliers = await db.query(
      'suppliers',
      columns: ['id'],
      where: 'is_active = 1',
      orderBy: 'id',
      limit: 1,
    );
    if (suppliers.isEmpty) throw Exception('No active supplier.');

    final date = DateTime.parse(values['payment_date']!.trim());
    final amount = double.parse(values['amount_gbp']!.trim());
    final reference = values['payoneer_reference']?.trim();

    await db.transaction((txn) async {
      await txn.insert('supplier_ledger_entries', {
        'supplier_id': suppliers.first['id'],
        'entry_date': date.toIso8601String(),
        'entry_type': 'payment',
        'debit_gbp': 0,
        'credit_gbp': amount,
        'reference': reference,
        'notes': values['notes'],
        'created_at': DateTime.now().toUtc().toIso8601String(),
      });

      await txn.insert('bank_ledger_entries', {
        'entry_date': date.toIso8601String(),
        'entry_type': 'supplier_payment',
        'inflow_gbp': 0,
        'outflow_gbp': amount,
        'reference': reference,
        'notes': values['notes'] ?? 'Imported supplier payment',
        'created_at': DateTime.now().toUtc().toIso8601String(),
      });
    });
  }

  Future<void> _saveRowResult({
    required int batchId,
    required ImportValidationRow row,
    required String status,
    required String message,
  }) async {
    final db = await _databaseService.database;
    await db.insert('import_row_results', {
      'batch_id': batchId,
      'row_number': row.rowNumber,
      'status': status,
      'reference_value': row.reference,
      'message': message,
      'raw_json': jsonEncode(row.values),
      'created_at': DateTime.now().toUtc().toIso8601String(),
    });
  }

  Future<List<Map<String, Object?>>> history() async {
    final db = await _databaseService.database;
    return db.query(
      'import_batches',
      orderBy: 'created_at DESC, id DESC',
      limit: 100,
    );
  }
}
