import '../../../core/database/database_service.dart';
import '../domain/import_models.dart';
import 'tabular_file_parser.dart';

class ImportValidationService {
  ImportValidationService({DatabaseService? databaseService})
      : _databaseService = databaseService ?? DatabaseService.instance;

  final DatabaseService _databaseService;

  Future<ImportPreview> validate({
    required ImportType type,
    required String fileName,
    required ParsedTabularFile parsed,
  }) async {
    final rows = <ImportValidationRow>[];

    for (var index = 0; index < parsed.rows.length; index++) {
      final values = parsed.rows[index];
      switch (type) {
        case ImportType.orders:
          rows.add(await _validateOrder(index + 2, values));
        case ImportType.trackingUpdates:
          rows.add(await _validateTracking(index + 2, values));
        case ImportType.supplierPayments:
          rows.add(await _validateSupplierPayment(index + 2, values));
      }
    }

    return ImportPreview(
      type: type,
      fileName: fileName,
      fileHash: parsed.hash,
      headers: parsed.headers,
      rows: rows,
    );
  }

  Future<ImportValidationRow> _validateOrder(
    int rowNumber,
    Map<String, String> values,
  ) async {
    final messages = <String>[];
    var status = ImportRowStatus.valid;

    final required = [
      'order_id',
      'order_date',
      'shop',
      'sku',
      'quantity',
      'tiktok_net_earning_gbp',
      'supplier_unit_cost_gbp',
    ];

    for (final key in required) {
      if ((values[key] ?? '').trim().isEmpty) {
        messages.add('Missing $key');
        status = ImportRowStatus.invalid;
      }
    }

    final orderId = values['order_id'] ?? '';
    if (orderId.isNotEmpty) {
      final db = await _databaseService.database;
      final existing = await db.query(
        'financial_orders',
        columns: ['id'],
        where: 'order_id = ? AND deleted_at IS NULL',
        whereArgs: [orderId],
        limit: 1,
      );
      if (existing.isNotEmpty) {
        messages.add('Order ID already exists and will be skipped.');
        status = ImportRowStatus.invalid;
      }
    }

    if (DateTime.tryParse(values['order_date'] ?? '') == null) {
      messages.add('Invalid date. Use YYYY-MM-DD.');
      status = ImportRowStatus.invalid;
    }

    final quantity = int.tryParse(values['quantity'] ?? '');
    if (quantity == null || quantity <= 0) {
      messages.add('Quantity must be a positive whole number.');
      status = ImportRowStatus.invalid;
    }

    final earning =
        double.tryParse(values['tiktok_net_earning_gbp'] ?? '');
    final cost =
        double.tryParse(values['supplier_unit_cost_gbp'] ?? '');
    if (earning == null) {
      messages.add('TikTok net earning must be numeric.');
      status = ImportRowStatus.invalid;
    }
    if (cost == null || cost < 0) {
      messages.add('Supplier unit cost must be zero or positive.');
      status = ImportRowStatus.invalid;
    }

    if ((values['tracking_number'] ?? '').trim().isEmpty &&
        status == ImportRowStatus.valid) {
      messages.add('Tracking is empty; order can still be imported.');
      status = ImportRowStatus.warning;
    }

    return ImportValidationRow(
      rowNumber: rowNumber,
      values: values,
      status: status,
      messages: messages,
      reference: orderId,
    );
  }

  Future<ImportValidationRow> _validateTracking(
    int rowNumber,
    Map<String, String> values,
  ) async {
    final messages = <String>[];
    var status = ImportRowStatus.valid;
    final orderId = values['order_id'] ?? '';
    final tracking = values['tracking_number'] ?? '';

    if (orderId.isEmpty || tracking.isEmpty) {
      messages.add('order_id and tracking_number are required.');
      status = ImportRowStatus.invalid;
    } else {
      final db = await _databaseService.database;
      final existing = await db.query(
        'financial_orders',
        columns: ['id', 'tracking_number'],
        where: 'order_id = ? AND deleted_at IS NULL',
        whereArgs: [orderId],
        limit: 1,
      );
      if (existing.isEmpty) {
        messages.add('Order ID was not found.');
        status = ImportRowStatus.invalid;
      } else if ((existing.first['tracking_number'] as String? ?? '') ==
          tracking) {
        messages.add('Tracking is already up to date.');
        status = ImportRowStatus.warning;
      }
    }

    return ImportValidationRow(
      rowNumber: rowNumber,
      values: values,
      status: status,
      messages: messages,
      reference: orderId,
    );
  }

  Future<ImportValidationRow> _validateSupplierPayment(
    int rowNumber,
    Map<String, String> values,
  ) async {
    final messages = <String>[];
    var status = ImportRowStatus.valid;

    final date = DateTime.tryParse(values['payment_date'] ?? '');
    final amount = double.tryParse(values['amount_gbp'] ?? '');
    final reference = values['payoneer_reference'] ?? '';

    if (date == null) {
      messages.add('Invalid payment date. Use YYYY-MM-DD.');
      status = ImportRowStatus.invalid;
    }
    if (amount == null || amount <= 0) {
      messages.add('Amount must be greater than zero.');
      status = ImportRowStatus.invalid;
    }
    if (reference.isEmpty && status == ImportRowStatus.valid) {
      messages.add('Payoneer reference is empty.');
      status = ImportRowStatus.warning;
    }

    return ImportValidationRow(
      rowNumber: rowNumber,
      values: values,
      status: status,
      messages: messages,
      reference: reference,
    );
  }
}
