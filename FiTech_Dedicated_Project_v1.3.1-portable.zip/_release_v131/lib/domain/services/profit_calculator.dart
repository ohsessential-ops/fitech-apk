class ProfitResult {
  const ProfitResult({
    required this.profit,
    required this.marginPercent,
  });

  final double profit;
  final double? marginPercent;
}

class ProfitCalculator {
  const ProfitCalculator();

  ProfitResult calculate({
    required double tiktokNetEarning,
    required double supplierTotalCost,
    double manualAdjustment = 0,
  }) {
    final profit =
        tiktokNetEarning - supplierTotalCost + manualAdjustment;
    final margin = tiktokNetEarning == 0
        ? null
        : (profit / tiktokNetEarning) * 100;

    return ProfitResult(
      profit: _round(profit),
      marginPercent: margin == null ? null : _round(margin),
    );
  }

  double _round(double value) =>
      (value * 100).roundToDouble() / 100;
}
