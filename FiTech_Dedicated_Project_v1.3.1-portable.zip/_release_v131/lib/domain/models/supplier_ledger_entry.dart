enum SupplierLedgerType {
  orderDebit,
  supplierPayment,
  supplierCredit,
  correctionDebit,
  correctionCredit,
}

class SupplierLedgerEntry {
  const SupplierLedgerEntry({
    this.id,
    required this.supplierId,
    required this.entryDate,
    required this.type,
    this.referenceType,
    this.referenceId,
    required this.description,
    required this.debitGbp,
    required this.creditGbp,
    this.notes,
    required this.createdAt,
  });

  final int? id;
  final int supplierId;
  final DateTime entryDate;
  final SupplierLedgerType type;
  final String? referenceType;
  final String? referenceId;
  final String description;
  final double debitGbp;
  final double creditGbp;
  final String? notes;
  final DateTime createdAt;

  Map<String, Object?> toMap() => {
        'supplier_id': supplierId,
        'entry_date': entryDate.toIso8601String(),
        'type': type.name,
        'reference_type': referenceType,
        'reference_id': referenceId,
        'description': description,
        'debit_gbp': debitGbp,
        'credit_gbp': creditGbp,
        'notes': notes,
        'created_at': createdAt.toUtc().toIso8601String(),
      };

  factory SupplierLedgerEntry.fromMap(Map<String, Object?> map) {
    return SupplierLedgerEntry(
      id: map['id'] as int,
      supplierId: map['supplier_id'] as int,
      entryDate: DateTime.parse(map['entry_date'] as String),
      type: SupplierLedgerType.values.firstWhere(
        (item) => item.name == map['type'],
      ),
      referenceType: map['reference_type'] as String?,
      referenceId: map['reference_id'] as String?,
      description: map['description'] as String,
      debitGbp: (map['debit_gbp'] as num).toDouble(),
      creditGbp: (map['credit_gbp'] as num).toDouble(),
      notes: map['notes'] as String?,
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }
}
