enum UserRole { owner, admin, manager, accountant, staff, readOnly }

class AppUser {
  const AppUser({
    required this.id,
    required this.email,
    required this.displayName,
    required this.role,
    required this.isActive,
    required this.createdAt,
    required this.updatedAt,
    this.lastLoginAt,
  });

  final int id;
  final String email;
  final String displayName;
  final UserRole role;
  final bool isActive;
  final DateTime createdAt;
  final DateTime updatedAt;
  final DateTime? lastLoginAt;

  factory AppUser.fromMap(Map<String, Object?> map) {
    return AppUser(
      id: map['id'] as int,
      email: map['email'] as String,
      displayName: map['display_name'] as String,
      role: UserRole.values.firstWhere(
        (item) => item.name == map['role'],
      ),
      isActive: (map['is_active'] as int) == 1,
      createdAt: DateTime.parse(map['created_at'] as String),
      updatedAt: DateTime.parse(map['updated_at'] as String),
      lastLoginAt: map['last_login_at'] == null
          ? null
          : DateTime.parse(map['last_login_at'] as String),
    );
  }
}
