class ReturnRecord {
  const ReturnRecord({
    this.id,
    required this.financialOrderId,
    required this.orderId,
    required this.returnDate,
    this.reason,
    required this.customerRefundGbp,
    required this.supplierCreditGbp,
    required this.otherAdjustmentGbp,
    required this.adjustedProfitGbp,
    this.notes,
    required this.createdAt,
  });

  final int? id;
  final int financialOrderId;
  final String orderId;
  final DateTime returnDate;
  final String? reason;
  final double customerRefundGbp;
  final double supplierCreditGbp;
  final double otherAdjustmentGbp;
  final double adjustedProfitGbp;
  final String? notes;
  final DateTime createdAt;
}
