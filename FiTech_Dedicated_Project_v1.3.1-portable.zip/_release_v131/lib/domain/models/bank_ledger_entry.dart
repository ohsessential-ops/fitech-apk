enum BankLedgerType {
  tiktokPayout,
  supplierPayment,
  customerRefund,
  manualInflow,
  manualOutflow,
  correction,
}

class BankLedgerEntry {
  const BankLedgerEntry({
    this.id,
    required this.entryDate,
    required this.type,
    this.referenceType,
    this.referenceId,
    required this.description,
    required this.inflowGbp,
    required this.outflowGbp,
    this.notes,
    required this.createdAt,
  });

  final int? id;
  final DateTime entryDate;
  final BankLedgerType type;
  final String? referenceType;
  final String? referenceId;
  final String description;
  final double inflowGbp;
  final double outflowGbp;
  final String? notes;
  final DateTime createdAt;

  double get signedImpact => inflowGbp - outflowGbp;

  Map<String, Object?> toMap() => {
        'entry_date': entryDate.toIso8601String(),
        'type': type.name,
        'reference_type': referenceType,
        'reference_id': referenceId,
        'description': description,
        'inflow_gbp': inflowGbp,
        'outflow_gbp': outflowGbp,
        'notes': notes,
        'created_at': createdAt.toUtc().toIso8601String(),
      };

  factory BankLedgerEntry.fromMap(Map<String, Object?> map) {
    return BankLedgerEntry(
      id: map['id'] as int,
      entryDate: DateTime.parse(map['entry_date'] as String),
      type: BankLedgerType.values.firstWhere(
        (item) => item.name == map['type'],
      ),
      referenceType: map['reference_type'] as String?,
      referenceId: map['reference_id'] as String?,
      description: map['description'] as String,
      inflowGbp: (map['inflow_gbp'] as num).toDouble(),
      outflowGbp: (map['outflow_gbp'] as num).toDouble(),
      notes: map['notes'] as String?,
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }
}
