class BankReconciliation {
  const BankReconciliation({
    this.id,
    required this.reconciliationDate,
    required this.actualBankBalanceGbp,
    required this.calculatedBankBalanceGbp,
    required this.differenceGbp,
    this.notes,
    required this.createdAt,
  });

  final int? id;
  final DateTime reconciliationDate;
  final double actualBankBalanceGbp;
  final double calculatedBankBalanceGbp;
  final double differenceGbp;
  final String? notes;
  final DateTime createdAt;

  Map<String, Object?> toMap() => {
        'reconciliation_date': reconciliationDate.toIso8601String(),
        'actual_bank_balance_gbp': actualBankBalanceGbp,
        'calculated_bank_balance_gbp': calculatedBankBalanceGbp,
        'difference_gbp': differenceGbp,
        'notes': notes,
        'created_at': createdAt.toUtc().toIso8601String(),
      };

  factory BankReconciliation.fromMap(Map<String, Object?> map) {
    return BankReconciliation(
      id: map['id'] as int,
      reconciliationDate: DateTime.parse(map['reconciliation_date'] as String),
      actualBankBalanceGbp:
          (map['actual_bank_balance_gbp'] as num).toDouble(),
      calculatedBankBalanceGbp:
          (map['calculated_bank_balance_gbp'] as num).toDouble(),
      differenceGbp: (map['difference_gbp'] as num).toDouble(),
      notes: map['notes'] as String?,
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }
}
