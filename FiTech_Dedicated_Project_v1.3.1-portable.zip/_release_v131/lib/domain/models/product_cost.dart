class ProductCost {
  const ProductCost({
    this.id,
    required this.productId,
    required this.unitCostGbp,
    required this.effectiveFrom,
    this.effectiveTo,
    required this.createdAt,
  });

  final int? id;
  final int productId;
  final double unitCostGbp;
  final DateTime effectiveFrom;
  final DateTime? effectiveTo;
  final DateTime createdAt;

  Map<String, Object?> toMap() {
    return {
      'product_id': productId,
      'unit_cost_gbp': unitCostGbp,
      'effective_from': effectiveFrom.toIso8601String(),
      'effective_to': effectiveTo?.toIso8601String(),
      'created_at': createdAt.toUtc().toIso8601String(),
    };
  }

  factory ProductCost.fromMap(Map<String, Object?> map) {
    return ProductCost(
      id: map['id'] as int,
      productId: map['product_id'] as int,
      unitCostGbp: (map['unit_cost_gbp'] as num).toDouble(),
      effectiveFrom: DateTime.parse(map['effective_from'] as String),
      effectiveTo: map['effective_to'] == null
          ? null
          : DateTime.parse(map['effective_to'] as String),
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }
}
