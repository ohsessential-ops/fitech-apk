class Supplier {
  const Supplier({
    required this.id,
    required this.displayName,
    required this.paymentMethod,
    required this.openingBalanceGbp,
    required this.isActive,
  });

  final int id;
  final String displayName;
  final String paymentMethod;
  final double openingBalanceGbp;
  final bool isActive;

  factory Supplier.fromMap(Map<String, Object?> map) {
    return Supplier(
      id: map['id'] as int,
      displayName: map['display_name'] as String,
      paymentMethod: map['payment_method'] as String,
      openingBalanceGbp: (map['opening_balance_gbp'] as num).toDouble(),
      isActive: (map['is_active'] as int) == 1,
    );
  }
}
