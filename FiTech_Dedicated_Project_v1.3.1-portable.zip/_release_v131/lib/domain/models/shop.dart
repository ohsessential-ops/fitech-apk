class Shop {
  const Shop({
    required this.id,
    required this.name,
    required this.platform,
    required this.isActive,
  });

  final int id;
  final String name;
  final String platform;
  final bool isActive;

  factory Shop.fromMap(Map<String, Object?> map) {
    return Shop(
      id: map['id'] as int,
      name: map['name'] as String,
      platform: map['platform'] as String,
      isActive: (map['is_active'] as int) == 1,
    );
  }
}
