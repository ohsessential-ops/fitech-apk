class FinancialOrder {
  const FinancialOrder({
    this.id,
    this.productId,
    required this.shopId,
    required this.shopName,
    required this.tiktokOrderId,
    required this.orderDate,
    required this.skuSnapshot,
    this.productNameSnapshot,
    this.variantSnapshot,
    required this.quantity,
    required this.tiktokNetEarningGbp,
    required this.supplierUnitCostSnapshotGbp,
    required this.supplierTotalCostGbp,
    required this.manualAdjustmentGbp,
    required this.calculatedProfitGbp,
    required this.profitMarginPercent,
    this.trackingNumber,
    this.notes,
    required this.createdAt,
    required this.updatedAt,
  });

  final int? id;
  final int? productId;
  final int shopId;
  final String shopName;
  final String tiktokOrderId;
  final DateTime orderDate;
  final String skuSnapshot;
  final String? productNameSnapshot;
  final String? variantSnapshot;
  final int quantity;
  final double tiktokNetEarningGbp;
  final double supplierUnitCostSnapshotGbp;
  final double supplierTotalCostGbp;
  final double manualAdjustmentGbp;
  final double calculatedProfitGbp;
  final double? profitMarginPercent;
  final String? trackingNumber;
  final String? notes;
  final DateTime createdAt;
  final DateTime updatedAt;

  Map<String, Object?> toInsertMap() {
    return {
      'shop_id': shopId,
      'product_id': productId,
      'tiktok_order_id': tiktokOrderId,
      'order_date': orderDate.toIso8601String(),
      'sku_snapshot': skuSnapshot,
      'product_name_snapshot': productNameSnapshot,
      'variant_snapshot': variantSnapshot,
      'quantity': quantity,
      'tiktok_net_earning_gbp': tiktokNetEarningGbp,
      'supplier_unit_cost_snapshot_gbp': supplierUnitCostSnapshotGbp,
      'supplier_total_cost_gbp': supplierTotalCostGbp,
      'manual_adjustment_gbp': manualAdjustmentGbp,
      'calculated_profit_gbp': calculatedProfitGbp,
      'profit_margin_percent': profitMarginPercent,
      'tracking_number': trackingNumber,
      'notes': notes,
      'created_at': createdAt.toUtc().toIso8601String(),
      'updated_at': updatedAt.toUtc().toIso8601String(),
    };
  }

  factory FinancialOrder.fromJoinedMap(Map<String, Object?> map) {
    return FinancialOrder(
      id: map['id'] as int,
      productId: map['product_id'] as int?,
      shopId: map['shop_id'] as int,
      shopName: map['shop_name'] as String,
      tiktokOrderId: map['tiktok_order_id'] as String,
      orderDate: DateTime.parse(map['order_date'] as String),
      skuSnapshot: map['sku_snapshot'] as String,
      productNameSnapshot: map['product_name_snapshot'] as String?,
      variantSnapshot: map['variant_snapshot'] as String?,
      quantity: map['quantity'] as int,
      tiktokNetEarningGbp:
          (map['tiktok_net_earning_gbp'] as num).toDouble(),
      supplierUnitCostSnapshotGbp:
          (map['supplier_unit_cost_snapshot_gbp'] as num).toDouble(),
      supplierTotalCostGbp:
          (map['supplier_total_cost_gbp'] as num).toDouble(),
      manualAdjustmentGbp:
          (map['manual_adjustment_gbp'] as num).toDouble(),
      calculatedProfitGbp:
          (map['calculated_profit_gbp'] as num).toDouble(),
      profitMarginPercent: map['profit_margin_percent'] == null
          ? null
          : (map['profit_margin_percent'] as num).toDouble(),
      trackingNumber: map['tracking_number'] as String?,
      notes: map['notes'] as String?,
      createdAt: DateTime.parse(map['created_at'] as String),
      updatedAt: DateTime.parse(map['updated_at'] as String),
    );
  }
}
