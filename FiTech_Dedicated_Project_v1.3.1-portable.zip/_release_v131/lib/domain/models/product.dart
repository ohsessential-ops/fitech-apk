class Product {
  const Product({
    this.id,
    required this.sku,
    this.supplierSku,
    required this.productName,
    this.variant,
    required this.isActive,
    required this.createdAt,
    required this.updatedAt,
    this.currentCostGbp,
  });

  final int? id;
  final String sku;
  final String? supplierSku;
  final String productName;
  final String? variant;
  final bool isActive;
  final DateTime createdAt;
  final DateTime updatedAt;
  final double? currentCostGbp;

  Map<String, Object?> toMap() {
    return {
      'sku': sku.trim(),
      'supplier_sku': supplierSku?.trim(),
      'product_name': productName.trim(),
      'variant': variant?.trim(),
      'is_active': isActive ? 1 : 0,
      'created_at': createdAt.toUtc().toIso8601String(),
      'updated_at': updatedAt.toUtc().toIso8601String(),
    };
  }

  factory Product.fromMap(Map<String, Object?> map) {
    return Product(
      id: map['id'] as int,
      sku: map['sku'] as String,
      supplierSku: map['supplier_sku'] as String?,
      productName: map['product_name'] as String,
      variant: map['variant'] as String?,
      isActive: (map['is_active'] as int) == 1,
      createdAt: DateTime.parse(map['created_at'] as String),
      updatedAt: DateTime.parse(map['updated_at'] as String),
      currentCostGbp: map['current_cost_gbp'] == null
          ? null
          : (map['current_cost_gbp'] as num).toDouble(),
    );
  }
}
