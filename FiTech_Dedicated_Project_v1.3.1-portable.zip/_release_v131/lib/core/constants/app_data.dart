class AppData {
  static const shops = <String>[
    'Comfy Nest',
    'Rug House',
    'My Home Essential',
    'Comfy Castle',
    'OHS Essential',
    'MomZone Textile',
  ];
}
