import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseService {
  DatabaseService._();

  static final DatabaseService instance = DatabaseService._();
  static const _databaseName = 'fitech.db';
  static const _databaseVersion = 8;

  Database? _database;

  Future<Database> get database async {
    final current = _database;
    if (current != null) return current;

    final path = join(await getDatabasesPath(), _databaseName);
    _database = await openDatabase(
      path,
      version: _databaseVersion,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: _createSchema,
      onUpgrade: _upgradeSchema,
    );
    return _database!;
  }


  Future<void> _upgradeSchema(
    Database db,
    int oldVersion,
    int newVersion,
  ) async {
    if (oldVersion < 2) {
      await _createSupplierSchema(db);
    }
    if (oldVersion < 3) {
      await _createBankAndReturnsSchema(db);
    }
    if (oldVersion < 4) {
      await _createEnterpriseSchema(db);
    }
    if (oldVersion < 5) {
      await _createImportSchema(db);
    }
    if (oldVersion < 6) {
      await _createAutomationSchema(db);
    }
    if (oldVersion < 7) {
      await _createMarketplaceSchema(db);
    }
    if (oldVersion < 8) {
      await _repairImportIndexes(db);
    }
  }

  Future<void> _repairImportIndexes(DatabaseExecutor db) async {
    await db.execute('DROP INDEX IF EXISTS idx_import_batch_hash_type');
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_import_batch_hash_type '
      'ON import_batches(file_hash, import_type)',
    );
  }

  Future<void> _createSupplierSchema(DatabaseExecutor db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS suppliers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        display_name TEXT NOT NULL,
        payment_method TEXT NOT NULL DEFAULT 'Payoneer',
        opening_balance_gbp REAL NOT NULL DEFAULT 0,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS supplier_ledger_entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        supplier_id INTEGER NOT NULL,
        entry_date TEXT NOT NULL,
        type TEXT NOT NULL,
        reference_type TEXT,
        reference_id TEXT,
        description TEXT NOT NULL,
        debit_gbp REAL NOT NULL DEFAULT 0,
        credit_gbp REAL NOT NULL DEFAULT 0,
        notes TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY(supplier_id) REFERENCES suppliers(id)
      )
    ''');

    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_supplier_ledger_date '
      'ON supplier_ledger_entries(entry_date)',
    );
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_supplier_ledger_reference '
      'ON supplier_ledger_entries(reference_type, reference_id)',
    );

    final count = Sqflite.firstIntValue(
      await db.rawQuery('SELECT COUNT(*) FROM suppliers'),
    ) ?? 0;

    if (count == 0) {
      final now = DateTime.now().toUtc().toIso8601String();
      await db.insert('suppliers', {
        'display_name': 'Primary UK Supplier',
        'payment_method': 'Payoneer',
        'opening_balance_gbp': 0,
        'is_active': 1,
        'created_at': now,
        'updated_at': now,
      });
    }
  }


  Future<void> _createBankAndReturnsSchema(DatabaseExecutor db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS bank_ledger_entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entry_date TEXT NOT NULL,
        type TEXT NOT NULL,
        reference_type TEXT,
        reference_id TEXT,
        description TEXT NOT NULL,
        inflow_gbp REAL NOT NULL DEFAULT 0,
        outflow_gbp REAL NOT NULL DEFAULT 0,
        notes TEXT,
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS bank_reconciliations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        reconciliation_date TEXT NOT NULL,
        actual_bank_balance_gbp REAL NOT NULL,
        calculated_bank_balance_gbp REAL NOT NULL,
        difference_gbp REAL NOT NULL,
        notes TEXT,
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS returns (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        financial_order_id INTEGER NOT NULL,
        return_date TEXT NOT NULL,
        reason TEXT,
        customer_refund_gbp REAL NOT NULL DEFAULT 0,
        supplier_credit_gbp REAL NOT NULL DEFAULT 0,
        other_adjustment_gbp REAL NOT NULL DEFAULT 0,
        adjusted_profit_gbp REAL NOT NULL,
        notes TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY(financial_order_id) REFERENCES financial_orders(id)
      )
    ''');

    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_bank_ledger_date '
      'ON bank_ledger_entries(entry_date)',
    );
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_returns_order '
      'ON returns(financial_order_id)',
    );
  }





  Future<void> _createMarketplaceSchema(DatabaseExecutor db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS marketplace_accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        marketplace TEXT NOT NULL,
        account_name TEXT NOT NULL,
        shop_reference TEXT,
        region TEXT NOT NULL DEFAULT 'UK',
        connection_status TEXT NOT NULL DEFAULT 'notConfigured',
        auto_order_sync INTEGER NOT NULL DEFAULT 0,
        auto_tracking_sync INTEGER NOT NULL DEFAULT 0,
        auto_payout_sync INTEGER NOT NULL DEFAULT 0,
        last_tested_at TEXT,
        last_sync_at TEXT,
        notes TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS marketplace_credentials (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        account_id INTEGER NOT NULL,
        credential_key TEXT NOT NULL,
        credential_value TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY(account_id) REFERENCES marketplace_accounts(id)
          ON DELETE CASCADE,
        UNIQUE(account_id, credential_key)
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS marketplace_sync_jobs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        account_id INTEGER NOT NULL,
        job_type TEXT NOT NULL,
        direction TEXT NOT NULL,
        status TEXT NOT NULL,
        records_found INTEGER NOT NULL DEFAULT 0,
        records_processed INTEGER NOT NULL DEFAULT 0,
        records_failed INTEGER NOT NULL DEFAULT 0,
        message TEXT,
        started_at TEXT,
        completed_at TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY(account_id) REFERENCES marketplace_accounts(id)
          ON DELETE CASCADE
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS marketplace_order_links (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        account_id INTEGER NOT NULL,
        external_order_id TEXT NOT NULL,
        financial_order_id INTEGER,
        external_status TEXT,
        last_synced_at TEXT NOT NULL,
        FOREIGN KEY(account_id) REFERENCES marketplace_accounts(id)
          ON DELETE CASCADE,
        FOREIGN KEY(financial_order_id) REFERENCES financial_orders(id),
        UNIQUE(account_id, external_order_id)
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS marketplace_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        account_id INTEGER,
        event_type TEXT NOT NULL,
        message TEXT NOT NULL,
        level TEXT NOT NULL DEFAULT 'info',
        created_at TEXT NOT NULL,
        FOREIGN KEY(account_id) REFERENCES marketplace_accounts(id)
          ON DELETE SET NULL
      )
    ''');
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_marketplace_jobs_status '
      'ON marketplace_sync_jobs(status, created_at)',
    );
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_marketplace_logs_account_date '
      'ON marketplace_logs(account_id, created_at)',
    );
  }

  Future<void> _createAutomationSchema(DatabaseExecutor db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS business_tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT,
        priority TEXT NOT NULL DEFAULT 'medium',
        due_at TEXT,
        completed_at TEXT,
        is_completed INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS notification_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        notification_key TEXT NOT NULL,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        severity TEXT NOT NULL,
        source_type TEXT NOT NULL,
        source_reference TEXT,
        is_read INTEGER NOT NULL DEFAULT 0,
        is_dismissed INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS daily_close_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        close_date TEXT NOT NULL UNIQUE,
        orders_count INTEGER NOT NULL,
        earnings_gbp REAL NOT NULL,
        supplier_cost_gbp REAL NOT NULL,
        profit_gbp REAL NOT NULL,
        refunds_gbp REAL NOT NULL,
        supplier_balance_gbp REAL NOT NULL,
        bank_balance_gbp REAL NOT NULL,
        missing_tracking_count INTEGER NOT NULL,
        negative_profit_count INTEGER NOT NULL,
        notes TEXT,
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS automation_runs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        automation_key TEXT NOT NULL,
        status TEXT NOT NULL,
        result_message TEXT,
        started_at TEXT NOT NULL,
        completed_at TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS app_activity (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        activity_type TEXT NOT NULL,
        title TEXT NOT NULL,
        description TEXT,
        reference_type TEXT,
        reference_id TEXT,
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_tasks_due '
      'ON business_tasks(is_completed, due_at)',
    );
    await db.execute(
      'CREATE UNIQUE INDEX IF NOT EXISTS idx_notification_key '
      'ON notification_items(notification_key)',
    );
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_notifications_status '
      'ON notification_items(is_read, is_dismissed, created_at)',
    );
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_activity_date '
      'ON app_activity(created_at)',
    );
  }

  Future<void> _createImportSchema(DatabaseExecutor db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS import_batches (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        import_type TEXT NOT NULL,
        file_name TEXT NOT NULL,
        file_hash TEXT NOT NULL,
        total_rows INTEGER NOT NULL,
        valid_rows INTEGER NOT NULL,
        imported_rows INTEGER NOT NULL,
        skipped_rows INTEGER NOT NULL,
        failed_rows INTEGER NOT NULL,
        status TEXT NOT NULL,
        notes TEXT,
        created_at TEXT NOT NULL,
        completed_at TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS import_row_results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        batch_id INTEGER NOT NULL,
        row_number INTEGER NOT NULL,
        status TEXT NOT NULL,
        reference_value TEXT,
        message TEXT,
        raw_json TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY(batch_id) REFERENCES import_batches(id)
      )
    ''');

    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_import_batch_hash_type '
      'ON import_batches(file_hash, import_type)',
    );
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_import_row_batch '
      'ON import_row_results(batch_id, row_number)',
    );
  }

  Future<void> _createEnterpriseSchema(DatabaseExecutor db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS app_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT NOT NULL UNIQUE,
        display_name TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        last_login_at TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        user_email TEXT,
        action TEXT NOT NULL,
        entity_type TEXT,
        entity_id TEXT,
        old_value_json TEXT,
        new_value_json TEXT,
        device_info TEXT,
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS app_settings (
        setting_key TEXT PRIMARY KEY,
        setting_value TEXT,
        updated_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS sync_queue (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entity_type TEXT NOT NULL,
        entity_id TEXT NOT NULL,
        operation TEXT NOT NULL,
        payload_json TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        attempts INTEGER NOT NULL DEFAULT 0,
        last_error TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS sync_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        started_at TEXT NOT NULL,
        completed_at TEXT,
        status TEXT NOT NULL,
        uploaded_count INTEGER NOT NULL DEFAULT 0,
        downloaded_count INTEGER NOT NULL DEFAULT 0,
        error_message TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS backup_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        backup_path TEXT NOT NULL,
        backup_type TEXT NOT NULL,
        file_size_bytes INTEGER NOT NULL,
        verified INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_audit_logs_created '
      'ON audit_logs(created_at)',
    );
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_sync_queue_status '
      'ON sync_queue(status, created_at)',
    );

    final userCount = Sqflite.firstIntValue(
      await db.rawQuery('SELECT COUNT(*) FROM app_users'),
    ) ?? 0;

    if (userCount == 0) {
      final now = DateTime.now().toUtc().toIso8601String();
      await db.insert('app_users', {
        'email': 'owner@fitech.local',
        'display_name': 'FiTech Owner',
        'password_hash':
            '47f649f05333a889014903697566d2f1406eff2cd13aaffd7051f5e056b801e3',
        'role': 'owner',
        'is_active': 1,
        'created_at': now,
        'updated_at': now,
      });
    }

    final settingCount = Sqflite.firstIntValue(
      await db.rawQuery('SELECT COUNT(*) FROM app_settings'),
    ) ?? 0;

    if (settingCount == 0) {
      final now = DateTime.now().toUtc().toIso8601String();
      final defaults = <String, String>{
        'company_name': 'FiTech',
        'currency': 'GBP',
        'theme_mode': 'system',
        'session_timeout_minutes': '30',
        'biometric_enabled': 'false',
        'cloud_sync_enabled': 'false',
        'automatic_backup_enabled': 'false',
        'backup_frequency': 'weekly',
      };
      for (final entry in defaults.entries) {
        await db.insert('app_settings', {
          'setting_key': entry.key,
          'setting_value': entry.value,
          'updated_at': now,
        });
      }
    }
  }

  Future<void> _createSchema(Database db, int version) async {
    await db.transaction((txn) async {
      await txn.execute('''
        CREATE TABLE shops (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL UNIQUE,
          platform TEXT NOT NULL DEFAULT 'TikTok Shop',
          is_active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL
        )
      ''');

      await txn.execute('''
        CREATE TABLE products (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          sku TEXT NOT NULL UNIQUE,
          supplier_sku TEXT,
          product_name TEXT NOT NULL,
          variant TEXT,
          is_active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        )
      ''');

      await txn.execute('''
        CREATE TABLE product_cost_history (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          product_id INTEGER NOT NULL,
          unit_cost_gbp REAL NOT NULL CHECK(unit_cost_gbp >= 0),
          effective_from TEXT NOT NULL,
          effective_to TEXT,
          created_at TEXT NOT NULL,
          FOREIGN KEY(product_id) REFERENCES products(id)
        )
      ''');

      await txn.execute('''
        CREATE TABLE financial_orders (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          shop_id INTEGER NOT NULL,
          product_id INTEGER,
          tiktok_order_id TEXT NOT NULL UNIQUE,
          order_date TEXT NOT NULL,
          sku_snapshot TEXT NOT NULL,
          product_name_snapshot TEXT,
          variant_snapshot TEXT,
          quantity INTEGER NOT NULL DEFAULT 1 CHECK(quantity > 0),
          tiktok_net_earning_gbp REAL NOT NULL,
          supplier_unit_cost_snapshot_gbp REAL NOT NULL,
          supplier_total_cost_gbp REAL NOT NULL,
          manual_adjustment_gbp REAL NOT NULL DEFAULT 0,
          calculated_profit_gbp REAL NOT NULL,
          profit_margin_percent REAL,
          tracking_number TEXT,
          notes TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          deleted_at TEXT,
          FOREIGN KEY(shop_id) REFERENCES shops(id),
          FOREIGN KEY(product_id) REFERENCES products(id)
        )
      ''');

      await txn.execute(
        'CREATE INDEX idx_financial_orders_order_date ON financial_orders(order_date)',
      );
      await txn.execute(
        'CREATE INDEX idx_financial_orders_shop_id ON financial_orders(shop_id)',
      );
      await txn.execute(
        'CREATE INDEX idx_financial_orders_sku ON financial_orders(sku_snapshot)',
      );
      await txn.execute(
        'CREATE INDEX idx_financial_orders_tracking ON financial_orders(tracking_number)',
      );

      await _createSupplierSchema(txn);
      await _createBankAndReturnsSchema(txn);
      await _createEnterpriseSchema(txn);
      await _createImportSchema(txn);
      await _createAutomationSchema(txn);
      await _createMarketplaceSchema(txn);

      const shops = [
        'Comfy Nest',
        'Rug House',
        'My Home Essential',
        'Comfy Castle',
        'OHS Essential',
        'MomZone Textile',
      ];

      final now = DateTime.now().toUtc().toIso8601String();
      for (final shop in shops) {
        await txn.insert('shops', {
          'name': shop,
          'platform': 'TikTok Shop',
          'is_active': 1,
          'created_at': now,
        });
      }
    });
  }
}
