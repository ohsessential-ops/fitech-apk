import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

import '../database/database_service.dart';

class BackupService {
  BackupService({DatabaseService? databaseService})
      : _databaseService = databaseService ?? DatabaseService.instance;

  final DatabaseService _databaseService;

  Future<File> createLocalBackup() async {
    final db = await _databaseService.database;
    final databasesPath = await getDatabasesPath();
    final source = File(p.join(databasesPath, 'fitech.db'));

    await db.rawQuery('PRAGMA wal_checkpoint(FULL)');

    final documents = await getApplicationDocumentsDirectory();
    final backupDirectory = Directory(
      p.join(documents.path, 'FiTechBackups'),
    );
    await backupDirectory.create(recursive: true);

    final stamp = DateTime.now()
        .toUtc()
        .toIso8601String()
        .replaceAll(':', '-')
        .replaceAll('.', '-');
    final destination = File(
      p.join(backupDirectory.path, 'fitech_backup_$stamp.db'),
    );

    await source.copy(destination.path);
    final verified = await _verifySqliteFile(destination);

    final historyDb = await _databaseService.database;
    await historyDb.insert('backup_history', {
      'backup_path': destination.path,
      'backup_type': 'local',
      'file_size_bytes': await destination.length(),
      'verified': verified ? 1 : 0,
      'created_at': DateTime.now().toUtc().toIso8601String(),
    });

    return destination;
  }

  Future<bool> _verifySqliteFile(File file) async {
    if (!await file.exists() || await file.length() < 100) return false;
    final bytes = await file.openRead(0, 16).fold<List<int>>(
      <int>[],
      (buffer, chunk) => buffer..addAll(chunk),
    );
    final header = String.fromCharCodes(bytes);
    return header.startsWith('SQLite format 3');
  }
}
