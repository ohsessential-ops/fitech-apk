import 'package:intl/intl.dart';

class Money {
  static final _gbp = NumberFormat.currency(
    locale: 'en_GB',
    symbol: '£',
    decimalDigits: 2,
  );

  static String gbp(num value) => _gbp.format(value);
}
