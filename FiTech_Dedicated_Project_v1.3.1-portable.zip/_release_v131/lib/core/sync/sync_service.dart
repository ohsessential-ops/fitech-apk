import 'dart:convert';

import '../database/database_service.dart';

enum SyncQueueStatus { pending, processing, completed, failed }

class SyncService {
  SyncService({DatabaseService? databaseService})
      : _databaseService = databaseService ?? DatabaseService.instance;

  final DatabaseService _databaseService;

  Future<void> enqueue({
    required String entityType,
    required String entityId,
    required String operation,
    required Map<String, Object?> payload,
  }) async {
    final db = await _databaseService.database;
    final now = DateTime.now().toUtc().toIso8601String();
    await db.insert('sync_queue', {
      'entity_type': entityType,
      'entity_id': entityId,
      'operation': operation,
      'payload_json': jsonEncode(payload),
      'status': SyncQueueStatus.pending.name,
      'attempts': 0,
      'created_at': now,
      'updated_at': now,
    });
  }

  Future<int> pendingCount() async {
    final db = await _databaseService.database;
    final rows = await db.rawQuery(
      "SELECT COUNT(*) AS count FROM sync_queue WHERE status = 'pending'",
    );
    return (rows.first['count'] as num).toInt();
  }

  Future<List<Map<String, Object?>>> failedItems() async {
    final db = await _databaseService.database;
    return db.query(
      'sync_queue',
      where: 'status = ?',
      whereArgs: [SyncQueueStatus.failed.name],
      orderBy: 'updated_at DESC',
    );
  }
}
