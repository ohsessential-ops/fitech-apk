import '../../domain/models/app_user.dart';

enum AppPermission {
  viewDashboard,
  manageEntries,
  manageProducts,
  manageSupplier,
  manageBank,
  manageReturns,
  viewReports,
  exportReports,
  manageUsers,
  manageSettings,
  manageBackup,
  viewAuditLog,
}

class PermissionService {
  const PermissionService();

  Set<AppPermission> permissionsFor(UserRole role) {
    switch (role) {
      case UserRole.owner:
        return AppPermission.values.toSet();
      case UserRole.admin:
        return AppPermission.values.toSet()
          ..remove(AppPermission.manageBackup);
      case UserRole.manager:
        return {
          AppPermission.viewDashboard,
          AppPermission.manageEntries,
          AppPermission.manageProducts,
          AppPermission.manageSupplier,
          AppPermission.manageReturns,
          AppPermission.viewReports,
          AppPermission.exportReports,
        };
      case UserRole.accountant:
        return {
          AppPermission.viewDashboard,
          AppPermission.manageEntries,
          AppPermission.manageSupplier,
          AppPermission.manageBank,
          AppPermission.manageReturns,
          AppPermission.viewReports,
          AppPermission.exportReports,
        };
      case UserRole.staff:
        return {
          AppPermission.viewDashboard,
          AppPermission.manageEntries,
          AppPermission.manageProducts,
        };
      case UserRole.readOnly:
        return {
          AppPermission.viewDashboard,
          AppPermission.viewReports,
        };
    }
  }

  bool can(UserRole role, AppPermission permission) =>
      permissionsFor(role).contains(permission);
}
