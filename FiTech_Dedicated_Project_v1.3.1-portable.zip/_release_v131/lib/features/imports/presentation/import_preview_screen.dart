import 'package:flutter/material.dart';

import '../data/import_repository.dart';
import '../domain/import_models.dart';

class ImportPreviewScreen extends StatefulWidget {
  const ImportPreviewScreen({
    super.key,
    required this.preview,
  });

  final ImportPreview preview;

  @override
  State<ImportPreviewScreen> createState() => _ImportPreviewScreenState();
}

class _ImportPreviewScreenState extends State<ImportPreviewScreen> {
  bool importing = false;

  Future<void> execute() async {
    setState(() => importing = true);
    try {
      final result = await ImportRepository().execute(widget.preview);
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Import completed'),
          content: Text(
            'Imported: ${result.imported}\n'
            'Skipped: ${result.skipped}\n'
            'Failed: ${result.failed}',
          ),
          actions: [
            FilledButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Done'),
            ),
          ],
        ),
      );
      if (mounted) Navigator.of(context).pop();
    } finally {
      if (mounted) setState(() => importing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final preview = widget.preview;

    return Scaffold(
      appBar: AppBar(title: Text('Preview: ${preview.fileName}')),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.all(16),
        child: FilledButton.icon(
          onPressed:
              importing || preview.validRows == 0 ? null : execute,
          icon: const Icon(Icons.save_alt_outlined),
          label: Text(
            importing
                ? 'Importing…'
                : 'Import ${preview.validRows} valid rows',
          ),
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: _Metric(
                    label: 'Total',
                    value: preview.totalRows.toString(),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _Metric(
                    label: 'Importable',
                    value: preview.validRows.toString(),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _Metric(
                    label: 'Invalid',
                    value: preview.invalidRows.toString(),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
              itemCount: preview.rows.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, index) {
                final row = preview.rows[index];
                final isValid = row.canImport;
                return Card(
                  child: ExpansionTile(
                    leading: CircleAvatar(
                      child: Icon(
                        isValid ? Icons.check : Icons.close,
                      ),
                    ),
                    title: Text(
                      'Row ${row.rowNumber} • ${row.reference ?? 'No reference'}',
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    subtitle: Text(
                      row.messages.isEmpty
                          ? 'Ready to import'
                          : row.messages.join(' '),
                    ),
                    children: [
                      for (final entry in row.values.entries)
                        ListTile(
                          dense: true,
                          title: Text(entry.key),
                          trailing: Flexible(
                            child: Text(
                              entry.value,
                              textAlign: TextAlign.right,
                            ),
                          ),
                        ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _Metric extends StatelessWidget {
  const _Metric({
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Text(
              value,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
            ),
            Text(label),
          ],
        ),
      ),
    );
  }
}
