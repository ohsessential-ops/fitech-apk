import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../data/import_repository.dart';
import '../data/import_validation_service.dart';
import '../data/tabular_file_parser.dart';
import '../domain/import_models.dart';
import 'import_history_screen.dart';
import 'import_preview_screen.dart';

class ImportCenterScreen extends StatefulWidget {
  const ImportCenterScreen({super.key});

  @override
  State<ImportCenterScreen> createState() => _ImportCenterScreenState();
}

class _ImportCenterScreenState extends State<ImportCenterScreen> {
  ImportType selectedType = ImportType.orders;
  bool loading = false;

  Future<void> selectFile() async {
    setState(() => loading = true);
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['csv', 'xlsx'],
        withData: true,
      );
      if (result == null || result.files.single.bytes == null) return;

      final file = result.files.single;
      final parsed = const TabularFileParser().parse(
        fileName: file.name,
        bytes: file.bytes!,
      );

      final repository = ImportRepository();
      final duplicate = await repository.fileAlreadyImported(
        fileHash: parsed.hash,
        type: selectedType,
      );
      if (duplicate && mounted) {
        final proceed = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Previously imported file'),
            content: const Text(
              'This exact file has already been imported successfully. '
              'Importing it again may create duplicate activity.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () => Navigator.of(context).pop(true),
                child: const Text('Review anyway'),
              ),
            ],
          ),
        );
        if (proceed != true) return;
      }

      final preview = await ImportValidationService().validate(
        type: selectedType,
        fileName: file.name,
        parsed: parsed,
      );

      if (!mounted) return;
      await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => ImportPreviewScreen(preview: preview),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Import error: $error')),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  String description(ImportType type) {
    return switch (type) {
      ImportType.orders =>
        'Import TikTok order earnings, supplier costs and tracking.',
      ImportType.trackingUpdates =>
        'Match Order IDs and update many tracking numbers.',
      ImportType.supplierPayments =>
        'Import Payoneer supplier payments into both ledgers.',
    };
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bulk import centre'),
        actions: [
          IconButton(
            tooltip: 'Import history',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const ImportHistoryScreen(),
              ),
            ),
            icon: const Icon(Icons.history),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            'Choose import type',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w900,
                ),
          ),
          const SizedBox(height: 12),
          for (final type in ImportType.values) ...[
            Card(
              child: RadioListTile<ImportType>(
                value: type,
                groupValue: selectedType,
                onChanged: loading
                    ? null
                    : (value) {
                        if (value != null) {
                          setState(() => selectedType = value);
                        }
                      },
                title: Text(
                  switch (type) {
                    ImportType.orders => 'Orders',
                    ImportType.trackingUpdates => 'Tracking updates',
                    ImportType.supplierPayments => 'Supplier payments',
                  },
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                subtitle: Text(description(type)),
              ),
            ),
            const SizedBox(height: 8),
          ],
          const SizedBox(height: 12),
          SizedBox(
            height: 54,
            child: FilledButton.icon(
              onPressed: loading ? null : selectFile,
              icon: const Icon(Icons.upload_file_outlined),
              label: Text(loading ? 'Reading file…' : 'Select CSV or Excel'),
            ),
          ),
          const SizedBox(height: 16),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(18),
              child: Text(
                'FiTech validates every row before saving. Invalid rows are '
                'skipped, duplicate Order IDs are blocked, and every import '
                'is recorded in Import History.',
              ),
            ),
          ),
        ],
      ),
    );
  }
}
