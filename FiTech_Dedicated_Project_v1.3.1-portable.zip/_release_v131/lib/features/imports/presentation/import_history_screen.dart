import 'package:flutter/material.dart';

import '../data/import_repository.dart';

class ImportHistoryScreen extends StatelessWidget {
  const ImportHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Import history')),
      body: FutureBuilder<List<Map<String, Object?>>>(
        future: ImportRepository().history(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final items = snapshot.data!;
          if (items.isEmpty) {
            return const Center(child: Text('No imports recorded yet.'));
          }

          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final item = items[index];
              return Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.all(16),
                  leading: const CircleAvatar(
                    child: Icon(Icons.file_present_outlined),
                  ),
                  title: Text(
                    item['file_name'] as String,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: Text(
                    '${item['import_type']} • ${item['status']}\n'
                    'Imported ${item['imported_rows']} • '
                    'Skipped ${item['skipped_rows']} • '
                    'Failed ${item['failed_rows']}',
                  ),
                  isThreeLine: true,
                ),
              );
            },
          );
        },
      ),
    );
  }
}
