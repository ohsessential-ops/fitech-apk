import 'dart:convert';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:excel/excel.dart';

class ParsedTabularFile {
  const ParsedTabularFile({
    required this.headers,
    required this.rows,
    required this.hash,
  });

  final List<String> headers;
  final List<Map<String, String>> rows;
  final String hash;
}

class TabularFileParser {
  const TabularFileParser();

  ParsedTabularFile parse({
    required String fileName,
    required Uint8List bytes,
  }) {
    final extension = fileName.toLowerCase().split('.').last;
    final hash = sha256.convert(bytes).toString();

    if (extension == 'csv') {
      return _parseCsv(bytes, hash);
    }
    if (extension == 'xlsx') {
      return _parseXlsx(bytes, hash);
    }

    throw const FormatException('Only CSV and XLSX files are supported.');
  }

  ParsedTabularFile _parseCsv(Uint8List bytes, String hash) {
    final content = utf8.decode(bytes, allowMalformed: true);
    final lines = const LineSplitter().convert(content);
    if (lines.isEmpty) {
      throw const FormatException('The file is empty.');
    }

    final matrix = lines.map(_splitCsvLine).toList();
    final headers = matrix.first.map(_normaliseHeader).toList();
    final rows = <Map<String, String>>[];

    for (final values in matrix.skip(1)) {
      if (values.every((value) => value.trim().isEmpty)) continue;
      final row = <String, String>{};
      for (var index = 0; index < headers.length; index++) {
        row[headers[index]] =
            index < values.length ? values[index].trim() : '';
      }
      rows.add(row);
    }

    return ParsedTabularFile(headers: headers, rows: rows, hash: hash);
  }

  ParsedTabularFile _parseXlsx(Uint8List bytes, String hash) {
    final workbook = Excel.decodeBytes(bytes);
    if (workbook.tables.isEmpty) {
      throw const FormatException('The workbook has no worksheets.');
    }

    final table = workbook.tables.values.first;
    if (table.rows.isEmpty) {
      throw const FormatException('The worksheet is empty.');
    }

    final headers = table.rows.first
        .map((cell) => _normaliseHeader(cell?.value?.toString() ?? ''))
        .toList();

    final rows = <Map<String, String>>[];
    for (final cells in table.rows.skip(1)) {
      final values =
          cells.map((cell) => cell?.value?.toString().trim() ?? '').toList();
      if (values.every((value) => value.isEmpty)) continue;

      final row = <String, String>{};
      for (var index = 0; index < headers.length; index++) {
        row[headers[index]] =
            index < values.length ? values[index] : '';
      }
      rows.add(row);
    }

    return ParsedTabularFile(headers: headers, rows: rows, hash: hash);
  }

  List<String> _splitCsvLine(String line) {
    final values = <String>[];
    final buffer = StringBuffer();
    var quoted = false;

    for (var index = 0; index < line.length; index++) {
      final character = line[index];

      if (character == '"') {
        if (quoted &&
            index + 1 < line.length &&
            line[index + 1] == '"') {
          buffer.write('"');
          index++;
        } else {
          quoted = !quoted;
        }
      } else if (character == ',' && !quoted) {
        values.add(buffer.toString());
        buffer.clear();
      } else {
        buffer.write(character);
      }
    }

    values.add(buffer.toString());
    return values;
  }

  String _normaliseHeader(String value) {
    return value
        .trim()
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9]+'), '_')
        .replaceAll(RegExp(r'^_+|_+$'), '');
  }
}
