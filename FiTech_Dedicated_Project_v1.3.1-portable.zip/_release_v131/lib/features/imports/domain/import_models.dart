enum ImportType { orders, trackingUpdates, supplierPayments }

enum ImportRowStatus { valid, warning, invalid, imported, skipped, failed }

class ImportValidationRow {
  const ImportValidationRow({
    required this.rowNumber,
    required this.values,
    required this.status,
    required this.messages,
    this.reference,
  });

  final int rowNumber;
  final Map<String, String> values;
  final ImportRowStatus status;
  final List<String> messages;
  final String? reference;

  bool get canImport =>
      status == ImportRowStatus.valid ||
      status == ImportRowStatus.warning;
}

class ImportPreview {
  const ImportPreview({
    required this.type,
    required this.fileName,
    required this.fileHash,
    required this.headers,
    required this.rows,
  });

  final ImportType type;
  final String fileName;
  final String fileHash;
  final List<String> headers;
  final List<ImportValidationRow> rows;

  int get totalRows => rows.length;
  int get validRows => rows.where((row) => row.canImport).length;
  int get invalidRows => rows.where((row) => !row.canImport).length;
}

class ImportExecutionResult {
  const ImportExecutionResult({
    required this.batchId,
    required this.imported,
    required this.skipped,
    required this.failed,
  });

  final int batchId;
  final int imported;
  final int skipped;
  final int failed;
}
