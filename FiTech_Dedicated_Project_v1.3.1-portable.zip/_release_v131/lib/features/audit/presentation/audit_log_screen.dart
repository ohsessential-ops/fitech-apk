import 'package:flutter/material.dart';

import '../data/audit_repository.dart';

class AuditLogScreen extends StatelessWidget {
  const AuditLogScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final repository = AuditRepository();

    return Scaffold(
      appBar: AppBar(title: const Text('Audit log')),
      body: FutureBuilder<List<Map<String, Object?>>>(
        future: repository.recent(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final entries = snapshot.data!;
          if (entries.isEmpty) {
            return const Center(child: Text('No audit activity yet.'));
          }

          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: entries.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              final item = entries[index];
              return Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.all(16),
                  leading: const CircleAvatar(
                    child: Icon(Icons.history),
                  ),
                  title: Text(
                    item['action'] as String,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: Text(
                    [
                      item['user_email'] ?? 'System',
                      item['entity_type'],
                      item['entity_id'],
                      item['created_at'],
                    ].whereType<Object>().join(' • '),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
