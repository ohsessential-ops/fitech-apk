import 'dart:convert';

import '../../../core/database/database_service.dart';

class AuditRepository {
  AuditRepository({DatabaseService? databaseService})
      : _databaseService = databaseService ?? DatabaseService.instance;

  final DatabaseService _databaseService;

  Future<void> log({
    int? userId,
    String? userEmail,
    required String action,
    String? entityType,
    String? entityId,
    Object? oldValue,
    Object? newValue,
    String? deviceInfo,
  }) async {
    final db = await _databaseService.database;
    await db.insert('audit_logs', {
      'user_id': userId,
      'user_email': userEmail,
      'action': action,
      'entity_type': entityType,
      'entity_id': entityId,
      'old_value_json': oldValue == null ? null : jsonEncode(oldValue),
      'new_value_json': newValue == null ? null : jsonEncode(newValue),
      'device_info': deviceInfo,
      'created_at': DateTime.now().toUtc().toIso8601String(),
    });
  }

  Future<List<Map<String, Object?>>> recent({int limit = 300}) async {
    final db = await _databaseService.database;
    return db.query(
      'audit_logs',
      orderBy: 'created_at DESC, id DESC',
      limit: limit,
    );
  }
}
