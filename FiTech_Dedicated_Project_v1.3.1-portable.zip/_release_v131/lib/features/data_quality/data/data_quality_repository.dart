import '../../../core/database/database_service.dart';
import '../domain/data_quality_issue.dart';

class DataQualityRepository {
  DataQualityRepository({DatabaseService? databaseService})
      : _databaseService = databaseService ?? DatabaseService.instance;

  final DatabaseService _databaseService;

  Future<List<DataQualityIssue>> scan() async {
    final db = await _databaseService.database;
    final issues = <DataQualityIssue>[];

    Future<int> count(String sql) async {
      final rows = await db.rawQuery(sql);
      return (rows.first['count'] as num).toInt();
    }

    final missingTracking = await count('''
      SELECT COUNT(*) AS count
      FROM financial_orders
      WHERE deleted_at IS NULL
        AND (tracking_number IS NULL OR TRIM(tracking_number) = '')
    ''');
    if (missingTracking > 0) {
      issues.add(
        DataQualityIssue(
          type: DataQualityIssueType.missingTracking,
          title: 'Missing tracking numbers',
          description: 'Orders without tracking cannot be monitored properly.',
          count: missingTracking,
        ),
      );
    }

    final duplicateTracking = await count('''
      SELECT COUNT(*) AS count
      FROM (
        SELECT tracking_number
        FROM financial_orders
        WHERE deleted_at IS NULL
          AND tracking_number IS NOT NULL
          AND TRIM(tracking_number) <> ''
        GROUP BY tracking_number
        HAVING COUNT(*) > 1
      )
    ''');
    if (duplicateTracking > 0) {
      issues.add(
        DataQualityIssue(
          type: DataQualityIssueType.duplicateTracking,
          title: 'Duplicate tracking numbers',
          description: 'One tracking number is attached to multiple orders.',
          count: duplicateTracking,
        ),
      );
    }

    final missingSku = await count('''
      SELECT COUNT(*) AS count
      FROM financial_orders
      WHERE deleted_at IS NULL
        AND (sku_snapshot IS NULL OR TRIM(sku_snapshot) = '')
    ''');
    if (missingSku > 0) {
      issues.add(
        DataQualityIssue(
          type: DataQualityIssueType.missingSku,
          title: 'Missing SKU values',
          description: 'SKU data is required for product-level analysis.',
          count: missingSku,
        ),
      );
    }

    final zeroCost = await count('''
      SELECT COUNT(*) AS count
      FROM financial_orders
      WHERE deleted_at IS NULL
        AND supplier_total_cost_gbp <= 0
    ''');
    if (zeroCost > 0) {
      issues.add(
        DataQualityIssue(
          type: DataQualityIssueType.zeroSupplierCost,
          title: 'Missing or zero supplier cost',
          description: 'Profit may be overstated for these orders.',
          count: zeroCost,
        ),
      );
    }

    final negativeEarning = await count('''
      SELECT COUNT(*) AS count
      FROM financial_orders
      WHERE deleted_at IS NULL
        AND tiktok_net_earning_gbp < 0
    ''');
    if (negativeEarning > 0) {
      issues.add(
        DataQualityIssue(
          type: DataQualityIssueType.negativeEarning,
          title: 'Negative TikTok earnings',
          description: 'Verify refunds, reversals or incorrect manual entries.',
          count: negativeEarning,
        ),
      );
    }

    final suspiciousProfit = await count('''
      SELECT COUNT(*) AS count
      FROM financial_orders
      WHERE deleted_at IS NULL
        AND calculated_profit_gbp > tiktok_net_earning_gbp * 1.5
    ''');
    if (suspiciousProfit > 0) {
      issues.add(
        DataQualityIssue(
          type: DataQualityIssueType.suspiciousProfit,
          title: 'Unusually high profit',
          description: 'Review manual adjustments and supplier costs.',
          count: suspiciousProfit,
        ),
      );
    }

    return issues;
  }
}
