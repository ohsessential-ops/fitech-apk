enum DataQualityIssueType {
  missingTracking,
  duplicateTracking,
  missingSku,
  zeroSupplierCost,
  negativeEarning,
  suspiciousProfit,
}

class DataQualityIssue {
  const DataQualityIssue({
    required this.type,
    required this.title,
    required this.description,
    required this.count,
  });

  final DataQualityIssueType type;
  final String title;
  final String description;
  final int count;
}
