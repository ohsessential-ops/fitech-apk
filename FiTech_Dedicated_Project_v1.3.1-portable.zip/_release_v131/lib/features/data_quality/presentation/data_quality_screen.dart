import 'package:flutter/material.dart';

import '../data/data_quality_repository.dart';
import '../domain/data_quality_issue.dart';

class DataQualityScreen extends StatelessWidget {
  const DataQualityScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final repository = DataQualityRepository();

    return Scaffold(
      appBar: AppBar(title: const Text('Data quality centre')),
      body: FutureBuilder<List<DataQualityIssue>>(
        future: repository.scan(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final issues = snapshot.data!;
          if (issues.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.verified_outlined, size: 64),
                    SizedBox(height: 12),
                    Text(
                      'Your business data looks clean.',
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            );
          }

          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: issues.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              final issue = issues[index];
              return Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.all(18),
                  leading: CircleAvatar(
                    child: Text(issue.count.toString()),
                  ),
                  title: Text(
                    issue.title,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(issue.description),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
