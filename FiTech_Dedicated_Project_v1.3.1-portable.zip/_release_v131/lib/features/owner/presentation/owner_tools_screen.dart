import 'package:flutter/material.dart';

import '../../data_quality/presentation/data_quality_screen.dart';
import '../../automation/presentation/automation_hub_screen.dart';
import '../../insights/presentation/insights_screen.dart';
import '../../imports/presentation/import_center_screen.dart';
import '../../integrations/presentation/integration_center_screen.dart';
import '../../reports/presentation/reports_screen.dart';
import '../../system/presentation/system_center_screen.dart';

class OwnerToolsScreen extends StatelessWidget {
  const OwnerToolsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Owner tools')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _ToolCard(
            icon: Icons.auto_mode_outlined,
            title: 'Automation & productivity',
            subtitle: 'Alerts, tasks, daily close and owner checks',
            screen: const AutomationHubScreen(),
          ),
          const SizedBox(height: 10),
          _ToolCard(
            icon: Icons.hub_outlined,
            title: 'Marketplace integrations',
            subtitle: 'TikTok Shop, Amazon, eBay, Etsy and Wayfair',
            screen: const IntegrationCenterScreen(),
          ),
          const SizedBox(height: 10),
          _ToolCard(
            icon: Icons.upload_file_outlined,
            title: 'Bulk import centre',
            subtitle: 'Orders, tracking updates and supplier payments',
            screen: const ImportCenterScreen(),
          ),
          const SizedBox(height: 10),
          _ToolCard(
            icon: Icons.auto_awesome_outlined,
            title: 'Smart business insights',
            subtitle: 'Automatic warnings, trends and business opportunities',
            screen: const InsightsScreen(),
          ),
          const SizedBox(height: 10),
          _ToolCard(
            icon: Icons.fact_check_outlined,
            title: 'Data quality centre',
            subtitle: 'Find missing, duplicate and suspicious records',
            screen: const DataQualityScreen(),
          ),
          const SizedBox(height: 10),
          _ToolCard(
            icon: Icons.analytics_outlined,
            title: 'Reports and analytics',
            subtitle: 'Profit, shop and product performance',
            screen: const ReportsScreen(),
          ),
          const SizedBox(height: 10),
          _ToolCard(
            icon: Icons.security_outlined,
            title: 'System and security',
            subtitle: 'Backup, settings, audit and local security',
            screen: const SystemCenterScreen(),
          ),
        ],
      ),
    );
  }
}

class _ToolCard extends StatelessWidget {
  const _ToolCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.screen,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final Widget screen;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.all(18),
        leading: CircleAvatar(child: Icon(icon)),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => screen),
        ),
      ),
    );
  }
}
