import 'package:sqflite/sqflite.dart';

import '../../../core/database/database_service.dart';
import '../../../domain/models/product.dart';
import '../../../domain/models/product_cost.dart';

class DuplicateSkuException implements Exception {
  const DuplicateSkuException(this.sku);
  final String sku;
}

class ProductRepository {
  ProductRepository({DatabaseService? databaseService})
      : _databaseService = databaseService ?? DatabaseService.instance;

  final DatabaseService _databaseService;

  Future<int> createProduct({
    required String sku,
    String? supplierSku,
    required String productName,
    String? variant,
    required double openingCostGbp,
    required DateTime effectiveFrom,
  }) async {
    final db = await _databaseService.database;
    final now = DateTime.now();

    try {
      return await db.transaction((txn) async {
        final productId = await txn.insert(
          'products',
          Product(
            sku: sku,
            supplierSku: supplierSku,
            productName: productName,
            variant: variant,
            isActive: true,
            createdAt: now,
            updatedAt: now,
          ).toMap(),
          conflictAlgorithm: ConflictAlgorithm.abort,
        );

        await txn.insert(
          'product_cost_history',
          ProductCost(
            productId: productId,
            unitCostGbp: openingCostGbp,
            effectiveFrom: DateTime(
              effectiveFrom.year,
              effectiveFrom.month,
              effectiveFrom.day,
            ),
            createdAt: now,
          ).toMap(),
        );

        return productId;
      });
    } on DatabaseException catch (error) {
      if (error.isUniqueConstraintError()) {
        throw DuplicateSkuException(sku);
      }
      rethrow;
    }
  }

  Future<List<Product>> getProducts({String query = ''}) async {
    final db = await _databaseService.database;
    final term = '%${query.trim()}%';

    final rows = await db.rawQuery('''
      SELECT
        p.*,
        (
          SELECT c.unit_cost_gbp
          FROM product_cost_history c
          WHERE c.product_id = p.id
            AND c.effective_from <= ?
            AND (c.effective_to IS NULL OR c.effective_to > ?)
          ORDER BY c.effective_from DESC, c.id DESC
          LIMIT 1
        ) AS current_cost_gbp
      FROM products p
      WHERE p.is_active = 1
        AND (
          ? = '%%'
          OR p.sku LIKE ?
          OR COALESCE(p.supplier_sku, '') LIKE ?
          OR p.product_name LIKE ?
          OR COALESCE(p.variant, '') LIKE ?
        )
      ORDER BY p.product_name COLLATE NOCASE, p.sku COLLATE NOCASE
    ''', [
      DateTime.now().toIso8601String(),
      DateTime.now().toIso8601String(),
      term,
      term,
      term,
      term,
      term,
    ]);

    return rows.map(Product.fromMap).toList();
  }

  Future<Product?> findBySku(String sku) async {
    final db = await _databaseService.database;
    final rows = await db.rawQuery('''
      SELECT p.*, NULL AS current_cost_gbp
      FROM products p
      WHERE UPPER(p.sku) = UPPER(?) AND p.is_active = 1
      LIMIT 1
    ''', [sku.trim()]);

    if (rows.isEmpty) return null;
    return Product.fromMap(rows.first);
  }

  Future<double?> costForProductOnDate({
    required int productId,
    required DateTime date,
  }) async {
    final db = await _databaseService.database;
    final target = DateTime(date.year, date.month, date.day).toIso8601String();

    final rows = await db.rawQuery('''
      SELECT unit_cost_gbp
      FROM product_cost_history
      WHERE product_id = ?
        AND effective_from <= ?
        AND (effective_to IS NULL OR effective_to > ?)
      ORDER BY effective_from DESC, id DESC
      LIMIT 1
    ''', [productId, target, target]);

    if (rows.isEmpty) return null;
    return (rows.first['unit_cost_gbp'] as num).toDouble();
  }

  Future<List<ProductCost>> getCostHistory(int productId) async {
    final db = await _databaseService.database;
    final rows = await db.query(
      'product_cost_history',
      where: 'product_id = ?',
      whereArgs: [productId],
      orderBy: 'effective_from DESC, id DESC',
    );
    return rows.map(ProductCost.fromMap).toList();
  }

  Future<void> addCost({
    required int productId,
    required double unitCostGbp,
    required DateTime effectiveFrom,
  }) async {
    final db = await _databaseService.database;
    final start = DateTime(
      effectiveFrom.year,
      effectiveFrom.month,
      effectiveFrom.day,
    );

    await db.transaction((txn) async {
      final overlapping = await txn.rawQuery('''
        SELECT *
        FROM product_cost_history
        WHERE product_id = ?
          AND effective_from <= ?
          AND (effective_to IS NULL OR effective_to > ?)
        ORDER BY effective_from DESC, id DESC
        LIMIT 1
      ''', [productId, start.toIso8601String(), start.toIso8601String()]);

      if (overlapping.isNotEmpty) {
        final current = overlapping.first;
        final currentStart = DateTime.parse(current['effective_from'] as String);

        if (currentStart.isAtSameMomentAs(start)) {
          await txn.update(
            'product_cost_history',
            {
              'unit_cost_gbp': unitCostGbp,
              'created_at': DateTime.now().toUtc().toIso8601String(),
            },
            where: 'id = ?',
            whereArgs: [current['id']],
          );
          return;
        }

        await txn.update(
          'product_cost_history',
          {'effective_to': start.toIso8601String()},
          where: 'id = ?',
          whereArgs: [current['id']],
        );
      }

      final nextRows = await txn.rawQuery('''
        SELECT effective_from
        FROM product_cost_history
        WHERE product_id = ? AND effective_from > ?
        ORDER BY effective_from ASC
        LIMIT 1
      ''', [productId, start.toIso8601String()]);

      await txn.insert(
        'product_cost_history',
        ProductCost(
          productId: productId,
          unitCostGbp: unitCostGbp,
          effectiveFrom: start,
          effectiveTo: nextRows.isEmpty
              ? null
              : DateTime.parse(nextRows.first['effective_from'] as String),
          createdAt: DateTime.now(),
        ).toMap(),
      );
    });
  }
}
