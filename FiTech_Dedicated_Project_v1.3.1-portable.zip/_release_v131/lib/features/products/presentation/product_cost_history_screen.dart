import 'package:flutter/material.dart';

import '../../../core/utils/money.dart';
import '../../../domain/models/product.dart';
import '../../../domain/models/product_cost.dart';
import '../data/product_repository.dart';

class ProductCostHistoryScreen extends StatefulWidget {
  const ProductCostHistoryScreen({super.key, required this.product});

  final Product product;

  @override
  State<ProductCostHistoryScreen> createState() =>
      _ProductCostHistoryScreenState();
}

class _ProductCostHistoryScreenState extends State<ProductCostHistoryScreen> {
  final repository = ProductRepository();
  late Future<List<ProductCost>> history;

  @override
  void initState() {
    super.initState();
    history = repository.getCostHistory(widget.product.id!);
  }

  void refresh() {
    setState(() {
      history = repository.getCostHistory(widget.product.id!);
    });
  }

  Future<void> addCost() async {
    final costController = TextEditingController();
    var effectiveFrom = DateTime.now();

    final saved = await showDialog<bool>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: const Text('Add supplier cost'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: costController,
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'Unit cost',
                      prefixText: '£ ',
                    ),
                  ),
                  const SizedBox(height: 12),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Effective from'),
                    subtitle: Text(
                      effectiveFrom.toLocal().toString().split(' ').first,
                    ),
                    trailing: const Icon(Icons.calendar_month_outlined),
                    onTap: () async {
                      final picked = await showDatePicker(
                        context: context,
                        initialDate: effectiveFrom,
                        firstDate: DateTime(2020),
                        lastDate: DateTime.now().add(const Duration(days: 365)),
                      );
                      if (picked != null) {
                        setDialogState(() => effectiveFrom = picked);
                      }
                    },
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(false),
                  child: const Text('Cancel'),
                ),
                FilledButton(
                  onPressed: () async {
                    final value = double.tryParse(costController.text.trim());
                    if (value == null || value < 0) return;
                    await repository.addCost(
                      productId: widget.product.id!,
                      unitCostGbp: value,
                      effectiveFrom: effectiveFrom,
                    );
                    if (context.mounted) Navigator.of(context).pop(true);
                  },
                  child: const Text('Save cost'),
                ),
              ],
            );
          },
        );
      },
    );

    costController.dispose();
    if (saved == true) refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.product.sku)),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: addCost,
        icon: const Icon(Icons.add),
        label: const Text('Add cost'),
      ),
      body: FutureBuilder<List<ProductCost>>(
        future: history,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final items = snapshot.data!;
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
            children: [
              Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.all(18),
                  title: Text(
                    widget.product.productName,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: Text(
                    [
                      widget.product.sku,
                      if (widget.product.variant != null)
                        widget.product.variant!,
                      if (widget.product.supplierSku != null)
                        'Supplier SKU: ${widget.product.supplierSku}',
                    ].join(' • '),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'Cost history',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w800,
                    ),
              ),
              const SizedBox(height: 10),
              for (final item in items) ...[
                Card(
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(16),
                    title: Text(
                      Money.gbp(item.unitCostGbp),
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    subtitle: Text(
                      'From ${item.effectiveFrom.toLocal().toString().split(' ').first}'
                      '${item.effectiveTo == null ? ' • Current' : ' until ${item.effectiveTo!.toLocal().toString().split(' ').first}'}',
                    ),
                  ),
                ),
                const SizedBox(height: 10),
              ],
            ],
          );
        },
      ),
    );
  }
}
