import 'package:flutter/material.dart';

import '../data/product_repository.dart';

class AddProductScreen extends StatefulWidget {
  const AddProductScreen({super.key});

  @override
  State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  final formKey = GlobalKey<FormState>();
  final repository = ProductRepository();

  final sku = TextEditingController();
  final supplierSku = TextEditingController();
  final productName = TextEditingController();
  final variant = TextEditingController();
  final openingCost = TextEditingController();
  DateTime effectiveFrom = DateTime.now();
  bool saving = false;

  String? requiredField(String? value) =>
      value == null || value.trim().isEmpty ? 'Required' : null;

  Future<void> save() async {
    if (!formKey.currentState!.validate()) return;
    setState(() => saving = true);

    try {
      await repository.createProduct(
        sku: sku.text.trim(),
        supplierSku:
            supplierSku.text.trim().isEmpty ? null : supplierSku.text.trim(),
        productName: productName.text.trim(),
        variant: variant.text.trim().isEmpty ? null : variant.text.trim(),
        openingCostGbp: double.parse(openingCost.text.trim()),
        effectiveFrom: effectiveFrom,
      );

      if (!mounted) return;
      Navigator.of(context).pop(true);
    } on DuplicateSkuException {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('This SKU already exists.')),
      );
      setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add product')),
      body: Form(
        key: formKey,
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            TextFormField(
              controller: sku,
              validator: requiredField,
              decoration: const InputDecoration(labelText: 'Internal SKU'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: supplierSku,
              decoration:
                  const InputDecoration(labelText: 'Supplier SKU (optional)'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: productName,
              validator: requiredField,
              decoration: const InputDecoration(labelText: 'Product name'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: variant,
              decoration:
                  const InputDecoration(labelText: 'Variant (optional)'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: openingCost,
              validator: (value) {
                final number = double.tryParse(value ?? '');
                return number == null || number < 0
                    ? 'Enter a valid cost'
                    : null;
              },
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: 'Opening supplier cost',
                prefixText: '£ ',
              ),
            ),
            const SizedBox(height: 12),
            ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 8),
              title: const Text('Cost effective from'),
              subtitle: Text(
                effectiveFrom.toLocal().toString().split(' ').first,
              ),
              trailing: const Icon(Icons.calendar_month_outlined),
              onTap: () async {
                final picked = await showDatePicker(
                  context: context,
                  initialDate: effectiveFrom,
                  firstDate: DateTime(2020),
                  lastDate: DateTime.now().add(const Duration(days: 365)),
                );
                if (picked != null) {
                  setState(() => effectiveFrom = picked);
                }
              },
            ),
            const SizedBox(height: 20),
            SizedBox(
              height: 54,
              child: FilledButton(
                onPressed: saving ? null : save,
                child: Text(saving ? 'Saving…' : 'Create product'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
