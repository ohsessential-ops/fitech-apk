import 'package:flutter/material.dart';

import '../../../core/utils/money.dart';
import '../../../domain/models/product.dart';
import '../data/product_repository.dart';
import 'add_product_screen.dart';
import 'product_cost_history_screen.dart';

class ProductsScreen extends StatefulWidget {
  const ProductsScreen({super.key});

  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  final repository = ProductRepository();
  final searchController = TextEditingController();
  late Future<List<Product>> products;

  @override
  void initState() {
    super.initState();
    products = repository.getProducts();
  }

  void refresh() {
    setState(() {
      products = repository.getProducts(query: searchController.text);
    });
  }

  Future<void> addProduct() async {
    final saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => const AddProductScreen()),
    );
    if (saved == true) refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Products')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: addProduct,
        icon: const Icon(Icons.add),
        label: const Text('Add product'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: TextField(
              controller: searchController,
              onSubmitted: (_) => refresh(),
              decoration: InputDecoration(
                hintText: 'Search SKU, product or variant',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: IconButton(
                  onPressed: refresh,
                  icon: const Icon(Icons.arrow_forward),
                ),
              ),
            ),
          ),
          Expanded(
            child: FutureBuilder<List<Product>>(
              future: products,
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final items = snapshot.data!;
                if (items.isEmpty) {
                  return const Center(child: Text('No products found.'));
                }

                return ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 100),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, index) {
                    final product = items[index];
                    return Card(
                      child: ListTile(
                        contentPadding: const EdgeInsets.all(16),
                        leading: const CircleAvatar(
                          child: Icon(Icons.inventory_2_outlined),
                        ),
                        title: Text(
                          product.productName,
                          style: const TextStyle(fontWeight: FontWeight.w800),
                        ),
                        subtitle: Text(
                          [
                            product.sku,
                            if (product.variant != null) product.variant!,
                            if (product.supplierSku != null)
                              'Supplier: ${product.supplierSku}',
                          ].join(' • '),
                        ),
                        trailing: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              product.currentCostGbp == null
                                  ? 'No cost'
                                  : Money.gbp(product.currentCostGbp!),
                              style:
                                  const TextStyle(fontWeight: FontWeight.w800),
                            ),
                            const Text('Current cost'),
                          ],
                        ),
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => ProductCostHistoryScreen(
                              product: product,
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
