class CostPeriodService {
  const CostPeriodService();

  DateTime normalizedDate(DateTime value) =>
      DateTime(value.year, value.month, value.day);

  bool appliesToDate({
    required DateTime targetDate,
    required DateTime effectiveFrom,
    DateTime? effectiveTo,
  }) {
    final target = normalizedDate(targetDate);
    final start = normalizedDate(effectiveFrom);
    final end = effectiveTo == null ? null : normalizedDate(effectiveTo);

    return !target.isBefore(start) && (end == null || target.isBefore(end));
  }
}
