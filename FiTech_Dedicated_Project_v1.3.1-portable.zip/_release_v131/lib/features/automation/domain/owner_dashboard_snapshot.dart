class OwnerDashboardSnapshot {
  const OwnerDashboardSnapshot({
    required this.todayOrders,
    required this.todayProfit,
    required this.weekProfit,
    required this.monthProfit,
    required this.pendingTasks,
    required this.unreadNotifications,
    required this.missingTracking,
    required this.negativeProfitOrders,
  });

  final int todayOrders;
  final double todayProfit;
  final double weekProfit;
  final double monthProfit;
  final int pendingTasks;
  final int unreadNotifications;
  final int missingTracking;
  final int negativeProfitOrders;
}
