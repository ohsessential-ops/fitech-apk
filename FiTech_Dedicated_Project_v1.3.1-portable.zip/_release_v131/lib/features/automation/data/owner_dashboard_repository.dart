import '../../../core/database/database_service.dart';
import '../../notifications/data/notification_repository.dart';
import '../../tasks/data/task_repository.dart';
import '../domain/owner_dashboard_snapshot.dart';

class OwnerDashboardRepository {
  OwnerDashboardRepository({DatabaseService? databaseService})
      : _databaseService = databaseService ?? DatabaseService.instance;

  final DatabaseService _databaseService;

  Future<OwnerDashboardSnapshot> load() async {
    final db = await _databaseService.database;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final weekStart = today.subtract(Duration(days: now.weekday - 1));
    final monthStart = DateTime(now.year, now.month, 1);

    Future<Map<String, Object?>> orderStats(DateTime start) async {
      final rows = await db.rawQuery('''
        SELECT COUNT(*) AS orders,
               COALESCE(SUM(calculated_profit_gbp), 0) AS profit
        FROM financial_orders
        WHERE deleted_at IS NULL AND order_date >= ?
      ''', [start.toIso8601String()]);
      return rows.first;
    }

    final todayStats = await orderStats(today);
    final weekStats = await orderStats(weekStart);
    final monthStats = await orderStats(monthStart);

    final issueRows = await db.rawQuery('''
      SELECT
        COALESCE(SUM(
          CASE WHEN tracking_number IS NULL OR TRIM(tracking_number) = ''
          THEN 1 ELSE 0 END
        ), 0) AS missing_tracking,
        COALESCE(SUM(
          CASE WHEN calculated_profit_gbp < 0 THEN 1 ELSE 0 END
        ), 0) AS negative_profit
      FROM financial_orders
      WHERE deleted_at IS NULL
    ''');

    return OwnerDashboardSnapshot(
      todayOrders: (todayStats['orders'] as num).toInt(),
      todayProfit: (todayStats['profit'] as num).toDouble(),
      weekProfit: (weekStats['profit'] as num).toDouble(),
      monthProfit: (monthStats['profit'] as num).toDouble(),
      pendingTasks: await TaskRepository().pendingCount(),
      unreadNotifications: await NotificationRepository().unreadCount(),
      missingTracking:
          (issueRows.first['missing_tracking'] as num).toInt(),
      negativeProfitOrders:
          (issueRows.first['negative_profit'] as num).toInt(),
    );
  }

  Future<List<Map<String, Object?>>> recentActivity() async {
    final db = await _databaseService.database;
    return db.query(
      'app_activity',
      orderBy: 'created_at DESC',
      limit: 20,
    );
  }
}
