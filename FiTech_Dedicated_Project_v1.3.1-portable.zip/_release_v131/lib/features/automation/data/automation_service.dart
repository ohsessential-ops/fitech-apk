import '../../../core/database/database_service.dart';
import '../../notifications/data/notification_repository.dart';
import '../../notifications/domain/business_notification.dart';

class AutomationService {
  AutomationService({
    DatabaseService? databaseService,
    NotificationRepository? notificationRepository,
  })  : _databaseService = databaseService ?? DatabaseService.instance,
        _notificationRepository =
            notificationRepository ?? NotificationRepository();

  final DatabaseService _databaseService;
  final NotificationRepository _notificationRepository;

  Future<void> runOwnerChecks() async {
    final db = await _databaseService.database;
    final started = DateTime.now().toUtc().toIso8601String();
    final runId = await db.insert('automation_runs', {
      'automation_key': 'owner_checks',
      'status': 'running',
      'started_at': started,
    });

    try {
      await _checkMissingTracking();
      await _checkNegativeProfit();
      await _checkMissingCost();
      await _checkSupplierBalance();
      await _checkBankBalance();
      await _checkOverdueTasks();
      await _checkBackupAge();

      await db.update(
        'automation_runs',
        {
          'status': 'completed',
          'result_message': 'Owner checks completed successfully.',
          'completed_at': DateTime.now().toUtc().toIso8601String(),
        },
        where: 'id = ?',
        whereArgs: [runId],
      );
    } catch (error) {
      await db.update(
        'automation_runs',
        {
          'status': 'failed',
          'result_message': error.toString(),
          'completed_at': DateTime.now().toUtc().toIso8601String(),
        },
        where: 'id = ?',
        whereArgs: [runId],
      );
      rethrow;
    }
  }

  Future<void> _checkMissingTracking() async {
    final db = await _databaseService.database;
    final rows = await db.rawQuery('''
      SELECT COUNT(*) AS count
      FROM financial_orders
      WHERE deleted_at IS NULL
        AND (tracking_number IS NULL OR TRIM(tracking_number) = '')
    ''');
    final count = (rows.first['count'] as num).toInt();
    if (count > 0) {
      await _notificationRepository.upsert(
        key: 'missing_tracking',
        title: '$count orders need tracking',
        message: 'Add tracking numbers to reduce delivery risk.',
        severity: NotificationSeverity.warning,
        sourceType: 'orders',
      );
    } else {
      await _notificationRepository.dismissByKey('missing_tracking');
    }
  }

  Future<void> _checkNegativeProfit() async {
    final db = await _databaseService.database;
    final rows = await db.rawQuery('''
      SELECT COUNT(*) AS count,
             COALESCE(SUM(calculated_profit_gbp), 0) AS loss
      FROM financial_orders
      WHERE deleted_at IS NULL
        AND calculated_profit_gbp < 0
    ''');
    final count = (rows.first['count'] as num).toInt();
    final loss = (rows.first['loss'] as num).toDouble();
    if (count > 0) {
      await _notificationRepository.upsert(
        key: 'negative_profit',
        title: '$count loss-making orders',
        message: 'Combined result: £${loss.toStringAsFixed(2)}.',
        severity: NotificationSeverity.critical,
        sourceType: 'profit',
      );
    } else {
      await _notificationRepository.dismissByKey('negative_profit');
    }
  }

  Future<void> _checkMissingCost() async {
    final db = await _databaseService.database;
    final rows = await db.rawQuery('''
      SELECT COUNT(*) AS count
      FROM financial_orders
      WHERE deleted_at IS NULL
        AND supplier_total_cost_gbp <= 0
    ''');
    final count = (rows.first['count'] as num).toInt();
    if (count > 0) {
      await _notificationRepository.upsert(
        key: 'missing_supplier_cost',
        title: '$count orders have zero supplier cost',
        message: 'Profit could be overstated until costs are corrected.',
        severity: NotificationSeverity.critical,
        sourceType: 'data_quality',
      );
    } else {
      await _notificationRepository.dismissByKey('missing_supplier_cost');
    }
  }

  Future<void> _checkSupplierBalance() async {
    final db = await _databaseService.database;
    final rows = await db.rawQuery('''
      SELECT COALESCE(SUM(debit_gbp), 0)
             - COALESCE(SUM(credit_gbp), 0) AS balance
      FROM supplier_ledger_entries
    ''');
    final balance = (rows.first['balance'] as num).toDouble();
    if (balance > 0) {
      await _notificationRepository.upsert(
        key: 'supplier_balance_due',
        title: 'Supplier balance is due',
        message: 'Current payable balance: £${balance.toStringAsFixed(2)}.',
        severity: balance >= 1000
            ? NotificationSeverity.critical
            : NotificationSeverity.warning,
        sourceType: 'supplier',
      );
    } else {
      await _notificationRepository.dismissByKey('supplier_balance_due');
    }
  }

  Future<void> _checkBankBalance() async {
    final db = await _databaseService.database;
    final rows = await db.rawQuery('''
      SELECT COALESCE(SUM(inflow_gbp), 0)
             - COALESCE(SUM(outflow_gbp), 0) AS balance
      FROM bank_ledger_entries
    ''');
    final balance = (rows.first['balance'] as num).toDouble();
    if (balance < 0) {
      await _notificationRepository.upsert(
        key: 'negative_bank_balance',
        title: 'Bank ledger is negative',
        message: 'Current ledger balance: £${balance.toStringAsFixed(2)}.',
        severity: NotificationSeverity.critical,
        sourceType: 'bank',
      );
    } else {
      await _notificationRepository.dismissByKey('negative_bank_balance');
    }
  }

  Future<void> _checkOverdueTasks() async {
    final db = await _databaseService.database;
    final now = DateTime.now().toUtc().toIso8601String();
    final rows = await db.rawQuery('''
      SELECT COUNT(*) AS count
      FROM business_tasks
      WHERE is_completed = 0
        AND due_at IS NOT NULL
        AND due_at < ?
    ''', [now]);
    final count = (rows.first['count'] as num).toInt();
    if (count > 0) {
      await _notificationRepository.upsert(
        key: 'overdue_tasks',
        title: '$count overdue business tasks',
        message: 'Review your task manager and update priorities.',
        severity: NotificationSeverity.warning,
        sourceType: 'tasks',
      );
    } else {
      await _notificationRepository.dismissByKey('overdue_tasks');
    }
  }

  Future<void> _checkBackupAge() async {
    final db = await _databaseService.database;
    final rows = await db.query(
      'backup_history',
      columns: ['created_at'],
      where: 'status = ?',
      whereArgs: ['completed'],
      orderBy: 'created_at DESC',
      limit: 1,
    );

    var needsBackup = rows.isEmpty;
    if (rows.isNotEmpty) {
      final lastBackup = DateTime.parse(rows.first['created_at'] as String);
      needsBackup =
          DateTime.now().toUtc().difference(lastBackup.toUtc()).inDays >= 1;
    }

    if (needsBackup) {
      await _notificationRepository.upsert(
        key: 'backup_due',
        title: 'Daily backup is due',
        message: 'Create a verified local backup from System Centre.',
        severity: NotificationSeverity.info,
        sourceType: 'backup',
      );
    } else {
      await _notificationRepository.dismissByKey('backup_due');
    }
  }
}
