import 'package:flutter/material.dart';

import '../../daily_close/presentation/daily_close_screen.dart';
import '../../notifications/presentation/notification_center_screen.dart';
import '../../system/presentation/system_center_screen.dart';
import '../../tasks/presentation/task_manager_screen.dart';
import '../data/automation_service.dart';
import '../data/owner_dashboard_repository.dart';
import '../domain/owner_dashboard_snapshot.dart';

class AutomationHubScreen extends StatefulWidget {
  const AutomationHubScreen({super.key});

  @override
  State<AutomationHubScreen> createState() => _AutomationHubScreenState();
}

class _AutomationHubScreenState extends State<AutomationHubScreen> {
  bool running = false;

  Future<void> runChecks() async {
    setState(() => running = true);
    try {
      await AutomationService().runOwnerChecks();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Automation checks completed.')),
        );
        setState(() {});
      }
    } finally {
      if (mounted) setState(() => running = false);
    }
  }

  Widget metric(String label, String value, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon),
            const SizedBox(height: 6),
            Text(
              value,
              style: const TextStyle(
                fontWeight: FontWeight.w900,
                fontSize: 20,
              ),
            ),
            Text(label, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final repository = OwnerDashboardRepository();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Automation & productivity'),
        actions: [
          IconButton(
            tooltip: 'Run owner checks',
            onPressed: running ? null : runChecks,
            icon: const Icon(Icons.play_circle_outline),
          ),
        ],
      ),
      body: FutureBuilder<OwnerDashboardSnapshot>(
        future: repository.load(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final data = snapshot.data!;

          return RefreshIndicator(
            onRefresh: runChecks,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  childAspectRatio: 1.55,
                  children: [
                    metric(
                      'Today orders',
                      data.todayOrders.toString(),
                      Icons.shopping_bag_outlined,
                    ),
                    metric(
                      'Today profit',
                      '£${data.todayProfit.toStringAsFixed(2)}',
                      Icons.today_outlined,
                    ),
                    metric(
                      'Week profit',
                      '£${data.weekProfit.toStringAsFixed(2)}',
                      Icons.date_range_outlined,
                    ),
                    metric(
                      'Month profit',
                      '£${data.monthProfit.toStringAsFixed(2)}',
                      Icons.calendar_month_outlined,
                    ),
                    metric(
                      'Pending tasks',
                      data.pendingTasks.toString(),
                      Icons.task_alt_outlined,
                    ),
                    metric(
                      'Unread alerts',
                      data.unreadNotifications.toString(),
                      Icons.notifications_outlined,
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                _HubCard(
                  icon: Icons.notifications_active_outlined,
                  title: 'Notification centre',
                  subtitle:
                      '${data.unreadNotifications} unread alerts and reminders',
                  screen: const NotificationCenterScreen(),
                ),
                const SizedBox(height: 8),
                _HubCard(
                  icon: Icons.task_outlined,
                  title: 'Business task manager',
                  subtitle: '${data.pendingTasks} tasks pending',
                  screen: const TaskManagerScreen(),
                ),
                const SizedBox(height: 8),
                const _HubCard(
                  icon: Icons.lock_clock_outlined,
                  title: 'Daily business close',
                  subtitle: 'Save an end-of-day financial snapshot',
                  screen: DailyCloseScreen(),
                ),
                const SizedBox(height: 8),
                const _HubCard(
                  icon: Icons.backup_outlined,
                  title: 'Backup and system',
                  subtitle: 'Create and verify your local backup',
                  screen: SystemCenterScreen(),
                ),
                const SizedBox(height: 20),
                Text(
                  'Recent activity',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w900,
                      ),
                ),
                const SizedBox(height: 8),
                FutureBuilder<List<Map<String, Object?>>>(
                  future: repository.recentActivity(),
                  builder: (context, activitySnapshot) {
                    if (!activitySnapshot.hasData) {
                      return const LinearProgressIndicator();
                    }
                    if (activitySnapshot.data!.isEmpty) {
                      return const Card(
                        child: Padding(
                          padding: EdgeInsets.all(18),
                          child: Text('No recent activity recorded yet.'),
                        ),
                      );
                    }
                    return Column(
                      children: activitySnapshot.data!
                          .map(
                            (item) => Card(
                              child: ListTile(
                                leading: const Icon(Icons.history),
                                title: Text(item['title'] as String),
                                subtitle: Text(
                                  item['description'] as String? ?? '',
                                ),
                              ),
                            ),
                          )
                          .toList(),
                    );
                  },
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _HubCard extends StatelessWidget {
  const _HubCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.screen,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final Widget screen;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.all(18),
        leading: CircleAvatar(child: Icon(icon)),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w900),
        ),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => screen),
        ),
      ),
    );
  }
}
