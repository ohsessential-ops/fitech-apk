import 'dart:async';

import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';
import '../../../shared/widgets/empty_state.dart';
import '../data/global_search_repository.dart';
import '../domain/global_search_result.dart';

class GlobalSearchScreen extends StatefulWidget {
  const GlobalSearchScreen({super.key});

  @override
  State<GlobalSearchScreen> createState() => _GlobalSearchScreenState();
}

class _GlobalSearchScreenState extends State<GlobalSearchScreen> {
  final controller = TextEditingController();
  final repository = GlobalSearchRepository();
  Timer? debounce;
  GlobalSearchType? selectedType;
  List<GlobalSearchResult> results = [];
  bool loading = false;

  @override
  void dispose() {
    debounce?.cancel();
    controller.dispose();
    super.dispose();
  }

  void changed(String value) {
    debounce?.cancel();
    debounce = Timer(const Duration(milliseconds: 280), runSearch);
  }

  Future<void> runSearch() async {
    final query = controller.text.trim();
    if (query.isEmpty) {
      setState(() {
        results = [];
        loading = false;
      });
      return;
    }

    setState(() => loading = true);
    final data = await repository.search(query, type: selectedType);
    if (!mounted) return;
    setState(() {
      results = data;
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Universal search')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: TextField(
              controller: controller,
              autofocus: true,
              onChanged: changed,
              onSubmitted: (_) => runSearch(),
              decoration: InputDecoration(
                hintText: 'Order ID, SKU, product or tracking number',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: controller.text.isEmpty
                    ? null
                    : IconButton(
                        onPressed: () {
                          controller.clear();
                          runSearch();
                        },
                        icon: const Icon(Icons.close),
                      ),
              ),
            ),
          ),
          SizedBox(
            height: 46,
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              scrollDirection: Axis.horizontal,
              children: [
                ChoiceChip(
                  label: const Text('All'),
                  selected: selectedType == null,
                  onSelected: (_) {
                    setState(() => selectedType = null);
                    runSearch();
                  },
                ),
                const SizedBox(width: 8),
                ChoiceChip(
                  label: const Text('Orders'),
                  selected: selectedType == GlobalSearchType.order,
                  onSelected: (_) {
                    setState(() => selectedType = GlobalSearchType.order);
                    runSearch();
                  },
                ),
                const SizedBox(width: 8),
                ChoiceChip(
                  label: const Text('Products'),
                  selected: selectedType == GlobalSearchType.product,
                  onSelected: (_) {
                    setState(() => selectedType = GlobalSearchType.product);
                    runSearch();
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: loading
                ? const Center(child: CircularProgressIndicator())
                : controller.text.trim().isEmpty
                    ? const EmptyState(
                        icon: Icons.manage_search_outlined,
                        title: 'Find anything quickly',
                        message:
                            'Search orders, products, SKUs and tracking numbers from one place.',
                      )
                    : results.isEmpty
                        ? const EmptyState(
                            icon: Icons.search_off_outlined,
                            title: 'No matching records',
                            message:
                                'Check the spelling or try a shorter search term.',
                          )
                        : ListView.separated(
                            padding: const EdgeInsets.all(16),
                            itemCount: results.length,
                            separatorBuilder: (_, __) =>
                                const SizedBox(height: 8),
                            itemBuilder: (context, index) {
                              final item = results[index];
                              return Card(
                                child: ListTile(
                                  contentPadding: const EdgeInsets.all(16),
                                  leading: CircleAvatar(
                                    backgroundColor: AppTheme.sky,
                                    foregroundColor: AppTheme.blue,
                                    child: Icon(
                                      item.type == GlobalSearchType.order
                                          ? Icons.receipt_long_outlined
                                          : Icons.inventory_2_outlined,
                                    ),
                                  ),
                                  title: Text(
                                    item.title,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                  subtitle: Text(item.subtitle),
                                  trailing: item.trailing == null
                                      ? null
                                      : Text(
                                          item.trailing!,
                                          style: const TextStyle(
                                            color: AppTheme.navy,
                                            fontWeight: FontWeight.w900,
                                          ),
                                        ),
                                ),
                              );
                            },
                          ),
          ),
        ],
      ),
    );
  }
}
