enum GlobalSearchType { order, product }

class GlobalSearchResult {
  const GlobalSearchResult({
    required this.type,
    required this.title,
    required this.subtitle,
    required this.reference,
    this.trailing,
  });

  final GlobalSearchType type;
  final String title;
  final String subtitle;
  final String reference;
  final String? trailing;
}
