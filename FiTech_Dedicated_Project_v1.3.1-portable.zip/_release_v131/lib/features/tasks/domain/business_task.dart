enum TaskPriority { low, medium, high, urgent }

class BusinessTask {
  const BusinessTask({
    this.id,
    required this.title,
    this.description,
    this.priority = TaskPriority.medium,
    this.dueAt,
    this.completedAt,
    this.isCompleted = false,
    required this.createdAt,
    required this.updatedAt,
  });

  final int? id;
  final String title;
  final String? description;
  final TaskPriority priority;
  final DateTime? dueAt;
  final DateTime? completedAt;
  final bool isCompleted;
  final DateTime createdAt;
  final DateTime updatedAt;

  bool get isOverdue =>
      !isCompleted &&
      dueAt != null &&
      dueAt!.isBefore(DateTime.now());

  factory BusinessTask.fromMap(Map<String, Object?> map) {
    return BusinessTask(
      id: map['id'] as int?,
      title: map['title'] as String,
      description: map['description'] as String?,
      priority: TaskPriority.values.firstWhere(
        (value) => value.name == map['priority'],
        orElse: () => TaskPriority.medium,
      ),
      dueAt: map['due_at'] == null
          ? null
          : DateTime.parse(map['due_at'] as String),
      completedAt: map['completed_at'] == null
          ? null
          : DateTime.parse(map['completed_at'] as String),
      isCompleted: (map['is_completed'] as int? ?? 0) == 1,
      createdAt: DateTime.parse(map['created_at'] as String),
      updatedAt: DateTime.parse(map['updated_at'] as String),
    );
  }
}
