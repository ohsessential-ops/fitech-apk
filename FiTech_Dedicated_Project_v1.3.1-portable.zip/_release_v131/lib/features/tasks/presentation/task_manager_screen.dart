import 'package:flutter/material.dart';

import '../data/task_repository.dart';
import '../domain/business_task.dart';

class TaskManagerScreen extends StatefulWidget {
  const TaskManagerScreen({super.key});

  @override
  State<TaskManagerScreen> createState() => _TaskManagerScreenState();
}

class _TaskManagerScreenState extends State<TaskManagerScreen> {
  final repository = TaskRepository();
  bool showCompleted = true;

  Future<void> addTask() async {
    final titleController = TextEditingController();
    final descriptionController = TextEditingController();
    var priority = TaskPriority.medium;
    DateTime? dueAt;

    final saved = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('New business task'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: titleController,
                  autofocus: true,
                  decoration: const InputDecoration(labelText: 'Task title'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: descriptionController,
                  minLines: 2,
                  maxLines: 4,
                  decoration: const InputDecoration(labelText: 'Description'),
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<TaskPriority>(
                  value: priority,
                  decoration: const InputDecoration(labelText: 'Priority'),
                  items: TaskPriority.values
                      .map(
                        (item) => DropdownMenuItem(
                          value: item,
                          child: Text(item.name.toUpperCase()),
                        ),
                      )
                      .toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setDialogState(() => priority = value);
                    }
                  },
                ),
                const SizedBox(height: 10),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(
                    dueAt == null
                        ? 'No due date'
                        : 'Due: ${dueAt!.toLocal().toString().split(' ').first}',
                  ),
                  trailing: const Icon(Icons.calendar_month_outlined),
                  onTap: () async {
                    final picked = await showDatePicker(
                      context: context,
                      firstDate: DateTime.now().subtract(
                        const Duration(days: 1),
                      ),
                      lastDate: DateTime.now().add(
                        const Duration(days: 3650),
                      ),
                    );
                    if (picked != null) {
                      setDialogState(() => dueAt = picked);
                    }
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                if (titleController.text.trim().isEmpty) return;
                Navigator.of(context).pop(true);
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );

    if (saved == true) {
      await repository.createTask(
        title: titleController.text,
        description: descriptionController.text,
        priority: priority,
        dueAt: dueAt,
      );
      if (mounted) setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Business tasks'),
        actions: [
          IconButton(
            tooltip: showCompleted ? 'Hide completed' : 'Show completed',
            onPressed: () => setState(() => showCompleted = !showCompleted),
            icon: Icon(
              showCompleted
                  ? Icons.visibility_off_outlined
                  : Icons.visibility_outlined,
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: addTask,
        icon: const Icon(Icons.add),
        label: const Text('Add task'),
      ),
      body: FutureBuilder<List<BusinessTask>>(
        future: repository.getTasks(includeCompleted: showCompleted),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final tasks = snapshot.data!;
          if (tasks.isEmpty) {
            return const Center(
              child: Text('No business tasks. Add your first task.'),
            );
          }

          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
            itemCount: tasks.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final task = tasks[index];
              return Dismissible(
                key: ValueKey(task.id),
                direction: DismissDirection.endToStart,
                background: Container(
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 24),
                  color: Theme.of(context).colorScheme.errorContainer,
                  child: const Icon(Icons.delete_outline),
                ),
                onDismissed: (_) async {
                  await repository.deleteTask(task.id!);
                  setState(() {});
                },
                child: Card(
                  child: CheckboxListTile(
                    contentPadding: const EdgeInsets.all(14),
                    value: task.isCompleted,
                    onChanged: (_) async {
                      await repository.toggleComplete(task);
                      setState(() {});
                    },
                    title: Text(
                      task.title,
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        decoration:
                            task.isCompleted ? TextDecoration.lineThrough : null,
                      ),
                    ),
                    subtitle: Text(
                      [
                        task.priority.name.toUpperCase(),
                        if (task.dueAt != null)
                          'Due ${task.dueAt!.toLocal().toString().split(' ').first}',
                        if (task.isOverdue) 'OVERDUE',
                        if ((task.description ?? '').isNotEmpty)
                          task.description!,
                      ].join(' • '),
                    ),
                    secondary: Icon(
                      task.isOverdue
                          ? Icons.warning_amber_rounded
                          : Icons.task_alt_outlined,
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
