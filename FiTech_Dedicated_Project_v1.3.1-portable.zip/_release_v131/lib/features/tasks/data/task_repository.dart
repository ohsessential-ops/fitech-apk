import '../../../core/database/database_service.dart';
import '../domain/business_task.dart';

class TaskRepository {
  TaskRepository({DatabaseService? databaseService})
      : _databaseService = databaseService ?? DatabaseService.instance;

  final DatabaseService _databaseService;

  Future<List<BusinessTask>> getTasks({bool includeCompleted = true}) async {
    final db = await _databaseService.database;
    final rows = await db.query(
      'business_tasks',
      where: includeCompleted ? null : 'is_completed = 0',
      orderBy:
          'is_completed ASC, CASE priority '
          "WHEN 'urgent' THEN 1 WHEN 'high' THEN 2 "
          "WHEN 'medium' THEN 3 ELSE 4 END, "
          'due_at ASC, created_at DESC',
    );
    return rows.map(BusinessTask.fromMap).toList();
  }

  Future<int> pendingCount() async {
    final db = await _databaseService.database;
    final rows = await db.rawQuery(
      'SELECT COUNT(*) AS count FROM business_tasks WHERE is_completed = 0',
    );
    return (rows.first['count'] as num).toInt();
  }

  Future<int> createTask({
    required String title,
    String? description,
    TaskPriority priority = TaskPriority.medium,
    DateTime? dueAt,
  }) async {
    final db = await _databaseService.database;
    final now = DateTime.now().toUtc().toIso8601String();
    final id = await db.insert('business_tasks', {
      'title': title.trim(),
      'description': description?.trim(),
      'priority': priority.name,
      'due_at': dueAt?.toIso8601String(),
      'is_completed': 0,
      'created_at': now,
      'updated_at': now,
    });
    await db.insert('app_activity', {
      'activity_type': 'task_created',
      'title': 'Task created',
      'description': title.trim(),
      'reference_type': 'business_task',
      'reference_id': id.toString(),
      'created_at': now,
    });
    return id;
  }

  Future<void> toggleComplete(BusinessTask task) async {
    final db = await _databaseService.database;
    final completed = !task.isCompleted;
    final now = DateTime.now().toUtc().toIso8601String();
    await db.update(
      'business_tasks',
      {
        'is_completed': completed ? 1 : 0,
        'completed_at': completed ? now : null,
        'updated_at': now,
      },
      where: 'id = ?',
      whereArgs: [task.id],
    );
    await db.insert('app_activity', {
      'activity_type': completed ? 'task_completed' : 'task_reopened',
      'title': completed ? 'Task completed' : 'Task reopened',
      'description': task.title,
      'reference_type': 'business_task',
      'reference_id': task.id.toString(),
      'created_at': now,
    });
  }

  Future<void> deleteTask(int id) async {
    final db = await _databaseService.database;
    await db.delete('business_tasks', where: 'id = ?', whereArgs: [id]);
  }
}
