class DashboardSummary {
  const DashboardSummary({
    required this.todayProfit,
    required this.yesterdayProfit,
    required this.monthProfit,
    required this.lifetimeProfit,
    required this.totalOrders,
    required this.supplierBalance,
    required this.totalSupplierPayments,
    required this.calculatedCash,
    required this.actualBankBalance,
    required this.bankDifference,
  });

  final double todayProfit;
  final double yesterdayProfit;
  final double monthProfit;
  final double lifetimeProfit;
  final int totalOrders;
  final double supplierBalance;
  final double totalSupplierPayments;
  final double calculatedCash;
  final double? actualBankBalance;
  final double? bankDifference;
}
