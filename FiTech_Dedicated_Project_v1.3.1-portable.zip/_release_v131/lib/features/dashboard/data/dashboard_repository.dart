import '../../../core/database/database_service.dart';
import '../domain/dashboard_summary.dart';

class DashboardRepository {
  DashboardRepository({DatabaseService? databaseService})
      : _databaseService = databaseService ?? DatabaseService.instance;

  final DatabaseService _databaseService;

  Future<DashboardSummary> loadSummary(DateTime now) async {
    final db = await _databaseService.database;

    final today = DateTime(now.year, now.month, now.day);
    final tomorrow = today.add(const Duration(days: 1));
    final yesterday = today.subtract(const Duration(days: 1));
    final monthStart = DateTime(now.year, now.month, 1);
    final nextMonth = now.month == 12
        ? DateTime(now.year + 1, 1, 1)
        : DateTime(now.year, now.month + 1, 1);

    Future<double> profitBetween(DateTime start, DateTime end) async {
      final result = await db.rawQuery('''
        SELECT COALESCE(SUM(calculated_profit_gbp), 0) AS total
        FROM financial_orders
        WHERE deleted_at IS NULL
          AND order_date >= ?
          AND order_date < ?
      ''', [start.toIso8601String(), end.toIso8601String()]);
      return (result.first['total'] as num).toDouble();
    }

    final supplierBalanceRows = await db.rawQuery('''
      SELECT
        COALESCE(s.opening_balance_gbp, 0)
        + COALESCE(SUM(l.credit_gbp), 0)
        - COALESCE(SUM(l.debit_gbp), 0) AS supplier_balance
      FROM suppliers s
      LEFT JOIN supplier_ledger_entries l ON l.supplier_id = s.id
      WHERE s.is_active = 1
      GROUP BY s.id
      ORDER BY s.id ASC
      LIMIT 1
    ''');

    final supplierPaymentsRows = await db.rawQuery('''
      SELECT COALESCE(SUM(credit_gbp), 0) AS supplier_payments
      FROM supplier_ledger_entries
      WHERE type = 'supplierPayment'
    ''');

    final bankRows = await db.rawQuery('''
      SELECT
        COALESCE(SUM(inflow_gbp), 0)
        - COALESCE(SUM(outflow_gbp), 0) AS calculated_cash
      FROM bank_ledger_entries
    ''');

    final reconciliationRows = await db.query(
      'bank_reconciliations',
      orderBy: 'reconciliation_date DESC, id DESC',
      limit: 1,
    );

    final lifetime = await db.rawQuery('''
      SELECT
        COALESCE(SUM(calculated_profit_gbp), 0) AS lifetime_profit,
        COUNT(*) AS total_orders
      FROM financial_orders
      WHERE deleted_at IS NULL
    ''');

    return DashboardSummary(
      todayProfit: await profitBetween(today, tomorrow),
      yesterdayProfit: await profitBetween(yesterday, today),
      monthProfit: await profitBetween(monthStart, nextMonth),
      lifetimeProfit:
          (lifetime.first['lifetime_profit'] as num).toDouble(),
      totalOrders: (lifetime.first['total_orders'] as num).toInt(),
      supplierBalance: supplierBalanceRows.isEmpty
          ? 0
          : (supplierBalanceRows.first['supplier_balance'] as num).toDouble(),
      totalSupplierPayments:
          (supplierPaymentsRows.first['supplier_payments'] as num).toDouble(),
      calculatedCash: (bankRows.first['calculated_cash'] as num).toDouble(),
      actualBankBalance: reconciliationRows.isEmpty
          ? null
          : (reconciliationRows.first['actual_bank_balance_gbp'] as num)
              .toDouble(),
      bankDifference: reconciliationRows.isEmpty
          ? null
          : (reconciliationRows.first['difference_gbp'] as num).toDouble(),
    );
  }
}
