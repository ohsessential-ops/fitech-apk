import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/money.dart';
import '../../../domain/models/app_user.dart';
import '../../../shared/widgets/loading_skeleton.dart';
import '../../../shared/widgets/metric_card.dart';
import '../../../shared/widgets/professional_menu_card.dart';
import '../../../shared/widgets/raised_3d_button.dart';
import '../../../shared/widgets/responsive_content.dart';
import '../../../shared/widgets/section_header.dart';
import '../../automation/presentation/automation_hub_screen.dart';
import '../../bank/presentation/bank_ledger_screen.dart';
import '../../entries/presentation/add_entry_screen.dart';
import '../../entries/presentation/entries_screen.dart';
import '../../notifications/presentation/notification_center_screen.dart';
import '../../integrations/presentation/integration_center_screen.dart';
import '../../owner/presentation/owner_tools_screen.dart';
import '../../products/presentation/products_screen.dart';
import '../../reports/presentation/reports_screen.dart';
import '../../returns/presentation/returns_screen.dart';
import '../../search/presentation/global_search_screen.dart';
import '../../supplier/presentation/supplier_ledger_screen.dart';
import '../../system/presentation/system_center_screen.dart';
import '../data/dashboard_repository.dart';
import '../domain/dashboard_summary.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({
    super.key,
    required this.currentUser,
    required this.onSignOut,
  });

  final AppUser currentUser;
  final VoidCallback onSignOut;

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final repository = DashboardRepository();
  late Future<DashboardSummary> summary;

  @override
  void initState() {
    super.initState();
    summary = repository.loadSummary(DateTime.now());
  }

  void refresh() {
    setState(() => summary = repository.loadSummary(DateTime.now()));
  }

  Future<void> open(Widget screen) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => screen),
    );
    refresh();
  }

  Future<void> addEntry() async {
    final saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => const AddEntryScreen()),
    );
    if (saved == true) refresh();
  }

  int gridColumns(double width) {
    if (width >= 1050) return 4;
    if (width >= 700) return 3;
    return 2;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 18,
        title: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF3B82F6), AppTheme.blue],
                ),
                borderRadius: BorderRadius.circular(12),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x30246BFD),
                    blurRadius: 10,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: const Icon(
                Icons.account_balance_wallet_outlined,
                color: Colors.white,
                size: 21,
              ),
            ),
            const SizedBox(width: 11),
            const Text('FiTech'),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Universal search',
            onPressed: () => open(const GlobalSearchScreen()),
            icon: const Icon(Icons.search),
          ),
          IconButton(
            tooltip: 'Notifications',
            onPressed: () => open(const NotificationCenterScreen()),
            icon: const Icon(Icons.notifications_none_rounded),
          ),
          PopupMenuButton<String>(
            tooltip: 'Account menu',
            onSelected: (value) {
              if (value == 'system') open(const SystemCenterScreen());
              if (value == 'signout') widget.onSignOut();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(
                value: 'system',
                child: ListTile(
                  leading: Icon(Icons.settings_outlined),
                  title: Text('System & settings'),
                ),
              ),
              PopupMenuItem(
                value: 'signout',
                child: ListTile(
                  leading: Icon(Icons.logout),
                  title: Text('Sign out'),
                ),
              ),
            ],
            icon: const Icon(Icons.account_circle_outlined),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: FutureBuilder<DashboardSummary>(
        future: summary,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const ResponsiveContent(
              child: Column(
                children: [
                  LoadingSkeleton(height: 140),
                  SizedBox(height: 16),
                  LoadingSkeleton(height: 110),
                  SizedBox(height: 12),
                  LoadingSkeleton(height: 110),
                  SizedBox(height: 20),
                  LoadingSkeleton(height: 320),
                ],
              ),
            );
          }

          final data = snapshot.data!;

          return RefreshIndicator(
            onRefresh: () async => refresh(),
            child: LayoutBuilder(
              builder: (context, constraints) {
                final columns = gridColumns(constraints.maxWidth);
                final wide = constraints.maxWidth >= 760;

                return ListView(
                  children: [
                    ResponsiveContent(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _WelcomeBanner(
                            userName: widget.currentUser.displayName,
                            role: widget.currentUser.role.name,
                            onAddEntry: addEntry,
                            onSearch: () => open(const GlobalSearchScreen()),
                          ),
                          const SizedBox(height: 24),
                          const SectionHeader(
                            title: 'Financial overview',
                            subtitle: 'Live information from your local database',
                          ),
                          const SizedBox(height: 12),
                          GridView.count(
                            crossAxisCount: wide ? 4 : 2,
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            crossAxisSpacing: 12,
                            mainAxisSpacing: 12,
                            childAspectRatio: wide ? 1.65 : 1.35,
                            children: [
                              MetricCard(
                                compact: true,
                                title: "Today's profit",
                                value: Money.gbp(data.todayProfit),
                                icon: Icons.trending_up_rounded,
                              ),
                              MetricCard(
                                compact: true,
                                title: 'Monthly profit',
                                value: Money.gbp(data.monthProfit),
                                icon: Icons.calendar_month_outlined,
                              ),
                              MetricCard(
                                compact: true,
                                title: data.actualBankBalance == null
                                    ? 'Available cash'
                                    : 'Bank balance',
                                value: Money.gbp(
                                  data.actualBankBalance ??
                                      data.calculatedCash,
                                ),
                                icon: Icons.account_balance_wallet_outlined,
                              ),
                              MetricCard(
                                compact: true,
                                title: data.supplierBalance >= 0
                                    ? 'Supplier credit'
                                    : 'Supplier payable',
                                value: Money.gbp(
                                  data.supplierBalance.abs(),
                                ),
                                icon: Icons.inventory_2_outlined,
                              ),
                            ],
                          ),
                          const SizedBox(height: 26),
                          SectionHeader(
                            title: 'Main menu',
                            subtitle: 'Everything is organised for quick access',
                            actionLabel: 'Search',
                            onAction: () => open(const GlobalSearchScreen()),
                          ),
                          const SizedBox(height: 12),
                          GridView.count(
                            crossAxisCount: columns,
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            crossAxisSpacing: 12,
                            mainAxisSpacing: 12,
                            childAspectRatio: columns >= 3 ? 1.12 : 1.0,
                            children: [
                              ProfessionalMenuCard(
                                icon: Icons.receipt_long_outlined,
                                title: 'Orders',
                                subtitle: 'Financial entries and order history',
                                onTap: () => open(const EntriesScreen()),
                              ),
                              ProfessionalMenuCard(
                                icon: Icons.inventory_2_outlined,
                                title: 'Products',
                                subtitle: 'SKUs and supplier cost history',
                                onTap: () => open(const ProductsScreen()),
                              ),
                              ProfessionalMenuCard(
                                icon: Icons.account_balance_wallet_outlined,
                                title: 'Supplier',
                                subtitle: 'Payments, credits and balance',
                                onTap: () => open(
                                  const SupplierLedgerScreen(),
                                ),
                              ),
                              ProfessionalMenuCard(
                                icon: Icons.account_balance_outlined,
                                title: 'Bank',
                                subtitle: 'Cash flow and reconciliation',
                                onTap: () => open(const BankLedgerScreen()),
                              ),
                              ProfessionalMenuCard(
                                icon: Icons.assignment_return_outlined,
                                title: 'Returns',
                                subtitle: 'Refunds and adjusted profit',
                                onTap: () => open(const ReturnsScreen()),
                              ),
                              ProfessionalMenuCard(
                                icon: Icons.analytics_outlined,
                                title: 'Reports',
                                subtitle: 'Analysis, PDF and Excel reports',
                                onTap: () => open(const ReportsScreen()),
                              ),
                              ProfessionalMenuCard(
                                icon: Icons.hub_outlined,
                                title: 'Integrations',
                                subtitle: 'Connect marketplaces and sync data',
                                onTap: () => open(const IntegrationCenterScreen()),
                              ),
                              ProfessionalMenuCard(
                                icon: Icons.auto_mode_outlined,
                                title: 'Automation',
                                subtitle: 'Tasks, alerts and daily close',
                                onTap: () => open(
                                  const AutomationHubScreen(),
                                ),
                              ),
                              ProfessionalMenuCard(
                                icon: Icons.workspace_premium_outlined,
                                title: 'Owner tools',
                                subtitle: 'Insights and data-quality controls',
                                onTap: () => open(const OwnerToolsScreen()),
                              ),
                            ],
                          ),
                          const SizedBox(height: 26),
                          const SectionHeader(
                            title: 'Business totals',
                            subtitle: 'Long-term operating position',
                          ),
                          const SizedBox(height: 12),
                          GridView.count(
                            crossAxisCount: wide ? 4 : 2,
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            crossAxisSpacing: 12,
                            mainAxisSpacing: 12,
                            childAspectRatio: wide ? 1.65 : 1.35,
                            children: [
                              MetricCard(
                                compact: true,
                                title: 'Lifetime profit',
                                value: Money.gbp(data.lifetimeProfit),
                                icon: Icons.auto_graph_rounded,
                              ),
                              MetricCard(
                                compact: true,
                                title: 'Financial orders',
                                value: data.totalOrders.toString(),
                                icon: Icons.shopping_bag_outlined,
                              ),
                              MetricCard(
                                compact: true,
                                title: 'Supplier payments',
                                value:
                                    Money.gbp(data.totalSupplierPayments),
                                icon: Icons.payments_outlined,
                              ),
                              MetricCard(
                                compact: true,
                                title: "Yesterday's profit",
                                value: Money.gbp(data.yesterdayProfit),
                                icon: Icons.history_rounded,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
          );
        },
      ),
      floatingActionButton: MediaQuery.sizeOf(context).width < 600
          ? FloatingActionButton(
              tooltip: 'Add financial entry',
              onPressed: addEntry,
              child: const Icon(Icons.add),
            )
          : null,
    );
  }
}

class _WelcomeBanner extends StatelessWidget {
  const _WelcomeBanner({
    required this.userName,
    required this.role,
    required this.onAddEntry,
    required this.onSearch,
  });

  final String userName;
  final String role;
  final VoidCallback onAddEntry;
  final VoidCallback onSearch;

  @override
  Widget build(BuildContext context) {
    final narrow = MediaQuery.sizeOf(context).width < 650;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(narrow ? 20 : 26),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppTheme.deepNavy, AppTheme.navy, Color(0xFF123A6B)],
        ),
        borderRadius: BorderRadius.circular(26),
        boxShadow: const [
          BoxShadow(
            color: Color(0x2A0B1F3A),
            blurRadius: 24,
            offset: Offset(0, 12),
          ),
          BoxShadow(
            color: Color(0x28071426),
            blurRadius: 0,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: narrow
          ? Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _WelcomeText(userName: userName, role: role),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Expanded(
                      child: Raised3DButton(
                        label: 'Add entry',
                        icon: Icons.add,
                        onPressed: onAddEntry,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Raised3DButton(
                        label: 'Search',
                        icon: Icons.search,
                        style: Raised3DButtonStyle.secondary,
                        onPressed: onSearch,
                      ),
                    ),
                  ],
                ),
              ],
            )
          : Row(
              children: [
                Expanded(
                  child: _WelcomeText(userName: userName, role: role),
                ),
                const SizedBox(width: 20),
                Raised3DButton(
                  label: 'Add financial entry',
                  icon: Icons.add,
                  onPressed: onAddEntry,
                ),
                const SizedBox(width: 10),
                Raised3DButton(
                  label: 'Search',
                  icon: Icons.search,
                  style: Raised3DButtonStyle.secondary,
                  onPressed: onSearch,
                ),
              ],
            ),
    );
  }
}

class _WelcomeText extends StatelessWidget {
  const _WelcomeText({
    required this.userName,
    required this.role,
  });

  final String userName;
  final String role;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Welcome back, $userName',
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.w900,
              ),
        ),
        const SizedBox(height: 7),
        Text(
          'Your FiTech business workspace • ${role.toUpperCase()}',
          style: const TextStyle(
            color: Color(0xFFCBD5E1),
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}
