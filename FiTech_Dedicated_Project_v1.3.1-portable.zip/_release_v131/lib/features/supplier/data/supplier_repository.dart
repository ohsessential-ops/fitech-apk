import '../../../core/database/database_service.dart';
import '../../../domain/models/supplier.dart';
import '../../../domain/models/supplier_ledger_entry.dart';
import '../domain/supplier_balance.dart';

class SupplierRepository {
  SupplierRepository({DatabaseService? databaseService})
      : _databaseService = databaseService ?? DatabaseService.instance;

  final DatabaseService _databaseService;

  Future<Supplier> getPrimarySupplier() async {
    final db = await _databaseService.database;
    final rows = await db.query(
      'suppliers',
      where: 'is_active = 1',
      orderBy: 'id ASC',
      limit: 1,
    );
    if (rows.isEmpty) throw StateError('No active supplier configured.');
    return Supplier.fromMap(rows.first);
  }

  Future<SupplierBalance> getBalance(int supplierId) async {
    final db = await _databaseService.database;
    final supplier = await db.query(
      'suppliers',
      columns: ['opening_balance_gbp'],
      where: 'id = ?',
      whereArgs: [supplierId],
      limit: 1,
    );
    final totals = await db.rawQuery('''
      SELECT
        COALESCE(SUM(debit_gbp), 0) AS total_debits,
        COALESCE(SUM(credit_gbp), 0) AS total_credits
      FROM supplier_ledger_entries
      WHERE supplier_id = ?
    ''', [supplierId]);

    return SupplierBalance(
      openingBalance: (supplier.first['opening_balance_gbp'] as num).toDouble(),
      totalDebits: (totals.first['total_debits'] as num).toDouble(),
      totalCredits: (totals.first['total_credits'] as num).toDouble(),
    );
  }

  Future<List<SupplierLedgerEntry>> getEntries(int supplierId) async {
    final db = await _databaseService.database;
    final rows = await db.query(
      'supplier_ledger_entries',
      where: 'supplier_id = ?',
      whereArgs: [supplierId],
      orderBy: 'entry_date DESC, id DESC',
      limit: 200,
    );
    return rows.map(SupplierLedgerEntry.fromMap).toList();
  }

  Future<int> addEntry(SupplierLedgerEntry entry) async {
    final db = await _databaseService.database;
    return db.insert('supplier_ledger_entries', entry.toMap());
  }

  Future<void> addSupplierPayment({
    required int supplierId,
    required DateTime paymentDate,
    required double amountGbp,
    String? reference,
    String? notes,
  }) async {
    final db = await _databaseService.database;
    await db.transaction((txn) async {
      await txn.insert(
        'supplier_ledger_entries',
        SupplierLedgerEntry(
        supplierId: supplierId,
        entryDate: paymentDate,
        type: SupplierLedgerType.supplierPayment,
        referenceType: 'payment',
        referenceId: reference,
        description: 'Supplier payment via Payoneer',
        debitGbp: 0,
        creditGbp: amountGbp,
        notes: notes,
        createdAt: DateTime.now(),
        ).toMap(),
      );
      await txn.insert('bank_ledger_entries', {
        'entry_date': paymentDate.toIso8601String(),
        'type': 'supplierPayment',
        'reference_type': 'supplier_payment',
        'reference_id': reference,
        'description': 'Supplier payment via Payoneer',
        'inflow_gbp': 0,
        'outflow_gbp': amountGbp,
        'notes': notes,
        'created_at': DateTime.now().toUtc().toIso8601String(),
      });
    });
  }

  Future<void> addSupplierCredit({
    required int supplierId,
    required DateTime creditDate,
    required double amountGbp,
    String? reference,
    String? notes,
  }) async {
    await addEntry(
      SupplierLedgerEntry(
        supplierId: supplierId,
        entryDate: creditDate,
        type: SupplierLedgerType.supplierCredit,
        referenceType: 'supplier_credit',
        referenceId: reference,
        description: 'Supplier credit',
        debitGbp: 0,
        creditGbp: amountGbp,
        notes: notes,
        createdAt: DateTime.now(),
      ),
    );
  }

  Future<void> addCorrection({
    required int supplierId,
    required DateTime date,
    required double amountGbp,
    required bool increasesCredit,
    String? notes,
  }) async {
    await addEntry(
      SupplierLedgerEntry(
        supplierId: supplierId,
        entryDate: date,
        type: increasesCredit
            ? SupplierLedgerType.correctionCredit
            : SupplierLedgerType.correctionDebit,
        referenceType: 'correction',
        description: increasesCredit
            ? 'Supplier balance credit correction'
            : 'Supplier balance debit correction',
        debitGbp: increasesCredit ? 0 : amountGbp,
        creditGbp: increasesCredit ? amountGbp : 0,
        notes: notes,
        createdAt: DateTime.now(),
      ),
    );
  }
}
