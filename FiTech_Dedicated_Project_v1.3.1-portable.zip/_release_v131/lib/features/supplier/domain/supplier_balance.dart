class SupplierBalance {
  const SupplierBalance({
    required this.openingBalance,
    required this.totalDebits,
    required this.totalCredits,
  });

  final double openingBalance;
  final double totalDebits;
  final double totalCredits;

  double get balance => openingBalance + totalCredits - totalDebits;
  bool get isCreditAvailable => balance >= 0;

  String get plainEnglishLabel =>
      isCreditAvailable ? 'Credit available with supplier' : 'You owe supplier';
}
