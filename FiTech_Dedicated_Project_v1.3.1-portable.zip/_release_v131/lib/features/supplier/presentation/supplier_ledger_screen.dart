import 'package:flutter/material.dart';

import '../../../core/utils/money.dart';
import '../../../domain/models/supplier.dart';
import '../../../domain/models/supplier_ledger_entry.dart';
import '../data/supplier_repository.dart';
import '../domain/supplier_balance.dart';
import 'add_supplier_adjustment_screen.dart';
import 'add_supplier_payment_screen.dart';

class SupplierLedgerScreen extends StatefulWidget {
  const SupplierLedgerScreen({super.key});

  @override
  State<SupplierLedgerScreen> createState() => _SupplierLedgerScreenState();
}

class _SupplierLedgerScreenState extends State<SupplierLedgerScreen> {
  final repository = SupplierRepository();
  late Future<_SupplierViewData> data;

  @override
  void initState() {
    super.initState();
    data = load();
  }

  Future<_SupplierViewData> load() async {
    final supplier = await repository.getPrimarySupplier();
    return _SupplierViewData(
      supplier: supplier,
      balance: await repository.getBalance(supplier.id),
      entries: await repository.getEntries(supplier.id),
    );
  }

  void refresh() => setState(() => data = load());

  Future<void> openScreen(Widget screen) async {
    final saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => screen),
    );
    if (saved == true) refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Supplier ledger')),
      body: FutureBuilder<_SupplierViewData>(
        future: data,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final value = snapshot.data!;
          final signedBalance = value.balance.balance;
          final sellerOwes = signedBalance < 0;

          return RefreshIndicator(
            onRefresh: () async => refresh(),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 100),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          value.supplier.displayName,
                          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                fontWeight: FontWeight.w800,
                              ),
                        ),
                        const SizedBox(height: 8),
                        Text(value.balance.plainEnglishLabel),
                        Text(
                          Money.gbp(signedBalance.abs()),
                          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                                fontWeight: FontWeight.w900,
                                color: sellerOwes
                                    ? Theme.of(context).colorScheme.error
                                    : null,
                              ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Debits ${Money.gbp(value.balance.totalDebits)}'
                          ' • Credits ${Money.gbp(value.balance.totalCredits)}',
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    FilledButton.icon(
                      onPressed: () => openScreen(
                        AddSupplierPaymentScreen(supplier: value.supplier),
                      ),
                      icon: const Icon(Icons.payments_outlined),
                      label: const Text('Add payment'),
                    ),
                    OutlinedButton.icon(
                      onPressed: () => openScreen(
                        AddSupplierAdjustmentScreen(
                          supplier: value.supplier,
                          mode: SupplierAdjustmentMode.credit,
                        ),
                      ),
                      icon: const Icon(Icons.replay_circle_filled_outlined),
                      label: const Text('Supplier credit'),
                    ),
                    OutlinedButton.icon(
                      onPressed: () => openScreen(
                        AddSupplierAdjustmentScreen(
                          supplier: value.supplier,
                          mode: SupplierAdjustmentMode.correctionCredit,
                        ),
                      ),
                      icon: const Icon(Icons.add_circle_outline),
                      label: const Text('Credit correction'),
                    ),
                    OutlinedButton.icon(
                      onPressed: () => openScreen(
                        AddSupplierAdjustmentScreen(
                          supplier: value.supplier,
                          mode: SupplierAdjustmentMode.correctionDebit,
                        ),
                      ),
                      icon: const Icon(Icons.remove_circle_outline),
                      label: const Text('Debit correction'),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                Text(
                  'Ledger activity',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w800,
                      ),
                ),
                const SizedBox(height: 10),
                if (value.entries.isEmpty)
                  const Card(
                    child: ListTile(title: Text('No supplier transactions yet')),
                  ),
                for (final entry in value.entries) ...[
                  Card(
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(16),
                      leading: CircleAvatar(
                        child: Icon(
                          entry.creditGbp > 0
                              ? Icons.arrow_downward_rounded
                              : Icons.arrow_upward_rounded,
                        ),
                      ),
                      title: Text(
                        entry.description,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      subtitle: Text(
                        [
                          entry.entryDate.toString().split(' ').first,
                          if (entry.referenceId != null) entry.referenceId!,
                          if (entry.notes != null) entry.notes!,
                        ].join(' • '),
                      ),
                      trailing: Text(
                        '${entry.creditGbp > 0 ? '+' : '-'}'
                        '${Money.gbp(entry.creditGbp > 0 ? entry.creditGbp : entry.debitGbp)}',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          color: entry.creditGbp > 0
                              ? null
                              : Theme.of(context).colorScheme.error,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                ],
              ],
            ),
          );
        },
      ),
    );
  }
}

class _SupplierViewData {
  const _SupplierViewData({
    required this.supplier,
    required this.balance,
    required this.entries,
  });

  final Supplier supplier;
  final SupplierBalance balance;
  final List<SupplierLedgerEntry> entries;
}
