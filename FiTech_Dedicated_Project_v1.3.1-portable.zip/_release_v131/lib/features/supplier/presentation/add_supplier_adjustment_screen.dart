import 'package:flutter/material.dart';

import '../../../domain/models/supplier.dart';
import '../data/supplier_repository.dart';

enum SupplierAdjustmentMode { credit, correctionCredit, correctionDebit }

class AddSupplierAdjustmentScreen extends StatefulWidget {
  const AddSupplierAdjustmentScreen({
    super.key,
    required this.supplier,
    required this.mode,
  });

  final Supplier supplier;
  final SupplierAdjustmentMode mode;

  @override
  State<AddSupplierAdjustmentScreen> createState() =>
      _AddSupplierAdjustmentScreenState();
}

class _AddSupplierAdjustmentScreenState
    extends State<AddSupplierAdjustmentScreen> {
  final formKey = GlobalKey<FormState>();
  final repository = SupplierRepository();
  final amount = TextEditingController();
  final reference = TextEditingController();
  final notes = TextEditingController();
  DateTime entryDate = DateTime.now();
  bool saving = false;

  String get title => switch (widget.mode) {
        SupplierAdjustmentMode.credit => 'Add supplier credit',
        SupplierAdjustmentMode.correctionCredit => 'Add credit correction',
        SupplierAdjustmentMode.correctionDebit => 'Add debit correction',
      };

  Future<void> save() async {
    if (!formKey.currentState!.validate()) return;
    setState(() => saving = true);
    final value = double.parse(amount.text.trim());

    if (widget.mode == SupplierAdjustmentMode.credit) {
      await repository.addSupplierCredit(
        supplierId: widget.supplier.id,
        creditDate: entryDate,
        amountGbp: value,
        reference: reference.text.trim().isEmpty ? null : reference.text.trim(),
        notes: notes.text.trim().isEmpty ? null : notes.text.trim(),
      );
    } else {
      await repository.addCorrection(
        supplierId: widget.supplier.id,
        date: entryDate,
        amountGbp: value,
        increasesCredit:
            widget.mode == SupplierAdjustmentMode.correctionCredit,
        notes: notes.text.trim().isEmpty ? null : notes.text.trim(),
      );
    }

    if (mounted) Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Form(
        key: formKey,
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            TextFormField(
              controller: amount,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              validator: (value) {
                final number = double.tryParse(value ?? '');
                return number == null || number <= 0 ? 'Enter a valid amount' : null;
              },
              decoration: const InputDecoration(
                labelText: 'Amount',
                prefixText: '£ ',
              ),
            ),
            const SizedBox(height: 12),
            if (widget.mode == SupplierAdjustmentMode.credit)
              TextFormField(
                controller: reference,
                decoration: const InputDecoration(
                  labelText: 'Credit reference (optional)',
                ),
              ),
            if (widget.mode == SupplierAdjustmentMode.credit)
              const SizedBox(height: 12),
            TextFormField(
              controller: notes,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'Reason or notes'),
            ),
            const SizedBox(height: 20),
            SizedBox(
              height: 54,
              child: FilledButton(
                onPressed: saving ? null : save,
                child: Text(saving ? 'Saving…' : 'Save entry'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
