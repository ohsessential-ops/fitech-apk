import 'package:flutter/material.dart';

import '../../../domain/models/supplier.dart';
import '../data/supplier_repository.dart';

class AddSupplierPaymentScreen extends StatefulWidget {
  const AddSupplierPaymentScreen({super.key, required this.supplier});
  final Supplier supplier;

  @override
  State<AddSupplierPaymentScreen> createState() =>
      _AddSupplierPaymentScreenState();
}

class _AddSupplierPaymentScreenState
    extends State<AddSupplierPaymentScreen> {
  final formKey = GlobalKey<FormState>();
  final repository = SupplierRepository();
  final amount = TextEditingController();
  final reference = TextEditingController();
  final notes = TextEditingController();
  DateTime paymentDate = DateTime.now();
  bool saving = false;

  Future<void> save() async {
    if (!formKey.currentState!.validate()) return;
    setState(() => saving = true);
    await repository.addSupplierPayment(
      supplierId: widget.supplier.id,
      paymentDate: paymentDate,
      amountGbp: double.parse(amount.text.trim()),
      reference: reference.text.trim().isEmpty ? null : reference.text.trim(),
      notes: notes.text.trim().isEmpty ? null : notes.text.trim(),
    );
    if (mounted) Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add supplier payment')),
      body: Form(
        key: formKey,
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Card(
              child: ListTile(
                contentPadding: const EdgeInsets.all(18),
                title: Text(widget.supplier.displayName),
                subtitle: Text('Payment method: ${widget.supplier.paymentMethod}'),
              ),
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: amount,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              validator: (value) {
                final number = double.tryParse(value ?? '');
                return number == null || number <= 0 ? 'Enter a valid amount' : null;
              },
              decoration: const InputDecoration(
                labelText: 'Payment amount',
                prefixText: '£ ',
              ),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: reference,
              decoration: const InputDecoration(
                labelText: 'Payoneer reference (optional)',
              ),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: notes,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'Notes (optional)'),
            ),
            const SizedBox(height: 20),
            SizedBox(
              height: 54,
              child: FilledButton(
                onPressed: saving ? null : save,
                child: Text(saving ? 'Saving…' : 'Record payment'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
