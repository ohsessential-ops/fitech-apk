enum NotificationSeverity { info, warning, critical, positive }

class BusinessNotification {
  const BusinessNotification({
    this.id,
    required this.key,
    required this.title,
    required this.message,
    required this.severity,
    required this.sourceType,
    this.sourceReference,
    this.isRead = false,
    this.isDismissed = false,
    required this.createdAt,
  });

  final int? id;
  final String key;
  final String title;
  final String message;
  final NotificationSeverity severity;
  final String sourceType;
  final String? sourceReference;
  final bool isRead;
  final bool isDismissed;
  final DateTime createdAt;

  factory BusinessNotification.fromMap(Map<String, Object?> map) {
    return BusinessNotification(
      id: map['id'] as int?,
      key: map['notification_key'] as String,
      title: map['title'] as String,
      message: map['message'] as String,
      severity: NotificationSeverity.values.firstWhere(
        (value) => value.name == map['severity'],
        orElse: () => NotificationSeverity.info,
      ),
      sourceType: map['source_type'] as String,
      sourceReference: map['source_reference'] as String?,
      isRead: (map['is_read'] as int? ?? 0) == 1,
      isDismissed: (map['is_dismissed'] as int? ?? 0) == 1,
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }
}
