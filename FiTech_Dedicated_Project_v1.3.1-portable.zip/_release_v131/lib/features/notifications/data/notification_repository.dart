import '../../../core/database/database_service.dart';
import '../domain/business_notification.dart';

class NotificationRepository {
  NotificationRepository({DatabaseService? databaseService})
      : _databaseService = databaseService ?? DatabaseService.instance;

  final DatabaseService _databaseService;

  Future<List<BusinessNotification>> getActive() async {
    final db = await _databaseService.database;
    final rows = await db.query(
      'notification_items',
      where: 'is_dismissed = 0',
      orderBy: 'is_read ASC, created_at DESC',
    );
    return rows.map(BusinessNotification.fromMap).toList();
  }

  Future<int> unreadCount() async {
    final db = await _databaseService.database;
    final rows = await db.rawQuery('''
      SELECT COUNT(*) AS count
      FROM notification_items
      WHERE is_read = 0 AND is_dismissed = 0
    ''');
    return (rows.first['count'] as num).toInt();
  }

  Future<void> upsert({
    required String key,
    required String title,
    required String message,
    required NotificationSeverity severity,
    required String sourceType,
    String? sourceReference,
  }) async {
    final db = await _databaseService.database;
    final now = DateTime.now().toUtc().toIso8601String();
    await db.rawInsert('''
      INSERT INTO notification_items (
        notification_key, title, message, severity, source_type,
        source_reference, is_read, is_dismissed, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, 0, 0, ?, ?)
      ON CONFLICT(notification_key) DO UPDATE SET
        title = excluded.title,
        message = excluded.message,
        severity = excluded.severity,
        source_reference = excluded.source_reference,
        is_dismissed = 0,
        updated_at = excluded.updated_at
    ''', [
      key,
      title,
      message,
      severity.name,
      sourceType,
      sourceReference,
      now,
      now,
    ]);
  }

  Future<void> markRead(int id) async {
    final db = await _databaseService.database;
    await db.update(
      'notification_items',
      {
        'is_read': 1,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> markAllRead() async {
    final db = await _databaseService.database;
    await db.update(
      'notification_items',
      {
        'is_read': 1,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      },
      where: 'is_dismissed = 0',
    );
  }

  Future<void> dismiss(int id) async {
    final db = await _databaseService.database;
    await db.update(
      'notification_items',
      {
        'is_dismissed': 1,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> dismissByKey(String key) async {
    final db = await _databaseService.database;
    await db.update(
      'notification_items',
      {
        'is_dismissed': 1,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      },
      where: 'notification_key = ?',
      whereArgs: [key],
    );
  }
}
