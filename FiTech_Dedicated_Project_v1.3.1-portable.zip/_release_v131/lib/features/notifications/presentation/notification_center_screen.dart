import 'package:flutter/material.dart';

import '../../automation/data/automation_service.dart';
import '../data/notification_repository.dart';
import '../domain/business_notification.dart';

class NotificationCenterScreen extends StatefulWidget {
  const NotificationCenterScreen({super.key});

  @override
  State<NotificationCenterScreen> createState() =>
      _NotificationCenterScreenState();
}

class _NotificationCenterScreenState extends State<NotificationCenterScreen> {
  final repository = NotificationRepository();
  bool refreshing = false;

  Future<void> refreshChecks() async {
    setState(() => refreshing = true);
    try {
      await AutomationService().runOwnerChecks();
    } finally {
      if (mounted) setState(() => refreshing = false);
    }
  }

  @override
  void initState() {
    super.initState();
    refreshChecks();
  }

  IconData iconFor(NotificationSeverity severity) {
    return switch (severity) {
      NotificationSeverity.critical => Icons.error_outline,
      NotificationSeverity.warning => Icons.warning_amber_rounded,
      NotificationSeverity.positive => Icons.check_circle_outline,
      NotificationSeverity.info => Icons.info_outline,
    };
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notification centre'),
        actions: [
          IconButton(
            tooltip: 'Mark all read',
            onPressed: () async {
              await repository.markAllRead();
              setState(() {});
            },
            icon: const Icon(Icons.done_all),
          ),
          IconButton(
            tooltip: 'Run checks',
            onPressed: refreshing ? null : refreshChecks,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: FutureBuilder<List<BusinessNotification>>(
        future: repository.getActive(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final items = snapshot.data!;
          if (items.isEmpty) {
            return const Center(
              child: Text('No active business alerts.'),
            );
          }

          return RefreshIndicator(
            onRefresh: refreshChecks,
            child: ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, index) {
                final item = items[index];
                return Dismissible(
                  key: ValueKey(item.id),
                  direction: DismissDirection.endToStart,
                  onDismissed: (_) async {
                    await repository.dismiss(item.id!);
                    setState(() {});
                  },
                  background: Container(
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 24),
                    color: Theme.of(context).colorScheme.surfaceContainerHighest,
                    child: const Icon(Icons.close),
                  ),
                  child: Card(
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(16),
                      leading: CircleAvatar(
                        child: Icon(iconFor(item.severity)),
                      ),
                      title: Text(
                        item.title,
                        style: TextStyle(
                          fontWeight:
                              item.isRead ? FontWeight.w600 : FontWeight.w900,
                        ),
                      ),
                      subtitle: Text(item.message),
                      trailing: item.isRead
                          ? null
                          : const Icon(Icons.circle, size: 10),
                      onTap: () async {
                        await repository.markRead(item.id!);
                        setState(() {});
                      },
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
