import 'package:flutter/material.dart';

import '../../../domain/models/app_user.dart';
import '../data/user_repository.dart';

class UsersScreen extends StatefulWidget {
  const UsersScreen({super.key});

  @override
  State<UsersScreen> createState() => _UsersScreenState();
}

class _UsersScreenState extends State<UsersScreen> {
  final repository = UserRepository();
  late Future<List<AppUser>> users;

  @override
  void initState() {
    super.initState();
    users = repository.getUsers();
  }

  void refresh() => setState(() => users = repository.getUsers());

  Future<void> addUser() async {
    final email = TextEditingController();
    final name = TextEditingController();
    final password = TextEditingController();
    var role = UserRole.staff;

    final saved = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Add user'),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: name,
                  decoration: const InputDecoration(labelText: 'Display name'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: email,
                  decoration: const InputDecoration(labelText: 'Email'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: password,
                  obscureText: true,
                  decoration:
                      const InputDecoration(labelText: 'Temporary password'),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<UserRole>(
                  value: role,
                  decoration: const InputDecoration(labelText: 'Role'),
                  items: [
                    for (final item in UserRole.values)
                      DropdownMenuItem(
                        value: item,
                        child: Text(item.name),
                      ),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      setDialogState(() => role = value);
                    }
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () async {
                if (email.text.trim().isEmpty ||
                    name.text.trim().isEmpty ||
                    password.text.length < 8) {
                  return;
                }
                await repository.createUser(
                  email: email.text,
                  displayName: name.text,
                  password: password.text,
                  role: role,
                );
                if (context.mounted) Navigator.of(context).pop(true);
              },
              child: const Text('Create'),
            ),
          ],
        ),
      ),
    );

    email.dispose();
    name.dispose();
    password.dispose();
    if (saved == true) refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Users and roles')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: addUser,
        icon: const Icon(Icons.person_add_alt_1),
        label: const Text('Add user'),
      ),
      body: FutureBuilder<List<AppUser>>(
        future: users,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
            itemCount: snapshot.data!.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              final user = snapshot.data![index];
              return Card(
                child: SwitchListTile(
                  contentPadding: const EdgeInsets.all(16),
                  value: user.isActive,
                  onChanged: user.role == UserRole.owner
                      ? null
                      : (value) async {
                          await repository.setActive(user.id, value);
                          refresh();
                        },
                  title: Text(
                    user.displayName,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: Text('${user.email} • ${user.role.name}'),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
