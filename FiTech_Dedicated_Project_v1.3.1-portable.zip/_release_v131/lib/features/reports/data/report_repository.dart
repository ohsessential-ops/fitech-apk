import '../../../core/database/database_service.dart';
import '../domain/report_models.dart';

class ReportRepository {
  ReportRepository({DatabaseService? databaseService})
      : _databaseService = databaseService ?? DatabaseService.instance;

  final DatabaseService _databaseService;

  Future<ManagementReport> generate(ReportFilter filter) async {
    final db = await _databaseService.database;
    final start = filter.startDate.toIso8601String();
    final end = filter.endDateExclusive.toIso8601String();
    final shopClause = filter.shopId == null ? '' : 'AND o.shop_id = ?';
    final args = <Object?>[start, end, if (filter.shopId != null) filter.shopId];

    final summaryRows = await db.rawQuery('''
      SELECT
        COUNT(*) AS total_orders,
        COALESCE(SUM(o.tiktok_net_earning_gbp), 0) AS total_earnings,
        COALESCE(SUM(o.supplier_total_cost_gbp), 0) AS total_supplier_cost,
        COALESCE(SUM(o.calculated_profit_gbp), 0) AS total_profit
      FROM financial_orders o
      WHERE o.deleted_at IS NULL
        AND o.order_date >= ?
        AND o.order_date < ?
        $shopClause
    ''', args);

    final returnsArgs = <Object?>[
      start,
      end,
      if (filter.shopId != null) filter.shopId,
    ];

    final returnRows = await db.rawQuery('''
      SELECT
        COALESCE(SUM(r.customer_refund_gbp), 0) AS total_refunds,
        COALESCE(SUM(r.supplier_credit_gbp), 0) AS total_supplier_credits
      FROM returns r
      INNER JOIN financial_orders o ON o.id = r.financial_order_id
      WHERE r.return_date >= ?
        AND r.return_date < ?
        ${filter.shopId == null ? '' : 'AND o.shop_id = ?'}
    ''', returnsArgs);

    final shopRows = await db.rawQuery('''
      SELECT
        s.id AS shop_id,
        s.name AS shop_name,
        COUNT(*) AS order_count,
        COALESCE(SUM(o.tiktok_net_earning_gbp), 0) AS total_earnings,
        COALESCE(SUM(o.supplier_total_cost_gbp), 0) AS total_supplier_cost,
        COALESCE(SUM(o.calculated_profit_gbp), 0) AS total_profit
      FROM financial_orders o
      INNER JOIN shops s ON s.id = o.shop_id
      WHERE o.deleted_at IS NULL
        AND o.order_date >= ?
        AND o.order_date < ?
        $shopClause
      GROUP BY s.id, s.name
      ORDER BY total_profit DESC
    ''', args);

    final dailyRows = await db.rawQuery('''
      SELECT
        SUBSTR(o.order_date, 1, 10) AS day,
        COUNT(*) AS order_count,
        COALESCE(SUM(o.calculated_profit_gbp), 0) AS total_profit
      FROM financial_orders o
      WHERE o.deleted_at IS NULL
        AND o.order_date >= ?
        AND o.order_date < ?
        $shopClause
      GROUP BY SUBSTR(o.order_date, 1, 10)
      ORDER BY day ASC
    ''', args);

    final productRows = await db.rawQuery('''
      SELECT
        o.sku_snapshot AS sku,
        COALESCE(o.product_name_snapshot, o.sku_snapshot) AS product_name,
        COUNT(*) AS order_count,
        COALESCE(SUM(o.quantity), 0) AS quantity,
        COALESCE(SUM(o.calculated_profit_gbp), 0) AS total_profit
      FROM financial_orders o
      WHERE o.deleted_at IS NULL
        AND o.order_date >= ?
        AND o.order_date < ?
        $shopClause
      GROUP BY o.sku_snapshot, COALESCE(o.product_name_snapshot, o.sku_snapshot)
      ORDER BY total_profit DESC
      LIMIT 50
    ''', args);

    final orderRows = await db.rawQuery('''
      SELECT
        o.order_date,
        o.tiktok_order_id,
        s.name AS shop_name,
        o.sku_snapshot,
        o.quantity,
        o.tiktok_net_earning_gbp,
        o.supplier_total_cost_gbp,
        o.calculated_profit_gbp,
        o.tracking_number
      FROM financial_orders o
      INNER JOIN shops s ON s.id = o.shop_id
      WHERE o.deleted_at IS NULL
        AND o.order_date >= ?
        AND o.order_date < ?
        $shopClause
      ORDER BY o.order_date DESC, o.id DESC
    ''', args);

    final summaryMap = summaryRows.first;
    final totalOrders = (summaryMap['total_orders'] as num).toInt();
    final totalEarnings = (summaryMap['total_earnings'] as num).toDouble();
    final totalProfit = (summaryMap['total_profit'] as num).toDouble();

    return ManagementReport(
      filter: filter,
      summary: ReportSummary(
        totalOrders: totalOrders,
        totalEarnings: totalEarnings,
        totalSupplierCost:
            (summaryMap['total_supplier_cost'] as num).toDouble(),
        totalProfit: totalProfit,
        averageOrderProfit:
            totalOrders == 0 ? 0 : totalProfit / totalOrders,
        profitMarginPercent:
            totalEarnings == 0 ? null : (totalProfit / totalEarnings) * 100,
        totalRefunds:
            (returnRows.first['total_refunds'] as num).toDouble(),
        totalSupplierCredits:
            (returnRows.first['total_supplier_credits'] as num).toDouble(),
      ),
      shopPerformance: shopRows
          .map(
            (row) => ShopPerformance(
              shopId: row['shop_id'] as int,
              shopName: row['shop_name'] as String,
              orderCount: (row['order_count'] as num).toInt(),
              totalEarnings: (row['total_earnings'] as num).toDouble(),
              totalSupplierCost:
                  (row['total_supplier_cost'] as num).toDouble(),
              totalProfit: (row['total_profit'] as num).toDouble(),
            ),
          )
          .toList(),
      dailyProfit: dailyRows
          .map(
            (row) => DailyProfitPoint(
              date: DateTime.parse(row['day'] as String),
              profit: (row['total_profit'] as num).toDouble(),
              orderCount: (row['order_count'] as num).toInt(),
            ),
          )
          .toList(),
      productPerformance: productRows
          .map(
            (row) => ProductPerformance(
              sku: row['sku'] as String,
              productName: row['product_name'] as String,
              orderCount: (row['order_count'] as num).toInt(),
              quantity: (row['quantity'] as num).toInt(),
              totalProfit: (row['total_profit'] as num).toDouble(),
            ),
          )
          .toList(),
      orders: orderRows
          .map(
            (row) => ReportOrderRow(
              orderDate: DateTime.parse(row['order_date'] as String),
              orderId: row['tiktok_order_id'] as String,
              shopName: row['shop_name'] as String,
              sku: row['sku_snapshot'] as String,
              quantity: (row['quantity'] as num).toInt(),
              tiktokEarning:
                  (row['tiktok_net_earning_gbp'] as num).toDouble(),
              supplierCost:
                  (row['supplier_total_cost_gbp'] as num).toDouble(),
              profit: (row['calculated_profit_gbp'] as num).toDouble(),
              trackingNumber: row['tracking_number'] as String?,
            ),
          )
          .toList(),
    );
  }
}
