class ReportFilter {
  const ReportFilter({
    required this.startDate,
    required this.endDateExclusive,
    this.shopId,
  });

  final DateTime startDate;
  final DateTime endDateExclusive;
  final int? shopId;
}

class ReportSummary {
  const ReportSummary({
    required this.totalOrders,
    required this.totalEarnings,
    required this.totalSupplierCost,
    required this.totalProfit,
    required this.averageOrderProfit,
    required this.profitMarginPercent,
    required this.totalRefunds,
    required this.totalSupplierCredits,
  });

  final int totalOrders;
  final double totalEarnings;
  final double totalSupplierCost;
  final double totalProfit;
  final double averageOrderProfit;
  final double? profitMarginPercent;
  final double totalRefunds;
  final double totalSupplierCredits;
}

class ShopPerformance {
  const ShopPerformance({
    required this.shopId,
    required this.shopName,
    required this.orderCount,
    required this.totalEarnings,
    required this.totalSupplierCost,
    required this.totalProfit,
  });

  final int shopId;
  final String shopName;
  final int orderCount;
  final double totalEarnings;
  final double totalSupplierCost;
  final double totalProfit;
}

class DailyProfitPoint {
  const DailyProfitPoint({
    required this.date,
    required this.profit,
    required this.orderCount,
  });

  final DateTime date;
  final double profit;
  final int orderCount;
}

class ProductPerformance {
  const ProductPerformance({
    required this.sku,
    required this.productName,
    required this.orderCount,
    required this.quantity,
    required this.totalProfit,
  });

  final String sku;
  final String productName;
  final int orderCount;
  final int quantity;
  final double totalProfit;
}

class ReportOrderRow {
  const ReportOrderRow({
    required this.orderDate,
    required this.orderId,
    required this.shopName,
    required this.sku,
    required this.quantity,
    required this.tiktokEarning,
    required this.supplierCost,
    required this.profit,
    this.trackingNumber,
  });

  final DateTime orderDate;
  final String orderId;
  final String shopName;
  final String sku;
  final int quantity;
  final double tiktokEarning;
  final double supplierCost;
  final double profit;
  final String? trackingNumber;
}

class ManagementReport {
  const ManagementReport({
    required this.filter,
    required this.summary,
    required this.shopPerformance,
    required this.dailyProfit,
    required this.productPerformance,
    required this.orders,
  });

  final ReportFilter filter;
  final ReportSummary summary;
  final List<ShopPerformance> shopPerformance;
  final List<DailyProfitPoint> dailyProfit;
  final List<ProductPerformance> productPerformance;
  final List<ReportOrderRow> orders;
}
