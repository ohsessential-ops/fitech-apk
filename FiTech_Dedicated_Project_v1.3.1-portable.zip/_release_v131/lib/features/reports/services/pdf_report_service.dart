import 'dart:io';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';

import '../domain/report_models.dart';

class PdfReportService {
  Future<File> generate(ManagementReport report) async {
    final document = pw.Document(
      title: 'FiTech Management Report',
      author: 'FiTech — Powered by Faizan',
    );

    document.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        header: (context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text(
              'FiTech',
              style: pw.TextStyle(
                fontSize: 24,
                fontWeight: pw.FontWeight.bold,
              ),
            ),
            pw.Text('Powered by Faizan'),
            pw.SizedBox(height: 4),
            pw.Text(
              'Management Report • '
              '${_date(report.filter.startDate)} to '
              '${_date(report.filter.endDateExclusive.subtract(const Duration(days: 1)))}',
              style: const pw.TextStyle(fontSize: 10),
            ),
            pw.Divider(),
          ],
        ),
        footer: (context) => pw.Align(
          alignment: pw.Alignment.centerRight,
          child: pw.Text(
            'Page ${context.pageNumber} of ${context.pagesCount}',
            style: const pw.TextStyle(fontSize: 9),
          ),
        ),
        build: (context) => [
          pw.Text(
            'Executive Summary',
            style: pw.TextStyle(
              fontSize: 18,
              fontWeight: pw.FontWeight.bold,
            ),
          ),
          pw.SizedBox(height: 10),
          pw.TableHelper.fromTextArray(
            headers: const ['Metric', 'Value'],
            data: [
              ['Total Orders', report.summary.totalOrders.toString()],
              ['TikTok Net Earnings', _money(report.summary.totalEarnings)],
              ['Supplier Cost', _money(report.summary.totalSupplierCost)],
              ['Total Profit', _money(report.summary.totalProfit)],
              ['Average Order Profit', _money(report.summary.averageOrderProfit)],
              [
                'Profit Margin',
                report.summary.profitMarginPercent == null
                    ? '—'
                    : '${report.summary.profitMarginPercent!.toStringAsFixed(2)}%',
              ],
              ['Customer Refunds', _money(report.summary.totalRefunds)],
              ['Supplier Credits', _money(report.summary.totalSupplierCredits)],
            ],
          ),
          pw.SizedBox(height: 20),
          pw.Text(
            'Shop Performance',
            style: pw.TextStyle(
              fontSize: 16,
              fontWeight: pw.FontWeight.bold,
            ),
          ),
          pw.SizedBox(height: 8),
          pw.TableHelper.fromTextArray(
            headers: const [
              'Shop',
              'Orders',
              'Earnings',
              'Supplier Cost',
              'Profit',
            ],
            data: report.shopPerformance
                .map(
                  (row) => [
                    row.shopName,
                    row.orderCount.toString(),
                    _money(row.totalEarnings),
                    _money(row.totalSupplierCost),
                    _money(row.totalProfit),
                  ],
                )
                .toList(),
          ),
          pw.SizedBox(height: 20),
          pw.Text(
            'Top Products',
            style: pw.TextStyle(
              fontSize: 16,
              fontWeight: pw.FontWeight.bold,
            ),
          ),
          pw.SizedBox(height: 8),
          pw.TableHelper.fromTextArray(
            headers: const ['SKU', 'Product', 'Orders', 'Qty', 'Profit'],
            data: report.productPerformance
                .take(20)
                .map(
                  (row) => [
                    row.sku,
                    row.productName,
                    row.orderCount.toString(),
                    row.quantity.toString(),
                    _money(row.totalProfit),
                  ],
                )
                .toList(),
          ),
          pw.SizedBox(height: 20),
          pw.Text(
            'Order Detail',
            style: pw.TextStyle(
              fontSize: 16,
              fontWeight: pw.FontWeight.bold,
            ),
          ),
          pw.SizedBox(height: 8),
          pw.TableHelper.fromTextArray(
            cellStyle: const pw.TextStyle(fontSize: 7),
            headerStyle: pw.TextStyle(
              fontSize: 7,
              fontWeight: pw.FontWeight.bold,
            ),
            headers: const [
              'Date',
              'Order ID',
              'Shop',
              'SKU',
              'Earnings',
              'Cost',
              'Profit',
            ],
            data: report.orders
                .map(
                  (row) => [
                    _date(row.orderDate),
                    row.orderId,
                    row.shopName,
                    row.sku,
                    _money(row.tiktokEarning),
                    _money(row.supplierCost),
                    _money(row.profit),
                  ],
                )
                .toList(),
          ),
        ],
      ),
    );

    final directory = await getApplicationDocumentsDirectory();
    final file = File(
      '${directory.path}/FiTech_Report_${_fileDate(DateTime.now())}.pdf',
    );
    await file.writeAsBytes(await document.save(), flush: true);
    return file;
  }

  String _money(double value) => '£${value.toStringAsFixed(2)}';

  String _date(DateTime value) =>
      value.toLocal().toString().split(' ').first;

  String _fileDate(DateTime value) =>
      value.toIso8601String().replaceAll(':', '-').split('.').first;
}
