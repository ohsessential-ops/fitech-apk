import 'dart:io';

import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';

import '../domain/report_models.dart';

class ExcelReportService {
  Future<File> generate(ManagementReport report) async {
    final excel = Excel.createExcel();
    final summarySheet = excel['Summary'];
    final shopSheet = excel['Shop Performance'];
    final productSheet = excel['Product Performance'];
    final ordersSheet = excel['Orders'];

    summarySheet.appendRow([
      TextCellValue('FiTech Management Report'),
      TextCellValue('Powered by Faizan'),
    ]);
    summarySheet.appendRow([
      TextCellValue('Period'),
      TextCellValue(
        '${_date(report.filter.startDate)} to '
        '${_date(report.filter.endDateExclusive.subtract(const Duration(days: 1)))}',
      ),
    ]);
    summarySheet.appendRow([]);
    summarySheet.appendRow([
      TextCellValue('Metric'),
      TextCellValue('Value'),
    ]);
    summarySheet.appendRow([
      TextCellValue('Total Orders'),
      IntCellValue(report.summary.totalOrders),
    ]);
    summarySheet.appendRow([
      TextCellValue('TikTok Net Earnings'),
      DoubleCellValue(report.summary.totalEarnings),
    ]);
    summarySheet.appendRow([
      TextCellValue('Supplier Cost'),
      DoubleCellValue(report.summary.totalSupplierCost),
    ]);
    summarySheet.appendRow([
      TextCellValue('Profit'),
      DoubleCellValue(report.summary.totalProfit),
    ]);
    summarySheet.appendRow([
      TextCellValue('Average Order Profit'),
      DoubleCellValue(report.summary.averageOrderProfit),
    ]);
    summarySheet.appendRow([
      TextCellValue('Profit Margin %'),
      DoubleCellValue(report.summary.profitMarginPercent ?? 0),
    ]);
    summarySheet.appendRow([
      TextCellValue('Customer Refunds'),
      DoubleCellValue(report.summary.totalRefunds),
    ]);
    summarySheet.appendRow([
      TextCellValue('Supplier Credits'),
      DoubleCellValue(report.summary.totalSupplierCredits),
    ]);

    shopSheet.appendRow([
      TextCellValue('Shop'),
      TextCellValue('Orders'),
      TextCellValue('TikTok Earnings'),
      TextCellValue('Supplier Cost'),
      TextCellValue('Profit'),
    ]);
    for (final row in report.shopPerformance) {
      shopSheet.appendRow([
        TextCellValue(row.shopName),
        IntCellValue(row.orderCount),
        DoubleCellValue(row.totalEarnings),
        DoubleCellValue(row.totalSupplierCost),
        DoubleCellValue(row.totalProfit),
      ]);
    }

    productSheet.appendRow([
      TextCellValue('SKU'),
      TextCellValue('Product'),
      TextCellValue('Orders'),
      TextCellValue('Quantity'),
      TextCellValue('Profit'),
    ]);
    for (final row in report.productPerformance) {
      productSheet.appendRow([
        TextCellValue(row.sku),
        TextCellValue(row.productName),
        IntCellValue(row.orderCount),
        IntCellValue(row.quantity),
        DoubleCellValue(row.totalProfit),
      ]);
    }

    ordersSheet.appendRow([
      TextCellValue('Date'),
      TextCellValue('Order ID'),
      TextCellValue('Shop'),
      TextCellValue('SKU'),
      TextCellValue('Quantity'),
      TextCellValue('TikTok Earnings'),
      TextCellValue('Supplier Cost'),
      TextCellValue('Profit'),
      TextCellValue('Tracking'),
    ]);
    for (final row in report.orders) {
      ordersSheet.appendRow([
        TextCellValue(_date(row.orderDate)),
        TextCellValue(row.orderId),
        TextCellValue(row.shopName),
        TextCellValue(row.sku),
        IntCellValue(row.quantity),
        DoubleCellValue(row.tiktokEarning),
        DoubleCellValue(row.supplierCost),
        DoubleCellValue(row.profit),
        TextCellValue(row.trackingNumber ?? ''),
      ]);
    }

    final defaultSheet = excel.getDefaultSheet();
    if (defaultSheet != null && defaultSheet != 'Summary') {
      excel.delete(defaultSheet);
    }

    final bytes = excel.encode();
    if (bytes == null) {
      throw StateError('Could not generate Excel report.');
    }

    final directory = await getApplicationDocumentsDirectory();
    final file = File(
      '${directory.path}/FiTech_Report_${_fileDate(DateTime.now())}.xlsx',
    );
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }

  String _date(DateTime value) =>
      value.toLocal().toString().split(' ').first;

  String _fileDate(DateTime value) =>
      value.toIso8601String().replaceAll(':', '-').split('.').first;
}
