import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../../../core/utils/money.dart';
import '../../../domain/models/shop.dart';
import '../../entries/data/financial_order_repository.dart';
import '../data/report_repository.dart';
import '../domain/report_models.dart';
import '../services/excel_report_service.dart';
import '../services/pdf_report_service.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  final reportRepository = ReportRepository();
  final orderRepository = FinancialOrderRepository();
  final pdfService = PdfReportService();
  final excelService = ExcelReportService();

  DateTime startDate = DateTime(DateTime.now().year, DateTime.now().month, 1);
  DateTime endDateExclusive = DateTime.now().add(const Duration(days: 1));
  Shop? selectedShop;
  late Future<List<Shop>> shops;
  late Future<ManagementReport> report;
  bool exporting = false;

  @override
  void initState() {
    super.initState();
    shops = orderRepository.getActiveShops();
    report = loadReport();
  }

  Future<ManagementReport> loadReport() {
    return reportRepository.generate(
      ReportFilter(
        startDate: startDate,
        endDateExclusive: endDateExclusive,
        shopId: selectedShop?.id,
      ),
    );
  }

  void refresh() => setState(() => report = loadReport());

  Future<void> chooseDateRange() async {
    final range = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      initialDateRange: DateTimeRange(
        start: startDate,
        end: endDateExclusive.subtract(const Duration(days: 1)),
      ),
    );
    if (range == null) return;
    setState(() {
      startDate = DateTime(range.start.year, range.start.month, range.start.day);
      endDateExclusive = DateTime(
        range.end.year,
        range.end.month,
        range.end.day,
      ).add(const Duration(days: 1));
      report = loadReport();
    });
  }

  Future<void> exportPdf(ManagementReport value) async {
    setState(() => exporting = true);
    try {
      final file = await pdfService.generate(value);
      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'FiTech management report',
      );
    } finally {
      if (mounted) setState(() => exporting = false);
    }
  }

  Future<void> exportExcel(ManagementReport value) async {
    setState(() => exporting = true);
    try {
      final file = await excelService.generate(value);
      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'FiTech Excel report',
      );
    } finally {
      if (mounted) setState(() => exporting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Reports and analytics')),
      body: FutureBuilder<List<Shop>>(
        future: shops,
        builder: (context, shopSnapshot) {
          if (!shopSnapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          return FutureBuilder<ManagementReport>(
            future: report,
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return const Center(child: CircularProgressIndicator());
              }

              final value = snapshot.data!;
              return RefreshIndicator(
                onRefresh: () async => refresh(),
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 10, 16, 100),
                  children: [
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            ListTile(
                              contentPadding: EdgeInsets.zero,
                              title: const Text('Report period'),
                              subtitle: Text(
                                '${startDate.toString().split(' ').first} to '
                                '${endDateExclusive.subtract(const Duration(days: 1)).toString().split(' ').first}',
                              ),
                              trailing:
                                  const Icon(Icons.calendar_month_outlined),
                              onTap: chooseDateRange,
                            ),
                            DropdownButtonFormField<Shop?>(
                              value: selectedShop,
                              decoration:
                                  const InputDecoration(labelText: 'Shop'),
                              items: [
                                const DropdownMenuItem<Shop?>(
                                  value: null,
                                  child: Text('All shops'),
                                ),
                                for (final shop in shopSnapshot.data!)
                                  DropdownMenuItem<Shop?>(
                                    value: shop,
                                    child: Text(shop.name),
                                  ),
                              ],
                              onChanged: (shop) {
                                setState(() {
                                  selectedShop = shop;
                                  report = loadReport();
                                });
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        FilledButton.icon(
                          onPressed:
                              exporting ? null : () => exportPdf(value),
                          icon: const Icon(Icons.picture_as_pdf_outlined),
                          label: const Text('Export PDF'),
                        ),
                        OutlinedButton.icon(
                          onPressed:
                              exporting ? null : () => exportExcel(value),
                          icon: const Icon(Icons.table_view_outlined),
                          label: const Text('Export Excel'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    _SummaryGrid(summary: value.summary),
                    const SizedBox(height: 18),
                    _ProfitChart(points: value.dailyProfit),
                    const SizedBox(height: 18),
                    Text(
                      'Shop performance',
                      style:
                          Theme.of(context).textTheme.titleLarge?.copyWith(
                                fontWeight: FontWeight.w800,
                              ),
                    ),
                    const SizedBox(height: 10),
                    if (value.shopPerformance.isEmpty)
                      const Card(
                        child: ListTile(
                          title: Text('No shop data for this period'),
                        ),
                      ),
                    for (final shop in value.shopPerformance) ...[
                      Card(
                        child: ListTile(
                          contentPadding: const EdgeInsets.all(16),
                          title: Text(
                            shop.shopName,
                            style:
                                const TextStyle(fontWeight: FontWeight.w800),
                          ),
                          subtitle: Text(
                            '${shop.orderCount} orders • '
                            'Earnings ${Money.gbp(shop.totalEarnings)}',
                          ),
                          trailing: Text(
                            Money.gbp(shop.totalProfit),
                            style: TextStyle(
                              fontWeight: FontWeight.w800,
                              color: shop.totalProfit < 0
                                  ? Theme.of(context).colorScheme.error
                                  : null,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                    ],
                    const SizedBox(height: 8),
                    Text(
                      'Top products',
                      style:
                          Theme.of(context).textTheme.titleLarge?.copyWith(
                                fontWeight: FontWeight.w800,
                              ),
                    ),
                    const SizedBox(height: 10),
                    for (final product
                        in value.productPerformance.take(10)) ...[
                      Card(
                        child: ListTile(
                          contentPadding: const EdgeInsets.all(16),
                          title: Text(
                            product.productName,
                            style:
                                const TextStyle(fontWeight: FontWeight.w800),
                          ),
                          subtitle: Text(
                            '${product.sku} • ${product.quantity} units',
                          ),
                          trailing: Text(
                            Money.gbp(product.totalProfit),
                            style:
                                const TextStyle(fontWeight: FontWeight.w800),
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                    ],
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class _SummaryGrid extends StatelessWidget {
  const _SummaryGrid({required this.summary});

  final ReportSummary summary;

  @override
  Widget build(BuildContext context) {
    final items = [
      ('Orders', summary.totalOrders.toString()),
      ('Net earnings', Money.gbp(summary.totalEarnings)),
      ('Supplier cost', Money.gbp(summary.totalSupplierCost)),
      ('Profit', Money.gbp(summary.totalProfit)),
      ('Average profit', Money.gbp(summary.averageOrderProfit)),
      (
        'Margin',
        summary.profitMarginPercent == null
            ? '—'
            : '${summary.profitMarginPercent!.toStringAsFixed(2)}%',
      ),
      ('Refunds', Money.gbp(summary.totalRefunds)),
      ('Supplier credits', Money.gbp(summary.totalSupplierCredits)),
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 1.65,
      ),
      itemBuilder: (context, index) {
        final item = items[index];
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(item.$1),
                const SizedBox(height: 5),
                Text(
                  item.$2,
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w900,
                      ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _ProfitChart extends StatelessWidget {
  const _ProfitChart({required this.points});

  final List<DailyProfitPoint> points;

  @override
  Widget build(BuildContext context) {
    if (points.isEmpty) {
      return const Card(
        child: SizedBox(
          height: 220,
          child: Center(child: Text('No profit trend data')),
        ),
      );
    }

    final spots = [
      for (var index = 0; index < points.length; index++)
        FlSpot(index.toDouble(), points[index].profit),
    ];

    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 18, 18, 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Daily profit trend',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
            ),
            const SizedBox(height: 18),
            SizedBox(
              height: 220,
              child: LineChart(
                LineChartData(
                  gridData: const FlGridData(show: true),
                  titlesData: const FlTitlesData(
                    topTitles:
                        AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    rightTitles:
                        AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  ),
                  lineBarsData: [
                    LineChartBarData(
                      spots: spots,
                      isCurved: true,
                      barWidth: 3,
                      dotData: const FlDotData(show: false),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
