import 'package:flutter/material.dart';

import '../data/settings_repository.dart';

class EnterpriseSettingsScreen extends StatefulWidget {
  const EnterpriseSettingsScreen({super.key});

  @override
  State<EnterpriseSettingsScreen> createState() =>
      _EnterpriseSettingsScreenState();
}

class _EnterpriseSettingsScreenState
    extends State<EnterpriseSettingsScreen> {
  final repository = SettingsRepository();
  late Future<Map<String, String>> settings;

  @override
  void initState() {
    super.initState();
    settings = repository.getAll();
  }

  void refresh() => setState(() => settings = repository.getAll());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Enterprise settings')),
      body: FutureBuilder<Map<String, String>>(
        future: settings,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final values = snapshot.data!;

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _SettingTile(
                title: 'Company name',
                value: values['company_name'] ?? 'FiTech',
                onChanged: (value) async {
                  await repository.setValue('company_name', value);
                  refresh();
                },
              ),
              _SettingTile(
                title: 'Currency',
                value: values['currency'] ?? 'GBP',
                onChanged: (value) async {
                  await repository.setValue('currency', value);
                  refresh();
                },
              ),
              SwitchListTile(
                title: const Text('Biometric login'),
                subtitle: const Text(
                  'Requires platform biometric configuration',
                ),
                value: values['biometric_enabled'] == 'true',
                onChanged: (value) async {
                  await repository.setValue(
                    'biometric_enabled',
                    value.toString(),
                  );
                  refresh();
                },
              ),
              SwitchListTile(
                title: const Text('Cloud synchronization'),
                subtitle: const Text(
                  'Requires Firebase configuration files',
                ),
                value: values['cloud_sync_enabled'] == 'true',
                onChanged: (value) async {
                  await repository.setValue(
                    'cloud_sync_enabled',
                    value.toString(),
                  );
                  refresh();
                },
              ),
              SwitchListTile(
                title: const Text('Automatic backup'),
                value: values['automatic_backup_enabled'] == 'true',
                onChanged: (value) async {
                  await repository.setValue(
                    'automatic_backup_enabled',
                    value.toString(),
                  );
                  refresh();
                },
              ),
              ListTile(
                title: const Text('Session timeout'),
                subtitle: Text(
                  '${values['session_timeout_minutes'] ?? '30'} minutes',
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _SettingTile extends StatelessWidget {
  const _SettingTile({
    required this.title,
    required this.value,
    required this.onChanged,
  });

  final String title;
  final String value;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(title),
      subtitle: Text(value),
      trailing: const Icon(Icons.edit_outlined),
      onTap: () async {
        final controller = TextEditingController(text: value);
        final changed = await showDialog<String>(
          context: context,
          builder: (context) => AlertDialog(
            title: Text(title),
            content: TextField(controller: controller),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () =>
                    Navigator.of(context).pop(controller.text.trim()),
                child: const Text('Save'),
              ),
            ],
          ),
        );
        controller.dispose();
        if (changed != null && changed.isNotEmpty) onChanged(changed);
      },
    );
  }
}
