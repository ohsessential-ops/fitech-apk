import 'package:sqflite/sqflite.dart';

import '../../../core/database/database_service.dart';

class SettingsRepository {
  SettingsRepository({DatabaseService? databaseService})
      : _databaseService = databaseService ?? DatabaseService.instance;

  final DatabaseService _databaseService;

  Future<Map<String, String>> getAll() async {
    final db = await _databaseService.database;
    final rows = await db.query('app_settings');
    return {
      for (final row in rows)
        row['setting_key'] as String: (row['setting_value'] as String?) ?? '',
    };
  }

  Future<void> setValue(String key, String value) async {
    final db = await _databaseService.database;
    await db.insert(
      'app_settings',
      {
        'setting_key': key,
        'setting_value': value,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }
}
