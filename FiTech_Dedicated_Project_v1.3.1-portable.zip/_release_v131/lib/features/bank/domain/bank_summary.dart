class BankSummary {
  const BankSummary({
    required this.calculatedBalance,
    required this.latestActualBalance,
    required this.latestDifference,
  });

  final double calculatedBalance;
  final double? latestActualBalance;
  final double? latestDifference;
}
