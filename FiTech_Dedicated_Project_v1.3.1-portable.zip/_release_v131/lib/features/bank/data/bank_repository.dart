import '../../../core/database/database_service.dart';
import '../../../domain/models/bank_ledger_entry.dart';
import '../../../domain/models/bank_reconciliation.dart';
import '../domain/bank_summary.dart';

class BankRepository {
  BankRepository({DatabaseService? databaseService})
      : _databaseService = databaseService ?? DatabaseService.instance;

  final DatabaseService _databaseService;

  Future<int> addLedgerEntry(BankLedgerEntry entry) async {
    final db = await _databaseService.database;
    return db.insert('bank_ledger_entries', entry.toMap());
  }

  Future<List<BankLedgerEntry>> getEntries({int limit = 200}) async {
    final db = await _databaseService.database;
    final rows = await db.query(
      'bank_ledger_entries',
      orderBy: 'entry_date DESC, id DESC',
      limit: limit,
    );
    return rows.map(BankLedgerEntry.fromMap).toList();
  }

  Future<double> calculatedBalance() async {
    final db = await _databaseService.database;
    final rows = await db.rawQuery('''
      SELECT
        COALESCE(SUM(inflow_gbp), 0)
        - COALESCE(SUM(outflow_gbp), 0) AS balance
      FROM bank_ledger_entries
    ''');
    return (rows.first['balance'] as num).toDouble();
  }

  Future<BankReconciliation?> latestReconciliation() async {
    final db = await _databaseService.database;
    final rows = await db.query(
      'bank_reconciliations',
      orderBy: 'reconciliation_date DESC, id DESC',
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return BankReconciliation.fromMap(rows.first);
  }

  Future<BankSummary> getSummary() async {
    final calculated = await calculatedBalance();
    final reconciliation = await latestReconciliation();
    return BankSummary(
      calculatedBalance: calculated,
      latestActualBalance: reconciliation?.actualBankBalanceGbp,
      latestDifference: reconciliation?.differenceGbp,
    );
  }

  Future<int> reconcile({
    required DateTime date,
    required double actualBalanceGbp,
    String? notes,
  }) async {
    final db = await _databaseService.database;
    final calculated = await calculatedBalance();
    final difference = actualBalanceGbp - calculated;

    return db.insert(
      'bank_reconciliations',
      BankReconciliation(
        reconciliationDate: date,
        actualBankBalanceGbp: actualBalanceGbp,
        calculatedBankBalanceGbp: calculated,
        differenceGbp: difference,
        notes: notes,
        createdAt: DateTime.now(),
      ).toMap(),
    );
  }
}
