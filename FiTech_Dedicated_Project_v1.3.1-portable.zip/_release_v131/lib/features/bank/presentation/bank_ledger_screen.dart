import 'package:flutter/material.dart';

import '../../../core/utils/money.dart';
import '../../../domain/models/bank_ledger_entry.dart';
import '../data/bank_repository.dart';
import '../domain/bank_summary.dart';

class BankLedgerScreen extends StatefulWidget {
  const BankLedgerScreen({super.key});

  @override
  State<BankLedgerScreen> createState() => _BankLedgerScreenState();
}

class _BankLedgerScreenState extends State<BankLedgerScreen> {
  final repository = BankRepository();
  late Future<_BankViewData> data;

  @override
  void initState() {
    super.initState();
    data = load();
  }

  Future<_BankViewData> load() async => _BankViewData(
        summary: await repository.getSummary(),
        entries: await repository.getEntries(),
      );

  void refresh() => setState(() => data = load());

  Future<void> addEntry({required bool inflow}) async {
    final amount = TextEditingController();
    final description = TextEditingController();
    final notes = TextEditingController();

    final saved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(inflow ? 'Add bank inflow' : 'Add bank outflow'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: amount,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: 'Amount',
                prefixText: '£ ',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: description,
              decoration: const InputDecoration(labelText: 'Description'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: notes,
              decoration:
                  const InputDecoration(labelText: 'Notes (optional)'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () async {
              final value = double.tryParse(amount.text.trim());
              if (value == null || value <= 0 || description.text.trim().isEmpty) {
                return;
              }
              await repository.addLedgerEntry(
                BankLedgerEntry(
                  entryDate: DateTime.now(),
                  type: inflow
                      ? BankLedgerType.manualInflow
                      : BankLedgerType.manualOutflow,
                  description: description.text.trim(),
                  inflowGbp: inflow ? value : 0,
                  outflowGbp: inflow ? 0 : value,
                  notes: notes.text.trim().isEmpty ? null : notes.text.trim(),
                  createdAt: DateTime.now(),
                ),
              );
              if (context.mounted) Navigator.of(context).pop(true);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );

    amount.dispose();
    description.dispose();
    notes.dispose();
    if (saved == true) refresh();
  }

  Future<void> reconcile() async {
    final actual = TextEditingController();
    final notes = TextEditingController();

    final saved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Reconcile bank balance'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: actual,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: 'Actual bank balance',
                prefixText: '£ ',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: notes,
              decoration:
                  const InputDecoration(labelText: 'Notes (optional)'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () async {
              final value = double.tryParse(actual.text.trim());
              if (value == null) return;
              await repository.reconcile(
                date: DateTime.now(),
                actualBalanceGbp: value,
                notes: notes.text.trim().isEmpty ? null : notes.text.trim(),
              );
              if (context.mounted) Navigator.of(context).pop(true);
            },
            child: const Text('Reconcile'),
          ),
        ],
      ),
    );

    actual.dispose();
    notes.dispose();
    if (saved == true) refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bank ledger')),
      body: FutureBuilder<_BankViewData>(
        future: data,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final value = snapshot.data!;

          return RefreshIndicator(
            onRefresh: () async => refresh(),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 100),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Calculated FiTech cash'),
                        Text(
                          Money.gbp(value.summary.calculatedBalance),
                          style: Theme.of(context)
                              .textTheme
                              .headlineMedium
                              ?.copyWith(fontWeight: FontWeight.w900),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          value.summary.latestActualBalance == null
                              ? 'No real bank balance reconciliation yet'
                              : 'Latest actual bank balance: '
                                  '${Money.gbp(value.summary.latestActualBalance!)}',
                        ),
                        if (value.summary.latestDifference != null)
                          Text(
                            'Difference: '
                            '${Money.gbp(value.summary.latestDifference!)}',
                          ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    FilledButton.icon(
                      onPressed: () => addEntry(inflow: true),
                      icon: const Icon(Icons.add),
                      label: const Text('Add inflow'),
                    ),
                    OutlinedButton.icon(
                      onPressed: () => addEntry(inflow: false),
                      icon: const Icon(Icons.remove),
                      label: const Text('Add outflow'),
                    ),
                    OutlinedButton.icon(
                      onPressed: reconcile,
                      icon: const Icon(Icons.account_balance),
                      label: const Text('Reconcile'),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                Text(
                  'Bank activity',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w800,
                      ),
                ),
                const SizedBox(height: 10),
                if (value.entries.isEmpty)
                  const Card(
                    child: ListTile(title: Text('No bank entries yet')),
                  ),
                for (final entry in value.entries) ...[
                  Card(
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(16),
                      title: Text(
                        entry.description,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      subtitle:
                          Text(entry.entryDate.toString().split(' ').first),
                      trailing: Text(
                        '${entry.inflowGbp > 0 ? '+' : '-'}'
                        '${Money.gbp(entry.inflowGbp > 0 ? entry.inflowGbp : entry.outflowGbp)}',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          color: entry.outflowGbp > 0
                              ? Theme.of(context).colorScheme.error
                              : null,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                ],
              ],
            ),
          );
        },
      ),
    );
  }
}

class _BankViewData {
  const _BankViewData({required this.summary, required this.entries});
  final BankSummary summary;
  final List<BankLedgerEntry> entries;
}
