import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../../../core/backup/backup_service.dart';
import '../../../core/sync/sync_service.dart';
import '../../audit/presentation/audit_log_screen.dart';
import '../../settings/presentation/enterprise_settings_screen.dart';
import '../../users/presentation/users_screen.dart';

class SystemCenterScreen extends StatefulWidget {
  const SystemCenterScreen({super.key});

  @override
  State<SystemCenterScreen> createState() => _SystemCenterScreenState();
}

class _SystemCenterScreenState extends State<SystemCenterScreen> {
  final backupService = BackupService();
  final syncService = SyncService();
  late Future<int> pendingSync;

  @override
  void initState() {
    super.initState();
    pendingSync = syncService.pendingCount();
  }

  Future<void> backup() async {
    final file = await backupService.createLocalBackup();
    if (!mounted) return;
    await Share.shareXFiles(
      [XFile(file.path)],
      text: 'FiTech verified local backup',
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('System and security')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          FutureBuilder<int>(
            future: pendingSync,
            builder: (context, snapshot) => Card(
              child: ListTile(
                leading: const CircleAvatar(
                  child: Icon(Icons.sync),
                ),
                title: const Text('Offline sync queue'),
                subtitle: Text(
                  '${snapshot.data ?? 0} pending records',
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Card(
            child: ListTile(
              leading: const CircleAvatar(
                child: Icon(Icons.people_outline),
              ),
              title: const Text('Users and roles'),
              subtitle: const Text('Owner, admin, manager, staff and more'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const UsersScreen()),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Card(
            child: ListTile(
              leading: const CircleAvatar(
                child: Icon(Icons.history),
              ),
              title: const Text('Audit log'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const AuditLogScreen()),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Card(
            child: ListTile(
              leading: const CircleAvatar(
                child: Icon(Icons.settings_outlined),
              ),
              title: const Text('Enterprise settings'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const EnterpriseSettingsScreen(),
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Card(
            child: ListTile(
              leading: const CircleAvatar(
                child: Icon(Icons.backup_outlined),
              ),
              title: const Text('Create verified local backup'),
              subtitle: const Text('Copies and verifies the SQLite database'),
              trailing: const Icon(Icons.chevron_right),
              onTap: backup,
            ),
          ),
          const SizedBox(height: 10),
          const Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Icon(Icons.cloud_outlined),
              ),
              title: Text('Firebase cloud sync'),
              subtitle: Text(
                'Foundation included. Add Firebase project files to activate.',
              ),
            ),
          ),
        ],
      ),
    );
  }
}
