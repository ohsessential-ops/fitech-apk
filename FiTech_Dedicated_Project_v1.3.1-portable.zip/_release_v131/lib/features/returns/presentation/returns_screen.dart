import 'package:flutter/material.dart';

import '../../../core/utils/money.dart';
import '../../../domain/models/financial_order.dart';
import '../../../domain/models/return_record.dart';
import '../data/return_repository.dart';
import '../domain/adjusted_profit_calculator.dart';

class ReturnsScreen extends StatefulWidget {
  const ReturnsScreen({super.key});

  @override
  State<ReturnsScreen> createState() => _ReturnsScreenState();
}

class _ReturnsScreenState extends State<ReturnsScreen> {
  final repository = ReturnRepository();
  late Future<List<ReturnRecord>> returns;

  @override
  void initState() {
    super.initState();
    returns = repository.getReturns();
  }

  void refresh() => setState(() => returns = repository.getReturns());

  Future<void> addReturn() async {
    final orderId = TextEditingController();
    FinancialOrder? order;

    final found = await showDialog<FinancialOrder?>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Find order'),
        content: TextField(
          controller: orderId,
          decoration: const InputDecoration(labelText: 'TikTok Order ID'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () async {
              final result = await repository.findOrderById(orderId.text);
              if (context.mounted) Navigator.of(context).pop(result);
            },
            child: const Text('Find'),
          ),
        ],
      ),
    );
    orderId.dispose();

    if (found == null || !mounted) {
      if (found == null && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Order not found.')),
        );
      }
      return;
    }
    order = found;

    final refund = TextEditingController();
    final supplierCredit = TextEditingController(
      text: const AdjustedProfitCalculator()
          .suggestedSupplierCredit(
            supplierCost: order.supplierTotalCostGbp,
          )
          .toStringAsFixed(2),
    );
    final adjustment = TextEditingController(text: '0');
    final reason = TextEditingController();
    final notes = TextEditingController();

    final saved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Return ${order!.tiktokOrderId}'),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: refund,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: 'Customer refund',
                  prefixText: '£ ',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: supplierCredit,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: 'Supplier credit',
                  prefixText: '£ ',
                  helperText: '60% suggestion only—confirm actual amount',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: adjustment,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: 'Other adjustment',
                  prefixText: '£ ',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: reason,
                decoration: const InputDecoration(labelText: 'Reason'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: notes,
                decoration:
                    const InputDecoration(labelText: 'Notes (optional)'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () async {
              await repository.createReturn(
                order: order!,
                returnDate: DateTime.now(),
                reason: reason.text.trim().isEmpty ? null : reason.text.trim(),
                customerRefundGbp:
                    double.tryParse(refund.text.trim()) ?? 0,
                supplierCreditGbp:
                    double.tryParse(supplierCredit.text.trim()) ?? 0,
                otherAdjustmentGbp:
                    double.tryParse(adjustment.text.trim()) ?? 0,
                notes: notes.text.trim().isEmpty ? null : notes.text.trim(),
              );
              if (context.mounted) Navigator.of(context).pop(true);
            },
            child: const Text('Save return'),
          ),
        ],
      ),
    );

    refund.dispose();
    supplierCredit.dispose();
    adjustment.dispose();
    reason.dispose();
    notes.dispose();
    if (saved == true) refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Returns')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: addReturn,
        icon: const Icon(Icons.assignment_return_outlined),
        label: const Text('Add return'),
      ),
      body: FutureBuilder<List<ReturnRecord>>(
        future: returns,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final items = snapshot.data!;
          if (items.isEmpty) {
            return const Center(child: Text('No returns recorded.'));
          }

          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              final item = items[index];
              return Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.all(16),
                  title: Text(
                    item.orderId,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: Text(
                    'Refund ${Money.gbp(item.customerRefundGbp)}'
                    ' • Supplier credit ${Money.gbp(item.supplierCreditGbp)}',
                  ),
                  trailing: Text(
                    Money.gbp(item.adjustedProfitGbp),
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      color: item.adjustedProfitGbp < 0
                          ? Theme.of(context).colorScheme.error
                          : null,
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
