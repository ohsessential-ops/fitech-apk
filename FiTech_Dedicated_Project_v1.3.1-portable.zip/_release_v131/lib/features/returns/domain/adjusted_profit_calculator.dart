class AdjustedProfitCalculator {
  const AdjustedProfitCalculator();

  double calculate({
    required double originalProfit,
    required double customerRefund,
    required double supplierCredit,
    double otherAdjustment = 0,
  }) {
    final result = originalProfit -
        customerRefund +
        supplierCredit +
        otherAdjustment;
    return (result * 100).roundToDouble() / 100;
  }

  double suggestedSupplierCredit({
    required double supplierCost,
    double percentage = 0.60,
  }) {
    final result = supplierCost * percentage;
    return (result * 100).roundToDouble() / 100;
  }
}
