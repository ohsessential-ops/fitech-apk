import '../../../core/database/database_service.dart';
import '../../../domain/models/financial_order.dart';
import '../../../domain/models/return_record.dart';
import '../domain/adjusted_profit_calculator.dart';

class ReturnRepository {
  ReturnRepository({
    DatabaseService? databaseService,
  }) : _databaseService = databaseService ?? DatabaseService.instance;

  final DatabaseService _databaseService;
  final _calculator = const AdjustedProfitCalculator();

  Future<FinancialOrder?> findOrderById(String orderId) async {
    final db = await _databaseService.database;
    final rows = await db.rawQuery('''
      SELECT o.*, s.name AS shop_name
      FROM financial_orders o
      INNER JOIN shops s ON s.id = o.shop_id
      WHERE o.tiktok_order_id = ? AND o.deleted_at IS NULL
      LIMIT 1
    ''', [orderId.trim()]);

    if (rows.isEmpty) return null;
    return FinancialOrder.fromJoinedMap(rows.first);
  }

  Future<int> createReturn({
    required FinancialOrder order,
    required DateTime returnDate,
    String? reason,
    required double customerRefundGbp,
    required double supplierCreditGbp,
    required double otherAdjustmentGbp,
    String? notes,
  }) async {
    final db = await _databaseService.database;
    final adjustedProfit = _calculator.calculate(
      originalProfit: order.calculatedProfitGbp,
      customerRefund: customerRefundGbp,
      supplierCredit: supplierCreditGbp,
      otherAdjustment: otherAdjustmentGbp,
    );

    return db.transaction((txn) async {
      final returnId = await txn.insert('returns', {
        'financial_order_id': order.id,
        'return_date': returnDate.toIso8601String(),
        'reason': reason,
        'customer_refund_gbp': customerRefundGbp,
        'supplier_credit_gbp': supplierCreditGbp,
        'other_adjustment_gbp': otherAdjustmentGbp,
        'adjusted_profit_gbp': adjustedProfit,
        'notes': notes,
        'created_at': DateTime.now().toUtc().toIso8601String(),
      });

      if (customerRefundGbp > 0) {
        await txn.insert('bank_ledger_entries', {
          'entry_date': returnDate.toIso8601String(),
          'type': 'customerRefund',
          'reference_type': 'financial_order',
          'reference_id': order.tiktokOrderId,
          'description': 'Customer refund: ${order.tiktokOrderId}',
          'inflow_gbp': 0,
          'outflow_gbp': customerRefundGbp,
          'notes': notes,
          'created_at': DateTime.now().toUtc().toIso8601String(),
        });
      }

      if (supplierCreditGbp > 0) {
        final suppliers = await txn.query(
          'suppliers',
          where: 'is_active = 1',
          orderBy: 'id ASC',
          limit: 1,
        );
        if (suppliers.isNotEmpty) {
          await txn.insert('supplier_ledger_entries', {
            'supplier_id': suppliers.first['id'],
            'entry_date': returnDate.toIso8601String(),
            'type': 'supplierCredit',
            'reference_type': 'return',
            'reference_id': returnId.toString(),
            'description': 'Return credit: ${order.tiktokOrderId}',
            'debit_gbp': 0,
            'credit_gbp': supplierCreditGbp,
            'notes': notes,
            'created_at': DateTime.now().toUtc().toIso8601String(),
          });
        }
      }

      await txn.update(
        'financial_orders',
        {
          'calculated_profit_gbp': adjustedProfit,
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        },
        where: 'id = ?',
        whereArgs: [order.id],
      );

      return returnId;
    });
  }

  Future<List<ReturnRecord>> getReturns() async {
    final db = await _databaseService.database;
    final rows = await db.rawQuery('''
      SELECT r.*, o.tiktok_order_id
      FROM returns r
      INNER JOIN financial_orders o ON o.id = r.financial_order_id
      ORDER BY r.return_date DESC, r.id DESC
    ''');

    return rows.map((map) {
      return ReturnRecord(
        id: map['id'] as int,
        financialOrderId: map['financial_order_id'] as int,
        orderId: map['tiktok_order_id'] as String,
        returnDate: DateTime.parse(map['return_date'] as String),
        reason: map['reason'] as String?,
        customerRefundGbp:
            (map['customer_refund_gbp'] as num).toDouble(),
        supplierCreditGbp:
            (map['supplier_credit_gbp'] as num).toDouble(),
        otherAdjustmentGbp:
            (map['other_adjustment_gbp'] as num).toDouble(),
        adjustedProfitGbp:
            (map['adjusted_profit_gbp'] as num).toDouble(),
        notes: map['notes'] as String?,
        createdAt: DateTime.parse(map['created_at'] as String),
      );
    }).toList();
  }
}
