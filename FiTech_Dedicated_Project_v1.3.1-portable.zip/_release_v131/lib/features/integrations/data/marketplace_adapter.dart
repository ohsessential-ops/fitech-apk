import '../domain/marketplace_models.dart';
class ConnectionTestResult { const ConnectionTestResult({required this.success, required this.message}); final bool success; final String message; }
abstract class MarketplaceAdapter {
  MarketplaceType get marketplace;
  Future<ConnectionTestResult> testConnection(MarketplaceAccount account, Map<String,String> credentials);
  Future<List<Map<String,Object?>>> fetchOrders(MarketplaceAccount account,{DateTime? since});
  Future<ConnectionTestResult> pushTracking(MarketplaceAccount account,String orderId,String tracking,String carrier);
  Future<List<Map<String,Object?>>> fetchPayouts(MarketplaceAccount account,{DateTime? since});
}
class PlaceholderMarketplaceAdapter implements MarketplaceAdapter {
  PlaceholderMarketplaceAdapter(this.marketplace); @override final MarketplaceType marketplace;
  @override Future<ConnectionTestResult> testConnection(MarketplaceAccount account,Map<String,String> credentials) async {
    await Future<void>.delayed(const Duration(milliseconds: 350));
    return credentials.values.any((v)=>v.trim().isNotEmpty)
      ? const ConnectionTestResult(success:true,message:'Configuration accepted. Live API verification activates after official OAuth credentials are enabled.')
      : const ConnectionTestResult(success:false,message:'Add API credentials before testing this connection.');
  }
  @override Future<List<Map<String,Object?>>> fetchOrders(MarketplaceAccount account,{DateTime? since}) async => const [];
  @override Future<ConnectionTestResult> pushTracking(MarketplaceAccount account,String orderId,String tracking,String carrier) async => const ConnectionTestResult(success:false,message:'Official API authorization is required.');
  @override Future<List<Map<String,Object?>>> fetchPayouts(MarketplaceAccount account,{DateTime? since}) async => const [];
}
class MarketplaceAdapterFactory { static MarketplaceAdapter create(MarketplaceType type)=>PlaceholderMarketplaceAdapter(type); }
