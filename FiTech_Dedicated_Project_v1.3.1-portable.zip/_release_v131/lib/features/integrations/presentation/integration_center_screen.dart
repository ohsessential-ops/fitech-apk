import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';
import '../../../shared/widgets/empty_state.dart';
import '../../../shared/widgets/professional_menu_card.dart';
import '../../../shared/widgets/raised_3d_button.dart';
import '../data/marketplace_repository.dart';
import '../domain/marketplace_models.dart';
import 'integration_logs_screen.dart';
import 'marketplace_account_screen.dart';
import 'sync_history_screen.dart';

class IntegrationCenterScreen extends StatefulWidget {
  const IntegrationCenterScreen({super.key});

  @override
  State<IntegrationCenterScreen> createState() =>
      _IntegrationCenterScreenState();
}

class _IntegrationCenterScreenState extends State<IntegrationCenterScreen> {
  final repository = MarketplaceRepository();

  Future<void> open(Widget screen) async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => screen),
    );
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Marketplace integrations')),
      body: FutureBuilder<List<MarketplaceAccount>>(
        future: repository.accounts(),
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return EmptyState(
              icon: Icons.error_outline,
              title: 'Unable to load integrations',
              message: snapshot.error.toString(),
              actionLabel: 'Try again',
              onAction: () => setState(() {}),
            );
          }

          final accounts = snapshot.data ?? const <MarketplaceAccount>[];
          final columns = MediaQuery.sizeOf(context).width > 700 ? 3 : 2;

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [AppTheme.deepNavy, AppTheme.navy],
                  ),
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Connect every sales channel',
                      style: Theme.of(context)
                          .textTheme
                          .headlineSmall
                          ?.copyWith(color: Colors.white),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Prepare order imports, tracking exports and payouts '
                      'in one workspace.',
                      style: TextStyle(color: Color(0xFFCBD5E1)),
                    ),
                    const SizedBox(height: 16),
                    Raised3DButton(
                      label: 'Add marketplace account',
                      icon: Icons.add_link,
                      onPressed: () => open(
                        const MarketplaceAccountScreen(),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              GridView.count(
                crossAxisCount: columns,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.05,
                children: [
                  ProfessionalMenuCard(
                    icon: Icons.sync,
                    title: 'Sync history',
                    subtitle: 'Queued and completed jobs',
                    onTap: () => open(const SyncHistoryScreen()),
                  ),
                  ProfessionalMenuCard(
                    icon: Icons.receipt_long,
                    title: 'Integration logs',
                    subtitle: 'Connection and error events',
                    onTap: () => open(const IntegrationLogsScreen()),
                  ),
                  ProfessionalMenuCard(
                    icon: Icons.security,
                    title: 'Credential safety',
                    subtitle: 'Production encryption required',
                    onTap: () => showDialog<void>(
                      context: context,
                      builder: (_) => const AlertDialog(
                        title: Text('Credential safety'),
                        content: Text(
                          'Development credentials are local placeholders. '
                          'Production release requires Android Keystore-backed '
                          'encrypted storage.',
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 22),
              Text(
                'Marketplace accounts',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 10),
              if (accounts.isEmpty)
                EmptyState(
                  icon: Icons.hub_outlined,
                  title: 'No marketplace accounts',
                  message: 'Add TikTok Shop, Amazon, eBay, Etsy or Wayfair.',
                  actionLabel: 'Add account',
                  onAction: () => open(const MarketplaceAccountScreen()),
                )
              else
                ...accounts.map(
                  (account) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Card(
                      child: ListTile(
                        contentPadding: const EdgeInsets.all(16),
                        leading: const CircleAvatar(
                          backgroundColor: AppTheme.sky,
                          child: Icon(
                            Icons.storefront,
                            color: AppTheme.blue,
                          ),
                        ),
                        title: Text(
                          account.accountName,
                          style: const TextStyle(fontWeight: FontWeight.w900),
                        ),
                        subtitle: Text(
                          '${account.marketplace.label} • ${account.region} • '
                          '${account.status.name}',
                        ),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => open(
                          MarketplaceAccountScreen(account: account),
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}
