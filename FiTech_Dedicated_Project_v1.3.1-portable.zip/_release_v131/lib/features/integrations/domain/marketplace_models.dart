enum MarketplaceType { tiktokShop, amazon, ebay, etsy, wayfair }
enum ConnectionStatus { notConfigured, configured, connected, error, expired }
enum SyncDirection { inbound, outbound, bidirectional }
enum SyncJobType { orders, tracking, payouts, inventory }
enum SyncJobStatus { queued, running, completed, failed, cancelled }

extension MarketplaceTypeX on MarketplaceType {
  String get label => switch (this) {
    MarketplaceType.tiktokShop => 'TikTok Shop', MarketplaceType.amazon => 'Amazon',
    MarketplaceType.ebay => 'eBay', MarketplaceType.etsy => 'Etsy', MarketplaceType.wayfair => 'Wayfair',
  };
  String get code => switch (this) {
    MarketplaceType.tiktokShop => 'tiktok_shop', MarketplaceType.amazon => 'amazon',
    MarketplaceType.ebay => 'ebay', MarketplaceType.etsy => 'etsy', MarketplaceType.wayfair => 'wayfair',
  };
  static MarketplaceType fromCode(String code) => MarketplaceType.values.firstWhere(
    (value) => value.code == code, orElse: () => MarketplaceType.tiktokShop);
}

class MarketplaceAccount {
  const MarketplaceAccount({this.id, required this.marketplace, required this.accountName,
    this.shopReference, this.region = 'UK', this.status = ConnectionStatus.notConfigured,
    this.autoOrderSync = false, this.autoTrackingSync = false, this.autoPayoutSync = false,
    this.lastTestedAt, this.lastSyncAt, this.notes});
  final int? id; final MarketplaceType marketplace; final String accountName; final String? shopReference;
  final String region; final ConnectionStatus status; final bool autoOrderSync, autoTrackingSync, autoPayoutSync;
  final DateTime? lastTestedAt, lastSyncAt; final String? notes;
  factory MarketplaceAccount.fromMap(Map<String, Object?> map) => MarketplaceAccount(
    id: map['id'] as int?, marketplace: MarketplaceTypeX.fromCode(map['marketplace'] as String),
    accountName: map['account_name'] as String, shopReference: map['shop_reference'] as String?,
    region: map['region'] as String? ?? 'UK', status: ConnectionStatus.values.firstWhere(
      (value) => value.name == map['connection_status'], orElse: () => ConnectionStatus.notConfigured),
    autoOrderSync: (map['auto_order_sync'] as int? ?? 0) == 1,
    autoTrackingSync: (map['auto_tracking_sync'] as int? ?? 0) == 1,
    autoPayoutSync: (map['auto_payout_sync'] as int? ?? 0) == 1,
    lastTestedAt: map['last_tested_at'] == null ? null : DateTime.parse(map['last_tested_at'] as String),
    lastSyncAt: map['last_sync_at'] == null ? null : DateTime.parse(map['last_sync_at'] as String),
    notes: map['notes'] as String?);
}

class MarketplaceSyncJob {
  const MarketplaceSyncJob({this.id, required this.accountId, required this.type, required this.direction,
    required this.status, this.recordsFound = 0, this.recordsProcessed = 0, this.recordsFailed = 0,
    this.message, this.startedAt, this.completedAt});
  final int? id; final int accountId; final SyncJobType type; final SyncDirection direction;
  final SyncJobStatus status; final int recordsFound, recordsProcessed, recordsFailed;
  final String? message; final DateTime? startedAt, completedAt;
  factory MarketplaceSyncJob.fromMap(Map<String, Object?> map) => MarketplaceSyncJob(
    id: map['id'] as int?, accountId: map['account_id'] as int,
    type: SyncJobType.values.byName(map['job_type'] as String),
    direction: SyncDirection.values.byName(map['direction'] as String),
    status: SyncJobStatus.values.byName(map['status'] as String),
    recordsFound: (map['records_found'] as num? ?? 0).toInt(),
    recordsProcessed: (map['records_processed'] as num? ?? 0).toInt(),
    recordsFailed: (map['records_failed'] as num? ?? 0).toInt(), message: map['message'] as String?,
    startedAt: map['started_at'] == null ? null : DateTime.parse(map['started_at'] as String),
    completedAt: map['completed_at'] == null ? null : DateTime.parse(map['completed_at'] as String));
}
