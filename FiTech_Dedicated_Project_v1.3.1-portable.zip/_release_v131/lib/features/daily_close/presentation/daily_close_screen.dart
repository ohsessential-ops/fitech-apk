import 'package:flutter/material.dart';

import '../data/daily_close_repository.dart';
import '../domain/daily_close_summary.dart';

class DailyCloseScreen extends StatefulWidget {
  const DailyCloseScreen({super.key});

  @override
  State<DailyCloseScreen> createState() => _DailyCloseScreenState();
}

class _DailyCloseScreenState extends State<DailyCloseScreen> {
  final repository = DailyCloseRepository();
  final notesController = TextEditingController();
  DateTime selectedDate = DateTime.now();
  bool closing = false;

  Future<void> closeDay(DailyCloseSummary summary) async {
    setState(() => closing = true);
    try {
      await repository.closeDay(summary, notes: notesController.text);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Daily close saved successfully.')),
      );
      setState(() {});
    } finally {
      if (mounted) setState(() => closing = false);
    }
  }

  Widget metric(String label, String value) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Text(
              value,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
            ),
            const SizedBox(height: 4),
            Text(label, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daily business close'),
        actions: [
          IconButton(
            onPressed: () async {
              final picked = await showDatePicker(
                context: context,
                initialDate: selectedDate,
                firstDate: DateTime(2020),
                lastDate: DateTime.now(),
              );
              if (picked != null) setState(() => selectedDate = picked);
            },
            icon: const Icon(Icons.calendar_month_outlined),
          ),
        ],
      ),
      body: FutureBuilder<DailyCloseSummary>(
        future: repository.preview(selectedDate),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final summary = snapshot.data!;

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text(
                summary.date.toLocal().toString().split(' ').first,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w900,
                    ),
              ),
              const SizedBox(height: 12),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                childAspectRatio: 1.7,
                children: [
                  metric('Orders', summary.orders.toString()),
                  metric('Profit', '£${summary.profit.toStringAsFixed(2)}'),
                  metric(
                    'Earnings',
                    '£${summary.earnings.toStringAsFixed(2)}',
                  ),
                  metric(
                    'Supplier cost',
                    '£${summary.supplierCost.toStringAsFixed(2)}',
                  ),
                  metric(
                    'Supplier balance',
                    '£${summary.supplierBalance.toStringAsFixed(2)}',
                  ),
                  metric(
                    'Bank balance',
                    '£${summary.bankBalance.toStringAsFixed(2)}',
                  ),
                  metric('Missing tracking', summary.missingTracking.toString()),
                  metric(
                    'Loss orders',
                    summary.negativeProfitOrders.toString(),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              TextField(
                controller: notesController,
                minLines: 3,
                maxLines: 5,
                decoration: const InputDecoration(
                  labelText: 'Closing notes',
                  hintText: 'Problems, actions and important observations',
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                height: 54,
                child: FilledButton.icon(
                  onPressed: closing ? null : () => closeDay(summary),
                  icon: const Icon(Icons.lock_clock_outlined),
                  label: Text(
                    closing ? 'Saving…' : 'Complete daily close',
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Text(
                'Recent closes',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w900,
                    ),
              ),
              const SizedBox(height: 8),
              FutureBuilder<List<Map<String, Object?>>>(
                future: repository.history(),
                builder: (context, historySnapshot) {
                  if (!historySnapshot.hasData) {
                    return const LinearProgressIndicator();
                  }
                  return Column(
                    children: historySnapshot.data!
                        .map(
                          (item) => Card(
                            child: ListTile(
                              title: Text(
                                (item['close_date'] as String).split('T').first,
                              ),
                              subtitle: Text(
                                '${item['orders_count']} orders • '
                                '£${(item['profit_gbp'] as num).toStringAsFixed(2)} profit',
                              ),
                            ),
                          ),
                        )
                        .toList(),
                  );
                },
              ),
            ],
          );
        },
      ),
    );
  }
}
