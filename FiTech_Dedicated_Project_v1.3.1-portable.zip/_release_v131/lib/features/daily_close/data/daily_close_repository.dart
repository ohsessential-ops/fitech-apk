import '../../../core/database/database_service.dart';
import '../domain/daily_close_summary.dart';

class DailyCloseRepository {
  DailyCloseRepository({DatabaseService? databaseService})
      : _databaseService = databaseService ?? DatabaseService.instance;

  final DatabaseService _databaseService;

  Future<DailyCloseSummary> preview(DateTime date) async {
    final db = await _databaseService.database;
    final start = DateTime(date.year, date.month, date.day);
    final end = start.add(const Duration(days: 1));

    final orderRows = await db.rawQuery('''
      SELECT
        COUNT(*) AS orders,
        COALESCE(SUM(tiktok_net_earning_gbp), 0) AS earnings,
        COALESCE(SUM(supplier_total_cost_gbp), 0) AS supplier_cost,
        COALESCE(SUM(calculated_profit_gbp), 0) AS profit,
        COALESCE(SUM(CASE WHEN calculated_profit_gbp < 0 THEN 1 ELSE 0 END), 0)
          AS negative_profit,
        COALESCE(SUM(
          CASE WHEN tracking_number IS NULL OR TRIM(tracking_number) = ''
          THEN 1 ELSE 0 END
        ), 0) AS missing_tracking
      FROM financial_orders
      WHERE deleted_at IS NULL
        AND order_date >= ?
        AND order_date < ?
    ''', [start.toIso8601String(), end.toIso8601String()]);

    final returnRows = await db.rawQuery('''
      SELECT COALESCE(SUM(customer_refund_gbp), 0) AS refunds
      FROM returns
      WHERE return_date >= ? AND return_date < ?
    ''', [start.toIso8601String(), end.toIso8601String()]);

    final supplierRows = await db.rawQuery('''
      SELECT COALESCE(SUM(debit_gbp), 0)
             - COALESCE(SUM(credit_gbp), 0) AS balance
      FROM supplier_ledger_entries
    ''');

    final bankRows = await db.rawQuery('''
      SELECT COALESCE(SUM(inflow_gbp), 0)
             - COALESCE(SUM(outflow_gbp), 0) AS balance
      FROM bank_ledger_entries
    ''');

    final order = orderRows.first;
    return DailyCloseSummary(
      date: start,
      orders: (order['orders'] as num).toInt(),
      earnings: (order['earnings'] as num).toDouble(),
      supplierCost: (order['supplier_cost'] as num).toDouble(),
      profit: (order['profit'] as num).toDouble(),
      refunds: (returnRows.first['refunds'] as num).toDouble(),
      supplierBalance: (supplierRows.first['balance'] as num).toDouble(),
      bankBalance: (bankRows.first['balance'] as num).toDouble(),
      missingTracking: (order['missing_tracking'] as num).toInt(),
      negativeProfitOrders: (order['negative_profit'] as num).toInt(),
    );
  }

  Future<void> closeDay(
    DailyCloseSummary summary, {
    String? notes,
  }) async {
    final db = await _databaseService.database;
    final closeDate =
        DateTime(summary.date.year, summary.date.month, summary.date.day)
            .toIso8601String();

    await db.transaction((txn) async {
      await txn.rawInsert('''
        INSERT INTO daily_close_records (
          close_date, orders_count, earnings_gbp, supplier_cost_gbp,
          profit_gbp, refunds_gbp, supplier_balance_gbp, bank_balance_gbp,
          missing_tracking_count, negative_profit_count, notes, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(close_date) DO UPDATE SET
          orders_count = excluded.orders_count,
          earnings_gbp = excluded.earnings_gbp,
          supplier_cost_gbp = excluded.supplier_cost_gbp,
          profit_gbp = excluded.profit_gbp,
          refunds_gbp = excluded.refunds_gbp,
          supplier_balance_gbp = excluded.supplier_balance_gbp,
          bank_balance_gbp = excluded.bank_balance_gbp,
          missing_tracking_count = excluded.missing_tracking_count,
          negative_profit_count = excluded.negative_profit_count,
          notes = excluded.notes,
          created_at = excluded.created_at
      ''', [
        closeDate,
        summary.orders,
        summary.earnings,
        summary.supplierCost,
        summary.profit,
        summary.refunds,
        summary.supplierBalance,
        summary.bankBalance,
        summary.missingTracking,
        summary.negativeProfitOrders,
        notes,
        DateTime.now().toUtc().toIso8601String(),
      ]);

      await txn.insert('app_activity', {
        'activity_type': 'daily_close',
        'title': 'Daily close completed',
        'description':
            '${summary.orders} orders • £${summary.profit.toStringAsFixed(2)} profit',
        'reference_type': 'daily_close',
        'reference_id': closeDate,
        'created_at': DateTime.now().toUtc().toIso8601String(),
      });
    });
  }

  Future<List<Map<String, Object?>>> history() async {
    final db = await _databaseService.database;
    return db.query(
      'daily_close_records',
      orderBy: 'close_date DESC',
      limit: 90,
    );
  }
}
