class DailyCloseSummary {
  const DailyCloseSummary({
    required this.date,
    required this.orders,
    required this.earnings,
    required this.supplierCost,
    required this.profit,
    required this.refunds,
    required this.supplierBalance,
    required this.bankBalance,
    required this.missingTracking,
    required this.negativeProfitOrders,
  });

  final DateTime date;
  final int orders;
  final double earnings;
  final double supplierCost;
  final double profit;
  final double refunds;
  final double supplierBalance;
  final double bankBalance;
  final int missingTracking;
  final int negativeProfitOrders;
}
