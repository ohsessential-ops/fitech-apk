import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../../../core/database/database_service.dart';
import '../../../domain/models/app_user.dart';
import '../domain/auth_session.dart';

class AuthException implements Exception {
  const AuthException(this.message);
  final String message;
}

class AuthRepository {
  AuthRepository({
    DatabaseService? databaseService,
    FlutterSecureStorage? secureStorage,
  })  : _databaseService = databaseService ?? DatabaseService.instance,
        _secureStorage = secureStorage ?? const FlutterSecureStorage();

  final DatabaseService _databaseService;
  final FlutterSecureStorage _secureStorage;

  static const _sessionUserIdKey = 'fitech_session_user_id';
  static const _sessionExpiresKey = 'fitech_session_expires';

  String hashPassword(String password) =>
      sha256.convert(utf8.encode(password)).toString();

  Future<AuthSession> signIn({
    required String email,
    required String password,
    int sessionTimeoutMinutes = 30,
  }) async {
    final db = await _databaseService.database;
    final rows = await db.query(
      'app_users',
      where: 'LOWER(email) = LOWER(?) AND is_active = 1',
      whereArgs: [email.trim()],
      limit: 1,
    );

    if (rows.isEmpty) {
      throw const AuthException('Invalid email or password.');
    }

    final row = rows.first;
    if (row['password_hash'] != hashPassword(password)) {
      throw const AuthException('Invalid email or password.');
    }

    final now = DateTime.now();
    final expiresAt = now.add(Duration(minutes: sessionTimeoutMinutes));
    final user = AppUser.fromMap(row);

    await db.update(
      'app_users',
      {'last_login_at': now.toUtc().toIso8601String()},
      where: 'id = ?',
      whereArgs: [user.id],
    );

    await _secureStorage.write(
      key: _sessionUserIdKey,
      value: user.id.toString(),
    );
    await _secureStorage.write(
      key: _sessionExpiresKey,
      value: expiresAt.toUtc().toIso8601String(),
    );

    return AuthSession(
      user: user,
      authenticatedAt: now,
      expiresAt: expiresAt,
    );
  }

  Future<AuthSession?> restoreSession() async {
    final userId = await _secureStorage.read(key: _sessionUserIdKey);
    final expiresText = await _secureStorage.read(key: _sessionExpiresKey);
    if (userId == null || expiresText == null) return null;

    final expiresAt = DateTime.parse(expiresText).toLocal();
    if (DateTime.now().isAfter(expiresAt)) {
      await signOut();
      return null;
    }

    final db = await _databaseService.database;
    final rows = await db.query(
      'app_users',
      where: 'id = ? AND is_active = 1',
      whereArgs: [int.parse(userId)],
      limit: 1,
    );
    if (rows.isEmpty) {
      await signOut();
      return null;
    }

    return AuthSession(
      user: AppUser.fromMap(rows.first),
      authenticatedAt: DateTime.now(),
      expiresAt: expiresAt,
    );
  }

  Future<void> signOut() async {
    await _secureStorage.delete(key: _sessionUserIdKey);
    await _secureStorage.delete(key: _sessionExpiresKey);
  }
}
