import '../../../domain/models/app_user.dart';

class AuthSession {
  const AuthSession({
    required this.user,
    required this.authenticatedAt,
    required this.expiresAt,
  });

  final AppUser user;
  final DateTime authenticatedAt;
  final DateTime expiresAt;

  bool get isExpired => DateTime.now().isAfter(expiresAt);
}
