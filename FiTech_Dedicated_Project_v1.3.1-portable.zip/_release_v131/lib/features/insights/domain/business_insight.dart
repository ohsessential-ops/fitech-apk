import 'package:flutter/material.dart';

enum InsightSeverity { info, warning, critical, positive }

class BusinessInsight {
  const BusinessInsight({
    required this.title,
    required this.message,
    required this.severity,
    required this.icon,
  });

  final String title;
  final String message;
  final InsightSeverity severity;
  final IconData icon;
}
