import 'package:flutter/material.dart';

import '../../../core/database/database_service.dart';
import '../domain/business_insight.dart';

class InsightRepository {
  InsightRepository({DatabaseService? databaseService})
      : _databaseService = databaseService ?? DatabaseService.instance;

  final DatabaseService _databaseService;

  Future<List<BusinessInsight>> generateInsights() async {
    final db = await _databaseService.database;
    final insights = <BusinessInsight>[];
    final now = DateTime.now();
    final monthStart = DateTime(now.year, now.month, 1);
    final previousMonthStart = DateTime(now.year, now.month - 1, 1);

    final currentRows = await db.rawQuery('''
      SELECT
        COUNT(*) AS orders,
        COALESCE(SUM(calculated_profit_gbp), 0) AS profit,
        COALESCE(SUM(tiktok_net_earning_gbp), 0) AS earnings
      FROM financial_orders
      WHERE deleted_at IS NULL
        AND order_date >= ?
    ''', [monthStart.toIso8601String()]);

    final previousRows = await db.rawQuery('''
      SELECT
        COUNT(*) AS orders,
        COALESCE(SUM(calculated_profit_gbp), 0) AS profit
      FROM financial_orders
      WHERE deleted_at IS NULL
        AND order_date >= ?
        AND order_date < ?
    ''', [
      previousMonthStart.toIso8601String(),
      monthStart.toIso8601String(),
    ]);

    final currentProfit = (currentRows.first['profit'] as num).toDouble();
    final previousProfit = (previousRows.first['profit'] as num).toDouble();
    final currentOrders = (currentRows.first['orders'] as num).toInt();

    if (currentOrders == 0) {
      insights.add(
        const BusinessInsight(
          title: 'No orders this month',
          message: 'Add or import recent orders to keep analytics accurate.',
          severity: InsightSeverity.warning,
          icon: Icons.inbox_outlined,
        ),
      );
    } else if (currentProfit > previousProfit) {
      final increase = previousProfit == 0
          ? 100
          : ((currentProfit - previousProfit) / previousProfit.abs()) * 100;
      insights.add(
        BusinessInsight(
          title: 'Profit is improving',
          message:
              'Current-month profit is ${increase.toStringAsFixed(1)}% higher than the previous month.',
          severity: InsightSeverity.positive,
          icon: Icons.trending_up,
        ),
      );
    } else if (currentProfit < previousProfit) {
      final decrease = previousProfit == 0
          ? 0
          : ((previousProfit - currentProfit) / previousProfit.abs()) * 100;
      insights.add(
        BusinessInsight(
          title: 'Profit has slowed',
          message:
              'Current-month profit is ${decrease.toStringAsFixed(1)}% lower than the previous month.',
          severity: InsightSeverity.warning,
          icon: Icons.trending_down,
        ),
      );
    }

    final lossRows = await db.rawQuery('''
      SELECT COUNT(*) AS count
      FROM financial_orders
      WHERE deleted_at IS NULL
        AND calculated_profit_gbp < 0
        AND order_date >= ?
    ''', [monthStart.toIso8601String()]);
    final lossOrders = (lossRows.first['count'] as num).toInt();
    if (lossOrders > 0) {
      insights.add(
        BusinessInsight(
          title: '$lossOrders loss-making orders',
          message:
              'Review supplier cost, TikTok earnings and refund adjustments.',
          severity: InsightSeverity.critical,
          icon: Icons.warning_amber_rounded,
        ),
      );
    }

    final missingTrackingRows = await db.rawQuery('''
      SELECT COUNT(*) AS count
      FROM financial_orders
      WHERE deleted_at IS NULL
        AND (tracking_number IS NULL OR TRIM(tracking_number) = '')
        AND order_date >= ?
    ''', [monthStart.toIso8601String()]);
    final missingTracking =
        (missingTrackingRows.first['count'] as num).toInt();
    if (missingTracking > 0) {
      insights.add(
        BusinessInsight(
          title: '$missingTracking orders need tracking',
          message:
              'Add tracking numbers to improve delivery monitoring and evidence.',
          severity: InsightSeverity.warning,
          icon: Icons.local_shipping_outlined,
        ),
      );
    }

    final supplierRows = await db.rawQuery('''
      SELECT
        COALESCE(SUM(debit_gbp), 0)
        - COALESCE(SUM(credit_gbp), 0) AS balance
      FROM supplier_ledger_entries
    ''');
    final supplierBalance =
        (supplierRows.first['balance'] as num).toDouble();
    if (supplierBalance > 0) {
      insights.add(
        BusinessInsight(
          title: 'Supplier payment due',
          message:
              'Current supplier balance is £${supplierBalance.toStringAsFixed(2)}.',
          severity: InsightSeverity.info,
          icon: Icons.account_balance_wallet_outlined,
        ),
      );
    }

    final returnRows = await db.rawQuery('''
      SELECT COUNT(*) AS count
      FROM returns
      WHERE return_date >= ?
    ''', [monthStart.toIso8601String()]);
    final returnsCount = (returnRows.first['count'] as num).toInt();
    if (returnsCount > 0) {
      insights.add(
        BusinessInsight(
          title: '$returnsCount returns this month',
          message:
              'Check that every customer refund has a matching supplier credit.',
          severity: InsightSeverity.info,
          icon: Icons.assignment_return_outlined,
        ),
      );
    }

    if (insights.isEmpty) {
      insights.add(
        const BusinessInsight(
          title: 'Business data looks healthy',
          message: 'No major issues were detected in the current records.',
          severity: InsightSeverity.positive,
          icon: Icons.verified_outlined,
        ),
      );
    }

    return insights;
  }
}
