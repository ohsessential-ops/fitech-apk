import 'package:flutter/material.dart';

import '../data/insight_repository.dart';
import '../domain/business_insight.dart';

class InsightsScreen extends StatelessWidget {
  const InsightsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final repository = InsightRepository();

    return Scaffold(
      appBar: AppBar(title: const Text('Smart business insights')),
      body: FutureBuilder<List<BusinessInsight>>(
        future: repository.generateInsights(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: snapshot.data!.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              final item = snapshot.data![index];
              final color = switch (item.severity) {
                InsightSeverity.critical =>
                  Theme.of(context).colorScheme.error,
                InsightSeverity.warning =>
                  Theme.of(context).colorScheme.tertiary,
                InsightSeverity.positive =>
                  Theme.of(context).colorScheme.primary,
                InsightSeverity.info =>
                  Theme.of(context).colorScheme.secondary,
              };

              return Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.all(18),
                  leading: CircleAvatar(
                    backgroundColor: color.withValues(alpha: 0.12),
                    child: Icon(
                      item.icon,
                      color: color,
                    ),
                  ),
                  title: Text(
                    item.title,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(item.message),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
