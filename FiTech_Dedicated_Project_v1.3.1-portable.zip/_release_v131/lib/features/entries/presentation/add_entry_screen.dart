import 'package:flutter/material.dart';

import '../../../core/utils/money.dart';
import '../../../domain/models/financial_order.dart';
import '../../../domain/models/product.dart';
import '../../../domain/models/shop.dart';
import '../../../domain/services/profit_calculator.dart';
import '../../products/data/product_repository.dart';
import '../../products/presentation/products_screen.dart';
import '../data/financial_order_repository.dart';

class AddEntryScreen extends StatefulWidget {
  const AddEntryScreen({super.key});

  @override
  State<AddEntryScreen> createState() => _AddEntryScreenState();
}

class _AddEntryScreenState extends State<AddEntryScreen> {
  final formKey = GlobalKey<FormState>();
  final orderRepository = FinancialOrderRepository();
  final productRepository = ProductRepository();
  final calculator = const ProfitCalculator();

  final orderId = TextEditingController();
  final sku = TextEditingController();
  final quantity = TextEditingController(text: '1');
  final earning = TextEditingController();
  final unitCost = TextEditingController();
  final tracking = TextEditingController();
  final adjustment = TextEditingController(text: '0');
  final notes = TextEditingController();

  late Future<List<Shop>> shopsFuture;
  Shop? selectedShop;
  Product? selectedProduct;
  DateTime orderDate = DateTime.now();
  bool saving = false;
  bool loadingCost = false;
  String? costMessage;

  @override
  void initState() {
    super.initState();
    shopsFuture = orderRepository.getActiveShops();
  }

  int get parsedQuantity => int.tryParse(quantity.text) ?? 0;
  double get parsedEarning => double.tryParse(earning.text) ?? 0;
  double get parsedUnitCost => double.tryParse(unitCost.text) ?? 0;
  double get parsedAdjustment => double.tryParse(adjustment.text) ?? 0;
  double get totalCost => parsedQuantity * parsedUnitCost;

  ProfitResult get result => calculator.calculate(
        tiktokNetEarning: parsedEarning,
        supplierTotalCost: totalCost,
        manualAdjustment: parsedAdjustment,
      );

  Future<void> lookupProduct() async {
    final value = sku.text.trim();
    if (value.isEmpty) return;

    setState(() {
      loadingCost = true;
      costMessage = null;
    });

    final product = await productRepository.findBySku(value);
    if (product == null) {
      if (!mounted) return;
      setState(() {
        selectedProduct = null;
        loadingCost = false;
        costMessage = 'SKU not found. Add the product first or enter cost manually.';
      });
      return;
    }

    final cost = await productRepository.costForProductOnDate(
      productId: product.id!,
      date: orderDate,
    );

    if (!mounted) return;
    setState(() {
      selectedProduct = product;
      loadingCost = false;
      if (cost == null) {
        costMessage = 'Product found, but no cost applies to this order date.';
      } else {
        unitCost.text = cost.toStringAsFixed(2);
        costMessage =
            'Cost selected automatically from dated history for ${product.productName}.';
      }
    });
  }

  Future<void> pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: orderDate,
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null) {
      setState(() => orderDate = picked);
      if (sku.text.trim().isNotEmpty) await lookupProduct();
    }
  }

  Future<void> save() async {
    if (!formKey.currentState!.validate() || selectedShop == null) return;
    setState(() => saving = true);

    try {
      final now = DateTime.now();
      await orderRepository.create(
        FinancialOrder(
          productId: selectedProduct?.id,
          shopId: selectedShop!.id,
          shopName: selectedShop!.name,
          tiktokOrderId: orderId.text.trim(),
          orderDate: orderDate,
          skuSnapshot: sku.text.trim(),
          productNameSnapshot: selectedProduct?.productName,
          variantSnapshot: selectedProduct?.variant,
          quantity: parsedQuantity,
          tiktokNetEarningGbp: parsedEarning,
          supplierUnitCostSnapshotGbp: parsedUnitCost,
          supplierTotalCostGbp: totalCost,
          manualAdjustmentGbp: parsedAdjustment,
          calculatedProfitGbp: result.profit,
          profitMarginPercent: result.marginPercent,
          trackingNumber:
              tracking.text.trim().isEmpty ? null : tracking.text.trim(),
          notes: notes.text.trim().isEmpty ? null : notes.text.trim(),
          createdAt: now,
          updatedAt: now,
        ),
      );

      if (!mounted) return;
      Navigator.of(context).pop(true);
    } on DuplicateOrderException {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('This TikTok Order ID already exists.')),
      );
      setState(() => saving = false);
    }
  }

  String? requiredField(String? value) =>
      value == null || value.trim().isEmpty ? 'Required' : null;

  @override
  Widget build(BuildContext context) {
    final isLoss = result.profit < 0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Add financial entry'),
        actions: [
          IconButton(
            tooltip: 'Products',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const ProductsScreen()),
            ),
            icon: const Icon(Icons.inventory_2_outlined),
          ),
        ],
      ),
      body: FutureBuilder<List<Shop>>(
        future: shopsFuture,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final shops = snapshot.data!;
          selectedShop ??= shops.first;

          return Form(
            key: formKey,
            child: ListView(
              padding: const EdgeInsets.all(18),
              children: [
                DropdownButtonFormField<Shop>(
                  value: selectedShop,
                  decoration: const InputDecoration(labelText: 'TikTok Shop'),
                  items: [
                    for (final shop in shops)
                      DropdownMenuItem(value: shop, child: Text(shop.name)),
                  ],
                  onChanged: (value) => setState(() => selectedShop = value),
                ),
                const SizedBox(height: 12),
                ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 8),
                  title: const Text('Order date'),
                  subtitle: Text(orderDate.toString().split(' ').first),
                  trailing: const Icon(Icons.calendar_month_outlined),
                  onTap: pickDate,
                ),
                const SizedBox(height: 6),
                TextFormField(
                  controller: orderId,
                  validator: requiredField,
                  decoration:
                      const InputDecoration(labelText: 'TikTok Order ID'),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: sku,
                  validator: requiredField,
                  textInputAction: TextInputAction.search,
                  onFieldSubmitted: (_) => lookupProduct(),
                  decoration: InputDecoration(
                    labelText: 'SKU',
                    suffixIcon: IconButton(
                      onPressed: loadingCost ? null : lookupProduct,
                      icon: loadingCost
                          ? const Padding(
                              padding: EdgeInsets.all(12),
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.search),
                    ),
                  ),
                ),
                if (costMessage != null) ...[
                  const SizedBox(height: 8),
                  Text(costMessage!),
                ],
                const SizedBox(height: 12),
                TextFormField(
                  controller: quantity,
                  keyboardType: TextInputType.number,
                  onChanged: (_) => setState(() {}),
                  validator: (value) {
                    final number = int.tryParse(value ?? '');
                    return number == null || number <= 0
                        ? 'Enter a valid quantity'
                        : null;
                  },
                  decoration: const InputDecoration(labelText: 'Quantity'),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: earning,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  onChanged: (_) => setState(() {}),
                  validator: requiredField,
                  decoration: const InputDecoration(
                    labelText: 'TikTok net earning',
                    prefixText: '£ ',
                    helperText: 'Already after TikTok deductions',
                  ),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: unitCost,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  onChanged: (_) => setState(() {}),
                  validator: requiredField,
                  decoration: const InputDecoration(
                    labelText: 'Supplier unit cost',
                    prefixText: '£ ',
                    helperText: 'Auto-filled from cost history when available',
                  ),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: adjustment,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  onChanged: (_) => setState(() {}),
                  decoration: const InputDecoration(
                    labelText: 'Manual adjustment',
                    prefixText: '£ ',
                  ),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: tracking,
                  decoration: const InputDecoration(
                    labelText: 'Tracking number (optional)',
                  ),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: notes,
                  maxLines: 3,
                  decoration:
                      const InputDecoration(labelText: 'Notes (optional)'),
                ),
                const SizedBox(height: 18),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      children: [
                        ListTile(
                          contentPadding: EdgeInsets.zero,
                          title: const Text('Supplier total cost'),
                          trailing: Text(
                            Money.gbp(totalCost),
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                        ),
                        ListTile(
                          contentPadding: EdgeInsets.zero,
                          title:
                              Text(isLoss ? 'Estimated loss' : 'Estimated profit'),
                          trailing: Text(
                            Money.gbp(result.profit),
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w800,
                              color: isLoss
                                  ? Theme.of(context).colorScheme.error
                                  : null,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                if (isLoss)
                  const Padding(
                    padding: EdgeInsets.only(top: 12),
                    child: Text(
                      'Warning: loss-making order. Review the values before saving.',
                    ),
                  ),
                const SizedBox(height: 18),
                SizedBox(
                  height: 54,
                  child: FilledButton(
                    onPressed: saving ? null : save,
                    child: Text(saving ? 'Saving…' : 'Save entry'),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
