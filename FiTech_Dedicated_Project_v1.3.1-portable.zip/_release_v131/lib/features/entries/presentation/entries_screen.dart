import 'package:flutter/material.dart';

import '../../../core/utils/money.dart';
import '../../../domain/models/financial_order.dart';
import '../data/financial_order_repository.dart';
import 'add_entry_screen.dart';

class EntriesScreen extends StatefulWidget {
  const EntriesScreen({super.key});

  @override
  State<EntriesScreen> createState() => _EntriesScreenState();
}

class _EntriesScreenState extends State<EntriesScreen> {
  final _repository = FinancialOrderRepository();
  final _searchController = TextEditingController();
  late Future<List<FinancialOrder>> _ordersFuture;

  @override
  void initState() {
    super.initState();
    _ordersFuture = _repository.getRecent();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _refresh() {
    setState(() {
      final query = _searchController.text.trim();
      _ordersFuture = query.isEmpty
          ? _repository.getRecent()
          : _repository.search(query);
    });
  }

  Future<void> _openAddEntry() async {
    final saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => const AddEntryScreen()),
    );
    if (saved == true) _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Financial entries')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openAddEntry,
        icon: const Icon(Icons.add),
        label: const Text('Add entry'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: TextField(
              controller: _searchController,
              textInputAction: TextInputAction.search,
              onSubmitted: (_) => _refresh(),
              decoration: InputDecoration(
                hintText: 'Search order, SKU, tracking or shop',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: IconButton(
                  onPressed: _refresh,
                  icon: const Icon(Icons.arrow_forward),
                ),
              ),
            ),
          ),
          Expanded(
            child: FutureBuilder<List<FinancialOrder>>(
              future: _ordersFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState != ConnectionState.done) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return Center(
                    child: Text('Could not load entries: ${snapshot.error}'),
                  );
                }

                final orders = snapshot.data ?? const [];
                if (orders.isEmpty) {
                  return const Center(child: Text('No financial entries found.'));
                }

                return RefreshIndicator(
                  onRefresh: () async => _refresh(),
                  child: ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 100),
                    itemCount: orders.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (context, index) {
                      final order = orders[index];
                      final isLoss = order.calculatedProfitGbp < 0;
                      return Card(
                        child: ListTile(
                          contentPadding: const EdgeInsets.all(16),
                          title: Text(
                            order.tiktokOrderId,
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                          subtitle: Text(
                            '${order.shopName} • ${order.skuSnapshot}\n'
                            '${order.orderDate.toLocal().toString().split(' ').first}',
                          ),
                          isThreeLine: true,
                          trailing: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                Money.gbp(order.calculatedProfitGbp),
                                style: TextStyle(
                                  fontWeight: FontWeight.w800,
                                  color: isLoss
                                      ? Theme.of(context).colorScheme.error
                                      : null,
                                ),
                              ),
                              Text(isLoss ? 'Loss' : 'Profit'),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
