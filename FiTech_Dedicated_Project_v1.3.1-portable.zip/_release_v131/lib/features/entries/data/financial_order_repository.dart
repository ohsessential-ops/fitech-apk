import 'package:sqflite/sqflite.dart';

import '../../../core/database/database_service.dart';
import '../../../domain/models/financial_order.dart';
import '../../../domain/models/shop.dart';

class DuplicateOrderException implements Exception {
  const DuplicateOrderException(this.orderId);
  final String orderId;
}

class FinancialOrderRepository {
  FinancialOrderRepository({DatabaseService? databaseService})
      : _databaseService = databaseService ?? DatabaseService.instance;

  final DatabaseService _databaseService;

  Future<List<Shop>> getActiveShops() async {
    final db = await _databaseService.database;
    final rows = await db.query(
      'shops',
      where: 'is_active = 1',
      orderBy: 'name COLLATE NOCASE',
    );
    return rows.map(Shop.fromMap).toList();
  }

  Future<int> create(FinancialOrder order) async {
    final db = await _databaseService.database;

    try {
      return await db.transaction((txn) async {
        final savedOrderId = await txn.insert(
          'financial_orders',
          order.toInsertMap(),
          conflictAlgorithm: ConflictAlgorithm.abort,
        );

        final suppliers = await txn.query(
          'suppliers',
          where: 'is_active = 1',
          orderBy: 'id ASC',
          limit: 1,
        );
        if (suppliers.isEmpty) {
          throw StateError('No active supplier is configured.');
        }

        await txn.insert('supplier_ledger_entries', {
          'supplier_id': suppliers.first['id'],
          'entry_date': order.orderDate.toIso8601String(),
          'type': 'orderDebit',
          'reference_type': 'financial_order',
          'reference_id': order.tiktokOrderId,
          'description': 'Order cost: ${order.tiktokOrderId}',
          'debit_gbp': order.supplierTotalCostGbp,
          'credit_gbp': 0,
          'notes': null,
          'created_at': DateTime.now().toUtc().toIso8601String(),
        });

        return savedOrderId;
      });
    } on DatabaseException catch (error) {
      if (error.isUniqueConstraintError()) {
        throw DuplicateOrderException(order.tiktokOrderId);
      }
      rethrow;
    }
  }

  Future<List<FinancialOrder>> getRecent({int limit = 25}) async {
    final db = await _databaseService.database;
    final rows = await db.rawQuery('''
      SELECT o.*, s.name AS shop_name
      FROM financial_orders o
      INNER JOIN shops s ON s.id = o.shop_id
      WHERE o.deleted_at IS NULL
      ORDER BY o.order_date DESC, o.id DESC
      LIMIT ?
    ''', [limit]);

    return rows.map(FinancialOrder.fromJoinedMap).toList();
  }

  Future<List<FinancialOrder>> search(String query) async {
    final db = await _databaseService.database;
    final term = '%${query.trim()}%';
    final rows = await db.rawQuery('''
      SELECT o.*, s.name AS shop_name
      FROM financial_orders o
      INNER JOIN shops s ON s.id = o.shop_id
      WHERE o.deleted_at IS NULL
        AND (
          o.tiktok_order_id LIKE ?
          OR o.sku_snapshot LIKE ?
          OR COALESCE(o.tracking_number, '') LIKE ?
          OR COALESCE(o.product_name_snapshot, '') LIKE ?
          OR s.name LIKE ?
        )
      ORDER BY o.order_date DESC, o.id DESC
    ''', [term, term, term, term, term]);

    return rows.map(FinancialOrder.fromJoinedMap).toList();
  }
}
