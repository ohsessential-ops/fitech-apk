import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';

enum Raised3DButtonStyle { primary, secondary, danger }

class Raised3DButton extends StatefulWidget {
  const Raised3DButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.style = Raised3DButtonStyle.primary,
    this.expand = false,
    this.height = 54,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final Raised3DButtonStyle style;
  final bool expand;
  final double height;

  @override
  State<Raised3DButton> createState() => _Raised3DButtonState();
}

class _Raised3DButtonState extends State<Raised3DButton> {
  bool pressed = false;

  Color get topColor => switch (widget.style) {
        Raised3DButtonStyle.primary => AppTheme.blue,
        Raised3DButtonStyle.secondary => Colors.white,
        Raised3DButtonStyle.danger => AppTheme.danger,
      };

  Color get bottomColor => switch (widget.style) {
        Raised3DButtonStyle.primary => AppTheme.blueDark,
        Raised3DButtonStyle.secondary => AppTheme.border,
        Raised3DButtonStyle.danger => const Color(0xFFAA2435),
      };

  Color get foreground => switch (widget.style) {
        Raised3DButtonStyle.secondary => AppTheme.navy,
        _ => Colors.white,
      };

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onPressed != null;

    return Semantics(
      button: true,
      enabled: enabled,
      label: widget.label,
      child: MouseRegion(
        cursor: enabled
            ? SystemMouseCursors.click
            : SystemMouseCursors.forbidden,
        child: GestureDetector(
          onTapDown: enabled ? (_) => setState(() => pressed = true) : null,
          onTapCancel: enabled ? () => setState(() => pressed = false) : null,
          onTapUp: enabled
              ? (_) {
                  setState(() => pressed = false);
                  widget.onPressed?.call();
                }
              : null,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 90),
            curve: Curves.easeOut,
            width: widget.expand ? double.infinity : null,
            height: widget.height + 5,
            padding: EdgeInsets.only(top: pressed ? 5 : 0),
            decoration: BoxDecoration(
              color: enabled ? bottomColor : AppTheme.border,
              borderRadius: BorderRadius.circular(17),
            ),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 90),
              height: widget.height,
              padding: const EdgeInsets.symmetric(horizontal: 18),
              decoration: BoxDecoration(
                color: enabled ? topColor : const Color(0xFFE8ECF2),
                borderRadius: BorderRadius.circular(16),
                border: widget.style == Raised3DButtonStyle.secondary
                    ? Border.all(color: AppTheme.border)
                    : null,
                boxShadow: pressed || !enabled
                    ? const []
                    : const [
                        BoxShadow(
                          color: Color(0x1C0B1F3A),
                          blurRadius: 12,
                          offset: Offset(0, 5),
                        ),
                      ],
              ),
              child: Row(
                mainAxisSize:
                    widget.expand ? MainAxisSize.max : MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (widget.icon != null) ...[
                    Icon(widget.icon, color: enabled ? foreground : AppTheme.textMuted),
                    const SizedBox(width: 10),
                  ],
                  Flexible(
                    child: Text(
                      widget.label,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: enabled ? foreground : AppTheme.textMuted,
                        fontWeight: FontWeight.w900,
                        fontSize: 15,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
