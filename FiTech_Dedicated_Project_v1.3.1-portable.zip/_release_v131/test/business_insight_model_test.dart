import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fitech/features/insights/domain/business_insight.dart';

void main() {
  test('business insight stores severity and message', () {
    const insight = BusinessInsight(
      title: 'Test',
      message: 'Business alert',
      severity: InsightSeverity.warning,
      icon: Icons.info_outline,
    );

    expect(insight.title, 'Test');
    expect(insight.severity, InsightSeverity.warning);
    expect(insight.icon, Icons.info_outline);
  });
}
