import 'package:flutter_test/flutter_test.dart';
import 'package:fitech/features/search/domain/global_search_result.dart';

void main() {
  test('global search result preserves record type', () {
    const result = GlobalSearchResult(
      type: GlobalSearchType.order,
      title: 'ORDER-1001',
      subtitle: 'Grey rug',
      reference: 'ORDER-1001',
      trailing: '£12.50',
    );

    expect(result.type, GlobalSearchType.order);
    expect(result.reference, 'ORDER-1001');
  });
}
