import 'package:flutter_test/flutter_test.dart';
import 'package:fitech/features/supplier/domain/supplier_balance.dart';

void main() {
  test('positive balance means supplier credit available', () {
    const result = SupplierBalance(
      openingBalance: 1000,
      totalDebits: 700,
      totalCredits: 500,
    );
    expect(result.balance, 800);
    expect(result.isCreditAvailable, isTrue);
  });

  test('negative balance means seller owes supplier', () {
    const result = SupplierBalance(
      openingBalance: 0,
      totalDebits: 4000,
      totalCredits: 3000,
    );
    expect(result.balance, -1000);
    expect(result.plainEnglishLabel, 'You owe supplier');
  });
}
