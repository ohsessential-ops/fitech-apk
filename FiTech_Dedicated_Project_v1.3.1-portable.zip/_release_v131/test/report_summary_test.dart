import 'package:flutter_test/flutter_test.dart';
import 'package:fitech/features/reports/domain/report_models.dart';

void main() {
  test('report summary stores all financial metrics', () {
    const summary = ReportSummary(
      totalOrders: 10,
      totalEarnings: 500,
      totalSupplierCost: 350,
      totalProfit: 150,
      averageOrderProfit: 15,
      profitMarginPercent: 30,
      totalRefunds: 20,
      totalSupplierCredits: 12,
    );

    expect(summary.totalOrders, 10);
    expect(summary.totalProfit, 150);
    expect(summary.profitMarginPercent, 30);
  });
}
