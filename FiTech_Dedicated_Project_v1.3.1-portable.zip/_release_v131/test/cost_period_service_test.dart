import 'package:flutter_test/flutter_test.dart';
import 'package:fitech/features/products/domain/cost_period_service.dart';

void main() {
  const service = CostPeriodService();

  test('cost applies on effective start date', () {
    expect(
      service.appliesToDate(
        targetDate: DateTime(2026, 7, 19),
        effectiveFrom: DateTime(2026, 7, 19),
      ),
      isTrue,
    );
  });

  test('cost does not apply before start date', () {
    expect(
      service.appliesToDate(
        targetDate: DateTime(2026, 7, 18),
        effectiveFrom: DateTime(2026, 7, 19),
      ),
      isFalse,
    );
  });

  test('effective-to date is exclusive', () {
    expect(
      service.appliesToDate(
        targetDate: DateTime(2026, 8, 1),
        effectiveFrom: DateTime(2026, 7, 1),
        effectiveTo: DateTime(2026, 8, 1),
      ),
      isFalse,
    );
  });
}
