import 'package:flutter_test/flutter_test.dart';
import 'package:fitech/features/imports/domain/import_models.dart';

void main() {
  test('preview counts importable rows', () {
    const preview = ImportPreview(
      type: ImportType.orders,
      fileName: 'test.csv',
      fileHash: 'hash',
      headers: ['order_id'],
      rows: [
        ImportValidationRow(
          rowNumber: 2,
          values: {'order_id': '1'},
          status: ImportRowStatus.valid,
          messages: [],
        ),
        ImportValidationRow(
          rowNumber: 3,
          values: {'order_id': ''},
          status: ImportRowStatus.invalid,
          messages: ['Missing order_id'],
        ),
      ],
    );

    expect(preview.validRows, 1);
    expect(preview.invalidRows, 1);
  });
}
