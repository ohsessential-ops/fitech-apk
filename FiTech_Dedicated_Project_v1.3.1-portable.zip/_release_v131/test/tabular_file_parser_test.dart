import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:fitech/features/imports/data/tabular_file_parser.dart';

void main() {
  test('parses CSV headers and rows', () {
    const csv = 'order_id,shop,quantity\n1001,Comfy Nest,2\n';
    final parsed = const TabularFileParser().parse(
      fileName: 'orders.csv',
      bytes: Uint8List.fromList(utf8.encode(csv)),
    );

    expect(parsed.headers, ['order_id', 'shop', 'quantity']);
    expect(parsed.rows.single['order_id'], '1001');
  });

  test('supports quoted comma values', () {
    const csv = 'order_id,notes\n1001,"Grey, large rug"\n';
    final parsed = const TabularFileParser().parse(
      fileName: 'orders.csv',
      bytes: Uint8List.fromList(utf8.encode(csv)),
    );

    expect(parsed.rows.single['notes'], 'Grey, large rug');
  });
}
