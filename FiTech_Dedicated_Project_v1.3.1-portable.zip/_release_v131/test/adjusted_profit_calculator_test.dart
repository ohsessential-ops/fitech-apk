import 'package:flutter_test/flutter_test.dart';
import 'package:fitech/features/returns/domain/adjusted_profit_calculator.dart';

void main() {
  const calculator = AdjustedProfitCalculator();

  test('calculates adjusted return profit', () {
    final result = calculator.calculate(
      originalProfit: 10,
      customerRefund: 25,
      supplierCredit: 12,
    );
    expect(result, -3);
  });

  test('suggests 60 percent supplier credit', () {
    final result = calculator.suggestedSupplierCredit(
      supplierCost: 20,
    );
    expect(result, 12);
  });
}
