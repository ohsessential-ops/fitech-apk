import 'package:flutter_test/flutter_test.dart';
import 'package:fitech/features/daily_close/domain/daily_close_summary.dart';

void main() {
  test('daily close summary preserves profit totals', () {
    final summary = DailyCloseSummary(
      date: DateTime(2026, 7, 19),
      orders: 10,
      earnings: 500,
      supplierCost: 300,
      profit: 200,
      refunds: 0,
      supplierBalance: 1000,
      bankBalance: 1500,
      missingTracking: 1,
      negativeProfitOrders: 0,
    );

    expect(summary.profit, 200);
    expect(summary.orders, 10);
  });
}
