import 'package:flutter_test/flutter_test.dart';
import 'package:fitech/features/data_quality/domain/data_quality_issue.dart';

void main() {
  test('data quality issue stores issue count', () {
    const issue = DataQualityIssue(
      type: DataQualityIssueType.missingTracking,
      title: 'Missing tracking',
      description: 'Tracking required',
      count: 4,
    );

    expect(issue.count, 4);
  });
}
