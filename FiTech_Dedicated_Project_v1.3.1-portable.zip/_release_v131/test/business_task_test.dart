import 'package:flutter_test/flutter_test.dart';
import 'package:fitech/features/tasks/domain/business_task.dart';

void main() {
  test('completed task is not overdue', () {
    final now = DateTime.now();
    final task = BusinessTask(
      id: 1,
      title: 'Pay supplier',
      priority: TaskPriority.high,
      dueAt: now.subtract(const Duration(days: 2)),
      completedAt: now,
      isCompleted: true,
      createdAt: now,
      updatedAt: now,
    );

    expect(task.isOverdue, false);
  });

  test('past incomplete task is overdue', () {
    final now = DateTime.now();
    final task = BusinessTask(
      title: 'Upload tracking',
      dueAt: now.subtract(const Duration(days: 1)),
      createdAt: now,
      updatedAt: now,
    );

    expect(task.isOverdue, true);
  });
}
