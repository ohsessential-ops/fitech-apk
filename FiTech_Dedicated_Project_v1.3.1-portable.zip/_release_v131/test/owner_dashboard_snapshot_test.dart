import 'package:flutter_test/flutter_test.dart';
import 'package:fitech/features/automation/domain/owner_dashboard_snapshot.dart';

void main() {
  test('owner dashboard stores productivity metrics', () {
    const snapshot = OwnerDashboardSnapshot(
      todayOrders: 5,
      todayProfit: 50,
      weekProfit: 300,
      monthProfit: 1200,
      pendingTasks: 3,
      unreadNotifications: 2,
      missingTracking: 1,
      negativeProfitOrders: 0,
    );

    expect(snapshot.todayOrders, 5);
    expect(snapshot.pendingTasks, 3);
  });
}
