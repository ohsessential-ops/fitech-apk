import 'package:flutter_test/flutter_test.dart';
import 'package:fitech/main.dart';

void main() {
  test('FiTechApp can be constructed', () {
    expect(const FiTechApp(), isA<FiTechApp>());
  });
}
