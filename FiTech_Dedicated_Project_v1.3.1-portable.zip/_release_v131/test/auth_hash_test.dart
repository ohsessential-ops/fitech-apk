import 'package:flutter_test/flutter_test.dart';
import 'package:fitech/features/auth/data/auth_repository.dart';

void main() {
  test('password hashing is deterministic', () {
    final repository = AuthRepository();
    expect(
      repository.hashPassword('FiTech@123'),
      repository.hashPassword('FiTech@123'),
    );
  });

  test('different passwords generate different hashes', () {
    final repository = AuthRepository();
    expect(
      repository.hashPassword('PasswordA'),
      isNot(repository.hashPassword('PasswordB')),
    );
  });
}
