import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fitech/shared/widgets/raised_3d_button.dart';

void main() {
  testWidgets('raised button exposes a professional action label', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Raised3DButton(
            label: 'Add entry',
            icon: Icons.add,
            onPressed: () {},
          ),
        ),
      ),
    );

    expect(find.text('Add entry'), findsOneWidget);
    expect(find.byIcon(Icons.add), findsOneWidget);
  });
}
