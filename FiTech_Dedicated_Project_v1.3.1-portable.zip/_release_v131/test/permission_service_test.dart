import 'package:flutter_test/flutter_test.dart';
import 'package:fitech/core/security/permissions.dart';
import 'package:fitech/domain/models/app_user.dart';

void main() {
  const service = PermissionService();

  test('owner has all permissions', () {
    expect(
      service.permissionsFor(UserRole.owner).length,
      AppPermission.values.length,
    );
  });

  test('read-only cannot manage entries', () {
    expect(
      service.can(UserRole.readOnly, AppPermission.manageEntries),
      isFalse,
    );
  });

  test('accountant can manage bank', () {
    expect(
      service.can(UserRole.accountant, AppPermission.manageBank),
      isTrue,
    );
  });
}
