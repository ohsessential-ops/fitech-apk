import 'package:flutter_test/flutter_test.dart';
import 'package:fitech/domain/services/profit_calculator.dart';

void main() {
  const calculator = ProfitCalculator();

  test('calculates normal profit', () {
    final result = calculator.calculate(
      tiktokNetEarning: 25,
      supplierTotalCost: 17,
    );
    expect(result.profit, 8);
    expect(result.marginPercent, 32);
  });

  test('supports negative manual adjustment', () {
    final result = calculator.calculate(
      tiktokNetEarning: 25,
      supplierTotalCost: 17,
      manualAdjustment: -2,
    );
    expect(result.profit, 6);
    expect(result.marginPercent, 24);
  });

  test('returns null margin when earning is zero', () {
    final result = calculator.calculate(
      tiktokNetEarning: 0,
      supplierTotalCost: 5,
    );
    expect(result.profit, -5);
    expect(result.marginPercent, isNull);
  });
}
