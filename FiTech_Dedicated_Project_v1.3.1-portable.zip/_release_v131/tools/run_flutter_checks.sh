#!/usr/bin/env bash
set -euo pipefail

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK is required for runtime checks." >&2
  exit 127
fi

flutter pub get
flutter analyze
flutter test --coverage
flutter build apk --debug
