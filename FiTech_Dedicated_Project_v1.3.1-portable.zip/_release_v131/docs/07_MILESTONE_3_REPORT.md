# Milestone 3 Report — Products and Dated Cost History

## Completed

- Product model
- Supplier SKU support
- Product creation
- Opening supplier cost
- Product search
- Current-cost display
- Dated cost-history records
- Cost periods with exclusive end dates
- New cost insertion that closes the previous period
- Product cost-history screen
- Automatic SKU lookup from Financial Entry
- Automatic cost selection using the order date
- Product and variant snapshots on financial orders
- Historical order costs remain unchanged
- Cost-period unit tests

## Key control

Changing a product's current supplier cost does not alter old financial orders. Every saved order keeps its own supplier-cost snapshot.

## Next milestone

Supplier ledger, supplier payments, order debits, return credits, corrections, and running supplier balance.
