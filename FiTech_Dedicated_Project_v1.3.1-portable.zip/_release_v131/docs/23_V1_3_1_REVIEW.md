# FiTech v1.3.1 Review

## Corrected

- Bulk order import now writes to the current financial-order schema.
- Bulk tracking updates now find orders by TikTok order ID.
- Bulk supplier payments now post valid supplier and bank ledger entries.
- Product lookup during import now uses the current product-name field.
- Universal order and product search now uses current database fields.
- Duplicate import files can be safely reviewed again; individual duplicate
  orders remain protected by the unique TikTok order ID.
- The FiTech logo is configured as the Android launcher and adaptive icon.
- Database version 8 safely repairs the import-history index on existing apps.

## Validation

- Offline source quality gate: passed with zero errors.
- Database-contract regression checks: passed.
- Android project generation and APK compilation are performed by GitHub
  Actions using Flutter 3.35.7 and Java 17.

## Remaining product limitations

- Marketplace integrations are scaffolding and require official marketplace
  API authorization before they can retrieve live records.
- Cloud sync remains disabled in the private owner edition.
- The initial local owner password should be replaced before any shared or
  commercial deployment; a dedicated password-change workflow is still needed.
