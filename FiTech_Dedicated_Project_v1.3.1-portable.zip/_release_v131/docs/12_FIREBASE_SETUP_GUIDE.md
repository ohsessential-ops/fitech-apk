# FiTech Firebase Setup Guide

## 1. Create the project

Create a Firebase project named `FiTech Production` or another approved name.

## 2. Configure FlutterFire

```bash
dart pub global activate flutterfire_cli
firebase login
flutterfire configure
```

Select Android, iOS, Windows and Web only when those platforms are required.

## 3. Authentication

Enable:

- Email/Password
- Password reset email
- Multi-factor authentication when the project plan supports it

## 4. Firestore collections

Recommended collections:

- users
- shops
- products
- product_cost_history
- financial_orders
- supplier_ledger_entries
- bank_ledger_entries
- returns
- audit_logs
- app_settings
- backups

## 5. Security rules

Use role claims and deny access by default. Do not use open test-mode rules in production.

## 6. Crashlytics

Enable Crashlytics and upload release symbols for Android and iOS builds.

## 7. Storage

Use Storage for:

- Business logo
- Exported reports
- Encrypted backups
- Evidence attachments

## 8. Secrets

Do not commit private service-account keys, signing passwords or encryption keys.
