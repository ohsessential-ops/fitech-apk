# FiTech Final Test Checklist

## Critical workflows

- Fresh install opens without a crash.
- Owner login and sign-out work.
- Product creation and supplier-cost history work.
- Financial order entry calculates profit correctly.
- Supplier and bank ledgers remain balanced.
- Return adjustment updates adjusted profit correctly.
- Bulk import rejects invalid and duplicate rows safely.
- Backup export and restore preserve record counts.
- Daily close creates only one record per date.
- Marketplace account screens work without live credentials.

## Device coverage

- Android 8/9 low-memory phone.
- Android 11–13 mainstream phone.
- Android 14–16 modern phone.
- Small screen and large tablet layout.
- Light mode, system font scaling and screen rotation.

## Reliability

- Force-close and reopen during data entry.
- Airplane mode/offline operation.
- Low storage behaviour.
- Database upgrade from versions 1 through 7.
- Large dataset performance: 10,000 orders and 5,000 ledger rows.

## Security

- No marketplace secrets in source control or logs.
- Production secrets stored with Android Keystore-backed secure storage.
- Release build has no debug banner or test credentials.
- Database backup includes an explicit user warning about sensitive data.
