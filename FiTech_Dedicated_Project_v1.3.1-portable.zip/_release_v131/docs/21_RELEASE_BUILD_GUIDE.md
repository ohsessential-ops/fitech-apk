# FiTech Android Release Build Guide

Task 14 should run these commands from the project root:

```bash
flutter create --platforms=android .
flutter pub get
flutter analyze
flutter test
flutter build apk --debug
```

After successful device testing, configure the private signing keystore and run:

```bash
flutter build apk --release
flutter build appbundle --release
```

Expected outputs:

- `build/app/outputs/flutter-apk/app-release.apk`
- `build/app/outputs/bundle/release/app-release.aab`

Never include the keystore file, passwords or production API secrets in a user-shared source archive.
