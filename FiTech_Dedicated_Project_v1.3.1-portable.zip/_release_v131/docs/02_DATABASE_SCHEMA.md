# Proposed Database Schema

## organisations
id, name, currency_code, timezone, created_at

## users
id, organisation_id, full_name, email, role_id, is_active, created_at, updated_at

## roles
id, organisation_id, name, permissions_json

## shops
id, organisation_id, name, platform, is_active

## suppliers
id, organisation_id, display_name, warehouse_name, encrypted_contact, is_active

## products
id, organisation_id, supplier_id, sku, supplier_sku, product_name, variant, category, is_active

## product_cost_history
id, product_id, unit_cost_gbp, effective_from, effective_to, created_by, created_at

## financial_orders
id, organisation_id, shop_id, supplier_id, product_id, tiktok_order_id,
order_date, quantity, tiktok_net_earning_gbp,
supplier_unit_cost_snapshot_gbp, supplier_total_cost_gbp,
manual_adjustment_gbp, calculated_profit_gbp, profit_margin_percent,
tracking_number, payout_status, notes, created_by, created_at, updated_at, deleted_at

## supplier_ledger_entries
id, organisation_id, supplier_id, entry_date,
type, reference_id, debit_gbp, credit_gbp, running_balance_gbp,
notes, created_by, created_at

Sign convention:
- Credit increases money held with supplier
- Debit reduces it
- Negative balance means money owed

## bank_ledger_entries
id, organisation_id, entry_date, type, shop_id, amount_gbp, reference, notes, created_by, created_at

## bank_reconciliations
id, organisation_id, reconciliation_date, actual_bank_balance_gbp,
calculated_balance_gbp, difference_gbp, notes, created_by, created_at

## returns
id, organisation_id, financial_order_id, return_date, reason,
customer_refund_gbp, supplier_credit_gbp, other_adjustment_gbp,
adjusted_profit_gbp, notes, created_by, created_at

## imports
id, organisation_id, source_type, original_filename,
rows_total, rows_imported, rows_rejected, error_file_path, created_by, created_at

## audit_logs
id, organisation_id, user_id, action, entity_type, entity_id,
before_json, after_json, created_at
