# FiTech Product Requirements

## Product purpose

FiTech is a financial ERP, not a fulfilment ERP. Its purpose is to provide accurate daily financial control for multi-shop e-commerce operations.

## Required dashboard values

- Cash available in bank
- Available supplier credit or supplier amount owed
- Today's profit
- Yesterday's profit
- Monthly profit
- Total supplier payments

## Core entry fields

- TikTok Order ID
- Shop
- Order date
- SKU
- Product/variant
- Quantity
- TikTok net earning
- Supplier unit cost snapshot
- Supplier total cost
- Tracking number, optional
- Adjustment, optional
- Notes
- Created by and timestamps

## Financial formulas

Normal profit:

`profit = TikTok net earning - supplier total cost`

Adjusted profit:

`adjusted profit = TikTok net earning - supplier total cost - customer refund + supplier credit + manual adjustment`

TikTok net earning is already after TikTok deductions.

## Supplier cost history

Every price change creates a new dated cost record. Historical order costs remain unchanged.

## Returns

The app may suggest 60% supplier credit, but the user must confirm the real amount.

## Multi-user roles

- Owner
- Finance Manager
- Data Entry
- Accountant/Viewer

Supplier cost and supplier identity must be protected by permissions.

## Search

Search by Order ID, SKU, supplier SKU, tracking number, product, shop, and date.

## Imports and reports

- Import supplier Excel files with column mapping and validation
- Export monthly Excel reports
- Export professional branded PDF reports
- Keep row-level import errors
- Never overwrite historical financial records silently

## Backup

- Local-first storage
- Automatic cloud backup and sync
- Visible last-sync status
- Conflict-safe financial records
