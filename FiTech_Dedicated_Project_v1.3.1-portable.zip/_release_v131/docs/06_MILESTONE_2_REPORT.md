# Milestone 2 Report — Local Financial Engine

## Completed

- SQLite database initialization
- Six shops seeded automatically
- Financial order storage
- Product and cost-history foundation tables
- Unique TikTok Order ID protection
- Search indexes
- Profit calculation domain service
- Real financial-entry saving
- Live profit and margin preview
- Loss warning
- Save and Add Another workflow
- Entries list and search
- Dashboard calculations for today, yesterday, month, lifetime and total orders
- Unit tests

## Formula

`profit = TikTok net earning - supplier total cost + manual adjustment`

TikTok net earning is already after TikTok deductions.

## Pending

- Product management UI
- Automatic dated supplier-cost lookup
- Supplier ledger and payments
- Bank reconciliation
- Returns
- PDF and Excel reports
- Authentication backend
- Cloud sync and permissions
