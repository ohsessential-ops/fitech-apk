# Milestone 4 Report — Supplier Ledger and Payments

## Completed

- Database migration to version 2
- Primary supplier record
- Supplier ledger
- Automatic order debit
- Atomic order and ledger save
- Payoneer supplier payments
- Supplier credits
- Credit and debit corrections
- Running signed balance
- Plain-English balance wording
- Supplier activity screen
- Dashboard supplier balance
- Dashboard total supplier payments
- Unit tests

## Balance convention

`balance = opening balance + credits - debits`

Positive means credit available with supplier.
Negative means the seller owes the supplier.

## Next milestone

Bank ledger, actual bank reconciliation, returns, supplier refund credits, and adjusted profit.
