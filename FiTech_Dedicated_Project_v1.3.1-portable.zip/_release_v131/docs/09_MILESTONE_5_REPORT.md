# Milestone 5 Report — Bank, Reconciliation and Returns

## Completed

- Database migration to version 3
- Bank ledger
- Manual bank inflows and outflows
- Supplier payments recorded as bank outflows
- Customer refunds recorded as bank outflows
- Calculated FiTech cash balance
- Manual actual-bank reconciliation
- Difference between calculated and actual bank balance
- Returns table and workflow
- Return lookup by TikTok Order ID
- Suggested 60% supplier credit
- Manual confirmation of actual supplier credit
- Supplier return credit posted to supplier ledger
- Adjusted profit calculation
- Financial order profit updated after return
- Dashboard cash metric
- Bank and returns screens
- Unit tests

## Adjusted profit

`adjusted profit = original profit - customer refund + supplier credit + other adjustment`

## Important distinction

Calculated FiTech cash is not automatically treated as the real bank balance.
The app stores actual reconciled bank balance separately and displays the difference.

## Next milestone

Reports, charts, PDF export, Excel export, shop analysis, monthly summaries, and branded management reports.
