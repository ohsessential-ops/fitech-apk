# Development Roadmap

## Milestone 1 — Foundation
- Flutter project
- Theme and branding
- Navigation
- Login shell
- Dashboard shell
- Core domain models
- Database migrations

## Milestone 2 — Financial Engine
- Products
- Cost history
- Add financial entry
- Profit calculations
- Unit tests
- Entries list and search

## Milestone 3 — Supplier
- Supplier ledger
- Running balance
- Supplier payments
- Credits and corrections
- Excel import

## Milestone 4 — Bank and Returns
- Bank ledger
- Bank reconciliation
- Returns
- Adjusted profit

## Milestone 5 — Reports
- Dashboard analytics
- Monthly reports
- PDF export
- Excel export

## Milestone 6 — Commercial Foundations
- Authentication backend
- Multi-user roles
- Permission checks
- Audit log
- Offline/cloud sync
- Backup
- Testing and release build
