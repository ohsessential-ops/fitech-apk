# FiTech UI/UX Specification

## Brand

- Name: FiTech
- Supporting line: Powered by Faizan
- Style: premium, clean, modern finance application
- Base colours: deep navy, white, bright blue
- Material 3
- Light mode first
- Rounded 16–22 px cards
- Strong GBP number typography
- Large touch targets
- Minimal clutter

## Bottom navigation

1. Dashboard
2. Entries
3. Supplier
4. Reports
5. More

## Dashboard

Metric cards:
- Cash available in bank
- Supplier balance
- Today's profit
- Yesterday's profit
- Monthly profit
- Total supplier payments

Additional:
- Profit trend
- Shop comparison
- Recent entries
- Date and shop filters
- Sync status
- Quick actions

## Add entry flow

1. Shop
2. Order ID
3. SKU
4. Supplier cost auto-fill
5. TikTok net earning
6. Tracking number, optional
7. Live profit preview
8. Save or Save and Add Another

Target completion time: under 30 seconds.

## Supplier screen

Show signed balance using plain wording:
- “Credit available with supplier”
- “You owe supplier”

Include:
- Add supplier payment
- Add correction
- Import supplier Excel
- Export ledger
- Running-balance transaction list

## Reports

- Date range
- Shop filter
- KPI summary
- Charts
- PDF preview/export
- Excel export
